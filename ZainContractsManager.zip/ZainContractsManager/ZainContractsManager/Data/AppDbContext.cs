﻿#nullable enable
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.IO;
using System.Linq;
using System.Windows; // Application.Current.Properties
using ZainContractsManager.Models;
using ZainContractsManager.Models.Settings;
using ZainContractsManager.Models.Finance;
using ZainContractsManager.Models.SaaS;

// ✅ FIX: solve ambiguity with System.Windows.Expression
using LinqExpression = System.Linq.Expressions.Expression;
using System.Linq.Expressions;

namespace ZainContractsManager.Data
{
    public class AppDbContext : DbContext
    {
        public static string DbFolder =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ZainContractsManager");

        public static string DbPath =>
            Path.Combine(DbFolder, "ZainSystem.db");

        // =====================================================
        // ✅ Multi-Tenant Switch (set after login / company select)
        // =====================================================
        public int CurrentCompanyId { get; set; } = 0;

        // -----------------------------------------------------
        // Constructors (safe for migrations + runtime)
        // -----------------------------------------------------
        public AppDbContext()
        {
            TryLoadCompanyIdFromAppSafe();
        }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            TryLoadCompanyIdFromAppSafe();
        }

        // ✅ لازم تكون SAFE مع الـ Migrate/Startup (Application.Current قد يكون null)
        private void TryLoadCompanyIdFromAppSafe()
        {
            try
            {
                var app = Application.Current;
                if (app?.Properties == null) return;

                var props = app.Properties;
                if (!props.Contains("CurrentCompanyId")) return;

                var v = props["CurrentCompanyId"];
                if (v != null && int.TryParse(v.ToString(), out var cid))
                    CurrentCompanyId = cid;
            }
            catch
            {
                // ignore
            }
        }

        // =====================================================
        // Core tables
        // =====================================================
        public DbSet<LeaseContract> Contracts { get; set; } = null!;
        public DbSet<Branch> Branches { get; set; } = null!;
        public DbSet<FinancialExpense> FinancialExpenses { get; set; } = null!;
        public DbSet<Payment> Payments { get; set; } = null!;
        public DbSet<Document> Documents { get; set; } = null!;
        public DbSet<User> Users { get; set; } = null!;

        // ✅ SaaS Core (لا تُفلتر)
        public DbSet<Company> Companies { get; set; } = null!;
        public DbSet<CompanyUser> CompanyUsers { get; set; } = null!;

        // ✅ Budget Engine
        public DbSet<BranchBudget> BranchBudgets { get; set; } = null!;

        // Settings Engine
        public DbSet<AppSetting> AppSettings { get; set; } = null!;

        // Finance Engine
        public DbSet<Account> Accounts { get; set; } = null!;
        public DbSet<JournalEntry> JournalEntries { get; set; } = null!;
        public DbSet<JournalLine> JournalLines { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured) return;

            if (!Directory.Exists(DbFolder))
                Directory.CreateDirectory(DbFolder);

            optionsBuilder.UseSqlite($"Data Source={DbPath}");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // =====================================================
            // 1) Decimal converters (SQLite)
            // =====================================================
            var decimalConverter = new ValueConverter<decimal, double>(
                v => (double)v,
                v => (decimal)v);

            var nullableDecimalConverter = new ValueConverter<decimal?, double?>(
                v => v.HasValue ? (double?)v.Value : null,
                v => v.HasValue ? (decimal?)v.Value : null);

            foreach (var entityType in modelBuilder.Model.GetEntityTypes())
            {
                foreach (var property in entityType.GetProperties())
                {
                    if (property.ClrType == typeof(decimal))
                        property.SetValueConverter(decimalConverter);
                    else if (property.ClrType == typeof(decimal?))
                        property.SetValueConverter(nullableDecimalConverter);
                }
            }

            // =====================================================
            // ✅ SaaS (Companies / CompanyUsers) - NO TENANT FILTER HERE
            // =====================================================
            modelBuilder.Entity<Company>(entity =>
            {
                entity.ToTable("Companies");

                entity.HasIndex(c => c.Name);
                entity.HasIndex(c => c.Code).IsUnique();

                entity.Property(c => c.Name).HasMaxLength(200).IsRequired();
                entity.Property(c => c.Code).HasMaxLength(50).IsRequired();

                entity.Property(c => c.TaxNumber).HasMaxLength(50);
                entity.Property(c => c.Country).HasMaxLength(100);
                entity.Property(c => c.City).HasMaxLength(100);
            });

            modelBuilder.Entity<CompanyUser>(entity =>
            {
                entity.ToTable("CompanyUsers");

                entity.HasIndex(x => new { x.CompanyId, x.UserId }).IsUnique();

                entity.HasOne(x => x.Company)
                      .WithMany(c => c.Users)
                      .HasForeignKey(x => x.CompanyId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(x => x.User)
                      .WithMany(u => u.CompanyUsers)
                      .HasForeignKey(x => x.UserId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.Property(x => x.Role).HasMaxLength(50);
            });

            // =====================================================
            // 2) Payment -> Contract (Cascade)
            // =====================================================
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Contract)
                .WithMany(c => c.Payments)
                .HasForeignKey(p => p.ContractId)
                .OnDelete(DeleteBehavior.Cascade);

            // =====================================================
            // 3) Indexes
            // =====================================================
            modelBuilder.Entity<LeaseContract>().HasIndex(c => c.BranchName);

            modelBuilder.Entity<LeaseContract>()
                .HasIndex(c => new { c.CompanyId, c.ContractNumber })
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            modelBuilder.Entity<AppSetting>(entity =>
            {
                entity.ToTable("AppSettings");
                entity.HasIndex(s => s.Key).IsUnique();
                entity.Property(s => s.Key).HasMaxLength(200);
            });

            modelBuilder.Entity<BranchBudget>(entity =>
            {
                entity.ToTable("BranchBudgets");

                entity.HasIndex(b => b.BranchName);
                entity.HasIndex(b => new { b.Year, b.Month, b.Category, b.BranchName }).IsUnique();

                entity.Property(b => b.BranchName).HasMaxLength(200);
                entity.Property(b => b.Category).HasMaxLength(100);

                entity.HasOne<Branch>()
                      .WithMany()
                      .HasForeignKey(b => b.BranchId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            // =====================================================
            // Finance Engine Mapping
            // =====================================================
            modelBuilder.Entity<Account>(entity =>
            {
                entity.ToTable("Accounts");
                entity.HasIndex(a => new { a.CompanyId, a.Code }).IsUnique();
                entity.HasIndex(a => a.Name);

                entity.Property(a => a.Code).HasMaxLength(50).IsRequired();
                entity.Property(a => a.Name).HasMaxLength(200).IsRequired();
                entity.Property(a => a.BranchName).HasMaxLength(200);

                entity.HasOne(a => a.Parent)
                      .WithMany(a => a.Children)
                      .HasForeignKey(a => a.ParentId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<JournalEntry>(entity =>
            {
                entity.ToTable("JournalEntries");

                entity.HasIndex(e => e.EntryDate);
                entity.HasIndex(e => e.EntryNo);
                entity.HasIndex(e => new { e.CompanyId, e.EntryNo });
                entity.HasIndex(e => new { e.CompanyId, e.BranchId });

                entity.Property(e => e.EntryNo).HasMaxLength(50);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.SourceType).HasMaxLength(50);
                entity.Property(e => e.BranchName).HasMaxLength(200);

                entity.HasOne(e => e.Branch)
                      .WithMany()
                      .HasForeignKey(e => e.BranchId)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<JournalLine>(entity =>
            {
                entity.ToTable("JournalLines");

                entity.HasIndex(l => l.JournalEntryId);
                entity.HasIndex(l => l.AccountId);
                entity.HasIndex(l => l.CompanyId);

                entity.Property(l => l.Notes).HasMaxLength(500);

                entity.HasOne(l => l.JournalEntry)
                      .WithMany(e => e.Lines)
                      .HasForeignKey(l => l.JournalEntryId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(l => l.Account)
                      .WithMany()
                      .HasForeignKey(l => l.AccountId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            // =====================================================
            // ✅ Global Tenant Filters
            // =====================================================
            ApplyTenantFilters(modelBuilder);
        }

        public void InitializeDatabase()
        {
            Database.Migrate();
        }

        private void ApplyTenantFilters(ModelBuilder modelBuilder)
        {
            ApplyTenantFilterIfHasCompanyId<LeaseContract>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<Payment>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<FinancialExpense>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<Document>(modelBuilder);

            ApplyTenantFilterIfHasCompanyId<Account>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<JournalEntry>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<JournalLine>(modelBuilder);

            ApplyTenantFilterIfHasCompanyId<Branch>(modelBuilder);
            ApplyTenantFilterIfHasCompanyId<BranchBudget>(modelBuilder);

            // ❌ ممنوع Tenant Filter على Companies / CompanyUsers
        }

        // ✅ FIX: tolerate legacy rows where CompanyId might be NULL in SQLite
        private void ApplyTenantFilterIfHasCompanyId<TEntity>(ModelBuilder modelBuilder) where TEntity : class
        {
            var entity = modelBuilder.Entity<TEntity>();

            if (entity.Metadata.FindProperty("CompanyId") == null)
                return;

            var param = LinqExpression.Parameter(typeof(TEntity), "e");

            // EF.Property<int?>(e, "CompanyId")
            var companyPropNullable = LinqExpression.Call(
                typeof(EF),
                nameof(EF.Property),
                new[] { typeof(int?) },
                param,
                LinqExpression.Constant("CompanyId"));

            // (EF.Property<int?>(...) ?? 0)
            var companyPropSafe = LinqExpression.Coalesce(
                companyPropNullable,
                LinqExpression.Constant(0));

            // this.CurrentCompanyId
            var ctxConst = LinqExpression.Constant(this, typeof(AppDbContext));
            var current = LinqExpression.Property(ctxConst, nameof(CurrentCompanyId));

            // (CurrentCompanyId > 0) && ((CompanyId ?? 0) == CurrentCompanyId)
            var body = LinqExpression.AndAlso(
                LinqExpression.GreaterThan(current, LinqExpression.Constant(0)),
                LinqExpression.Equal(companyPropSafe, current));

            var lambda = LinqExpression.Lambda<Func<TEntity, bool>>(body, param);
            entity.HasQueryFilter(lambda);
        }
    }
}