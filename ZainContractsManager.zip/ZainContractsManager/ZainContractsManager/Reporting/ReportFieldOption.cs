﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ZainContractsManager.Reporting
{
    public sealed class ReportFieldOption : INotifyPropertyChanged
    {
        public string Key { get; }
        public string DisplayName { get; }
        public string Group { get; }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value) return;
                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public ReportFieldOption(string key, string displayName, string group, bool selectedByDefault = false)
        {
            Key = key;
            DisplayName = displayName;
            Group = group;
            _isSelected = selectedByDefault;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}