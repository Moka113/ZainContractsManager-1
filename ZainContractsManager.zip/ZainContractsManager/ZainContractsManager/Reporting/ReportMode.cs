﻿namespace ZainContractsManager.Reporting
{
    public enum ReportMode
    {
        ContractDetailed,   // صف لكل عقد + تجميعات (مدفوعات/مصاريف/مستندات)
        BranchSummary       // صف لكل فرع + تجميعات
    }
}