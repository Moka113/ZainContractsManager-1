﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace ZainContractsManager.Reporting
{
    public sealed class ReportsStateStore
    {
        private sealed class ReportsState
        {
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public string SelectedBranch { get; set; }
            public string SelectedMode { get; set; }
            public bool IncludeTotalsRow { get; set; }
            public bool IncludeArchivedDocuments { get; set; }
            public List<string> SelectedFieldKeys { get; set; } = new();
        }

        private readonly string _path;

        public ReportsStateStore()
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ZainContractsManager");
            Directory.CreateDirectory(dir);
            _path = Path.Combine(dir, "reports_state.json");
        }

        public void Save(DateTime start, DateTime end, string branch, string mode, bool totals, bool includeArchived, List<string> selectedKeys)
        {
            var state = new ReportsState
            {
                StartDate = start,
                EndDate = end,
                SelectedBranch = branch,
                SelectedMode = mode,
                IncludeTotalsRow = totals,
                IncludeArchivedDocuments = includeArchived,
                SelectedFieldKeys = selectedKeys ?? new List<string>()
            };

            File.WriteAllText(_path, JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));
        }

        public bool TryLoad(out DateTime start, out DateTime end, out string branch, out string mode, out bool totals, out bool includeArchived, out List<string> selectedKeys)
        {
            start = DateTime.Today.AddDays(-30);
            end = DateTime.Today;
            branch = "الكل";
            mode = "ContractDetailed";
            totals = true;
            includeArchived = false;
            selectedKeys = new List<string>();

            if (!File.Exists(_path)) return false;

            try
            {
                var json = File.ReadAllText(_path);
                var state = JsonSerializer.Deserialize<ReportsState>(json);
                if (state == null) return false;

                start = state.StartDate;
                end = state.EndDate;
                branch = string.IsNullOrWhiteSpace(state.SelectedBranch) ? "الكل" : state.SelectedBranch;
                mode = string.IsNullOrWhiteSpace(state.SelectedMode) ? "ContractDetailed" : state.SelectedMode;
                totals = state.IncludeTotalsRow;
                includeArchived = state.IncludeArchivedDocuments;
                selectedKeys = state.SelectedFieldKeys ?? new List<string>();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}