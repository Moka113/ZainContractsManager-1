﻿using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public class DashboardViewModel : ObservableObject
    {
        public DashboardViewModel()
        {
        }
    }
}