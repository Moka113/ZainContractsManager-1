﻿using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public class PaymentsViewModel : ObservableObject
    {
        public PaymentsViewModel()
        {
        }
    }
}