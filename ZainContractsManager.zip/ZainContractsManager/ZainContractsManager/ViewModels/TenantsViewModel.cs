﻿using System.Collections.ObjectModel;
using ZainContractsManager.Models;
using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public class TenantsViewModel : ObservableObject
    {
        private ObservableCollection<Tenant> _tenants;

        public ObservableCollection<Tenant> Tenants
        {
            get => _tenants;
            set
            {
                _tenants = value;
                OnPropertyChanged();
            }
        }

        public TenantsViewModel()
        {
            // تحميل بيانات تجريبية للتأكد من أن الشاشة تعمل
            LoadSampleData();
        }

        private void LoadSampleData()
        {
            Tenants = new ObservableCollection<Tenant>
            {
                new Tenant { Name = "أحمد محمد", IdNumber = "123456789", PhoneNumber = "0550000000", Email = "ahmed@example.com" },
                new Tenant { Name = "سارة علي", IdNumber = "987654321", PhoneNumber = "0560000000", Email = "sara@example.com" },
                new Tenant { Name = "شركة التوفيق", IdNumber = "777666555", PhoneNumber = "011222333", Email = "info@tawfeeq.com" }
            };
        }
    }
}