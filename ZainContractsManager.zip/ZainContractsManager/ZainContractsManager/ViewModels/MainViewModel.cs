﻿using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        private object _currentView;
        public object CurrentView
        {
            get => _currentView;
            set { _currentView = value; OnPropertyChanged(); }
        }

        // الأوامر الخاصة بالتنقل التي كانت تعمل سابقاً
        public RelayCommand DashboardViewCommand { get; set; }
        public RelayCommand TenantsViewCommand { get; set; }
        public RelayCommand ContractsViewCommand { get; set; } // عقود الفروع

        public MainViewModel()
        {
            // الصفحة الافتراضية عند فتح البرنامج
            CurrentView = new DashboardViewModel();

            // تعريف الأوامر بدون باراميتر 'o =>' لتعود للنسخة المستقرة
            DashboardViewCommand = new RelayCommand(() => CurrentView = new DashboardViewModel());
            TenantsViewCommand = new RelayCommand(() => CurrentView = new TenantsViewModel());
            ContractsViewCommand = new RelayCommand(() => CurrentView = new ContractsViewModel());
        }
    }
}