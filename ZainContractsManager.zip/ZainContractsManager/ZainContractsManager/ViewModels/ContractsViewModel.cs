﻿using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public class ContractsViewModel : ObservableObject
    {
        public ContractsViewModel()
        {
            // اتركها فارغة الآن، المحرك سيتولى الباقي
        }
    }
}