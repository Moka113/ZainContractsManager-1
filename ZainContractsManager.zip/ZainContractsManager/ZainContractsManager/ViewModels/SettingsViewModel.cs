﻿#nullable enable
using System;
using ZainContractsManager.Helpers;
using ZainContractsManager.Services.Settings;

namespace ZainContractsManager.ViewModels
{
    public class SettingsViewModel : ObservableObject
    {
        private readonly SettingsService _settings;

        public SettingsViewModel()
        {
            _settings = new SettingsService();
            Load();
        }

        private string _saveStatus = "جاهز";
        public string SaveStatus
        {
            get => _saveStatus;
            set => SetProperty(ref _saveStatus, value);
        }

        private DateTime _lastSavedAt = DateTime.Now;
        public DateTime LastSavedAt
        {
            get => _lastSavedAt;
            set => SetProperty(ref _lastSavedAt, value);
        }

        private bool _darkMode;
        public bool DarkMode
        {
            get => _darkMode;
            set
            {
                if (SetProperty(ref _darkMode, value))
                {
                    _settings.SetBool("ui.darkMode", value, "تفعيل الوضع الداكن");
                    ThemeService.Apply(value);
                    TouchSaved();
                }
            }
        }

        private string _companyName = "ZAIN SYSTEM";
        public string CompanyName
        {
            get => _companyName;
            set
            {
                if (SetProperty(ref _companyName, value))
                {
                    _settings.SetString("app.companyName", value, "اسم الشركة/النظام");
                    TouchSaved();
                }
            }
        }

        public void Load()
        {
            SaveStatus = "جاري التحميل...";

            var dm = _settings.GetBool("ui.darkMode", false);
            var cn = _settings.GetString("app.companyName", "ZAIN SYSTEM") ?? "ZAIN SYSTEM";

            ThemeService.Apply(dm);

            _darkMode = dm;
            OnPropertyChanged(nameof(DarkMode));

            _companyName = cn;
            OnPropertyChanged(nameof(CompanyName));

            LastSavedAt = DateTime.Now;
            SaveStatus = "تم التحميل ✅";
        }

        private void TouchSaved()
        {
            LastSavedAt = DateTime.Now;
            SaveStatus = "تم الحفظ ✅";
        }
    }
}