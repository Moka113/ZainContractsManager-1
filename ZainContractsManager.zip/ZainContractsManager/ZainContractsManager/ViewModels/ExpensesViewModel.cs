﻿#nullable enable
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

namespace ZainContractsManager.ViewModels
{
    public class ExpensesViewModel : BaseViewModel
    {
        private readonly AppDbContext _db = new AppDbContext();

        public ObservableCollection<FinancialExpense> Expenses { get; set; } = new ObservableCollection<FinancialExpense>();
        public ObservableCollection<Branch> Branches { get; set; } = new ObservableCollection<Branch>();

        #region الإجماليات المالية
        private decimal _totalBase;
        public decimal TotalBase { get => _totalBase; set { _totalBase = value; OnPropertyChanged(); } }

        private decimal _totalTax;
        public decimal TotalTax { get => _totalTax; set { _totalTax = value; OnPropertyChanged(); } }

        private decimal _totalGross;
        public decimal TotalGross { get => _totalGross; set { _totalGross = value; OnPropertyChanged(); } }
        #endregion

        #region خصائص الفلترة
        private string _searchText = string.Empty;
        public string SearchText
        {
            get => _searchText;
            set { _searchText = value; FilterData(); OnPropertyChanged(); }
        }

        private Branch? _selectedBranch;
        public Branch? SelectedBranch
        {
            get => _selectedBranch;
            set { _selectedBranch = value; FilterData(); OnPropertyChanged(); }
        }

        private int _selectedMonth = 0;
        public int SelectedMonth
        {
            get => _selectedMonth;
            set { _selectedMonth = value; FilterData(); OnPropertyChanged(); }
        }
        #endregion

        private List<FinancialExpense> _allData = new List<FinancialExpense>();

        public ExpensesViewModel()
        {
            LoadInitialData();
        }

        public void LoadInitialData()
        {
            try
            {
                // 1) جلب الفروع
                var branchesList = _db.Branches.AsNoTracking().ToList();
                Branches.Clear();
                foreach (var b in branchesList) Branches.Add(b);

                // 2) تحميل المصاريف
                RefreshExpenses();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ZAIN LOAD ERROR: {ex.Message}");
            }
        }

        public void RefreshExpenses()
        {
            try
            {
                // ✅ Contract ليس Navigation => ممنوع Include(e => e.Contract)
                // ✅ Include Branch فقط (لو محتاج تعرض بيانات Branch)
                _allData = _db.FinancialExpenses
                             .Include(e => e.Branch)
                             .OrderByDescending(e => e.ExpenseDate)
                             .AsNoTracking()
                             .ToList();

                FilterData();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"ZAIN REFRESH ERROR: {ex.Message}");
            }
        }

        public void FilterData()
        {
            if (_allData == null) return;

            var filtered = _allData.AsEnumerable();

            // ✅ فلترة حسب الفرع
            if (SelectedBranch != null)
            {
                // لو عندك BranchId في المصروف
                filtered = filtered.Where(e =>
                    (e.BranchId.HasValue && e.BranchId.Value == SelectedBranch.Id)
                    || (!string.IsNullOrWhiteSpace(e.BranchName) && e.BranchName == SelectedBranch.Name)
                );
            }

            // ✅ الفلترة حسب الشهر
            if (SelectedMonth > 0)
                filtered = filtered.Where(e => e.ExpenseDate.Month == SelectedMonth);

            // ✅ البحث النصي الشامل
            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                string query = SearchText.Trim().ToLowerInvariant();

                filtered = filtered.Where(e =>
                    (!string.IsNullOrWhiteSpace(e.Description) && e.Description.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.ExpenseNumber) && e.ExpenseNumber.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.InvoiceNumber) && e.InvoiceNumber.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.Category) && e.Category.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.ContractNumber) && e.ContractNumber.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.BranchName) && e.BranchName.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.ReferenceNo) && e.ReferenceNo.ToLowerInvariant().Contains(query)) ||
                    (!string.IsNullOrWhiteSpace(e.PaymentMethod) && e.PaymentMethod.ToLowerInvariant().Contains(query))
                );
            }

            Expenses.Clear();
            foreach (var item in filtered) Expenses.Add(item);

            UpdateTotals();
        }

        private void UpdateTotals()
        {
            TotalBase = Expenses.Sum(e => e.Amount);
            TotalTax = Expenses.Sum(e => e.TaxAmount);
            TotalGross = Expenses.Sum(e => e.TotalAmount);
        }

        public List<FinancialExpense> GetFilteredDataForExport() => Expenses.ToList();
    }
}