﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;
using System.Windows.Input;
using ZainContractsManager.Models;
using ZainContractsManager.Reporting;
using ZainContractsManager.Services;
using ZainContractsManager.Helpers;

namespace ZainContractsManager.ViewModels
{
    public sealed class ReportsViewModel : INotifyPropertyChanged
    {
        private readonly DbService _dbService;
        private readonly FileService _fileService;
        private readonly ReportsStateStore _stateStore;

        public ReportsViewModel()
        {
            _dbService = DbService.Instance;
            _fileService = new FileService();
            _stateStore = new ReportsStateStore();

            // Modes
            ReportModes = new ObservableCollection<string>
            {
                "ContractDetailed",
                "BranchSummary"
            };

            // Branches list (will be loaded from DB)
            Branches = new ObservableCollection<string>();

            // Fields (columns)
            Fields = new ObservableCollection<ReportFieldOption>(BuildAllFields());
            foreach (var f in Fields)
                f.PropertyChanged += Field_PropertyChanged;

            // Filtered view for left list
            FilteredFieldsView = CollectionViewSource.GetDefaultView(Fields);
            FilteredFieldsView.Filter = FieldsFilter;

            // Commands
            RefreshCommand = new RelayCommand(Refresh);
            ExportExcelCommand = new RelayCommand(ExportExcel);
            ExportCsvCommand = new RelayCommand(ExportCsv);

            QuickRange30Command = new RelayCommand(() =>
            {
                StartDate = DateTime.Today.AddDays(-30);
                EndDate = DateTime.Today;
                Refresh();
            });

            QuickRangeMonthCommand = new RelayCommand(() =>
            {
                StartDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                EndDate = DateTime.Today;
                Refresh();
            });

            PresetFullCommand = new RelayCommand(() => ApplyPreset("FULL"));
            PresetFinanceCommand = new RelayCommand(() => ApplyPreset("FINANCE"));
            PresetDocsCommand = new RelayCommand(() => ApplyPreset("DOCS"));
            PresetOverdueCommand = new RelayCommand(() => ApplyPreset("OVERDUE"));
            ClearFieldsCommand = new RelayCommand(ClearFields);

            FooterHint = "ملحوظة: المعاينة هي نفس البيانات التي سيتم تصديرها إلى Excel/CSV.";

            LoadBranches();
            LoadStateOrDefaults();
            Refresh();
        }

        // ====== UI Props ======
        public ObservableCollection<string> Branches { get; }
        public ObservableCollection<string> ReportModes { get; }

        private string _selectedBranch = "الكل";
        public string SelectedBranch
        {
            get => _selectedBranch;
            set { _selectedBranch = value; OnPropertyChanged(); Refresh(); }
        }

        private string _selectedMode = "ContractDetailed";
        public string SelectedMode
        {
            get => _selectedMode;
            set { _selectedMode = value; OnPropertyChanged(); Refresh(); }
        }

        private DateTime _startDate;
        public DateTime StartDate
        {
            get => _startDate;
            set { _startDate = value; OnPropertyChanged(); }
        }

        private DateTime _endDate;
        public DateTime EndDate
        {
            get => _endDate;
            set { _endDate = value; OnPropertyChanged(); }
        }

        private bool _includeTotalsRow = true;
        public bool IncludeTotalsRow
        {
            get => _includeTotalsRow;
            set { _includeTotalsRow = value; OnPropertyChanged(); Refresh(); }
        }

        private bool _includeArchivedDocuments = false;
        public bool IncludeArchivedDocuments
        {
            get => _includeArchivedDocuments;
            set { _includeArchivedDocuments = value; OnPropertyChanged(); Refresh(); }
        }

        public ObservableCollection<ReportFieldOption> Fields { get; }
        public ICollectionView FilteredFieldsView { get; }

        public IEnumerable<ReportFieldOption> FilteredFields
            => FilteredFieldsView.Cast<ReportFieldOption>();

        private string _fieldsSearchText = "";
        public string FieldsSearchText
        {
            get => _fieldsSearchText;
            set { _fieldsSearchText = value ?? ""; OnPropertyChanged(); FilteredFieldsView.Refresh(); }
        }

        private DataTable _previewTable;
        public DataTable PreviewTable
        {
            get => _previewTable;
            private set { _previewTable = value; OnPropertyChanged(); OnPropertyChanged(nameof(PreviewView)); }
        }

        // ✅ هذا هو حل المعاينة (DataGrid يحب DataView)
        public DataView PreviewView => PreviewTable?.DefaultView;

        private string _statusText = "جاهز";
        public string StatusText
        {
            get => _statusText;
            set { _statusText = value; OnPropertyChanged(); }
        }

        private string _previewCountText = "";
        public string PreviewCountText
        {
            get => _previewCountText;
            set { _previewCountText = value; OnPropertyChanged(); }
        }

        private string _lastGeneratedText = "لم يتم إنشاء تقرير بعد.";
        public string LastGeneratedText
        {
            get => _lastGeneratedText;
            set { _lastGeneratedText = value; OnPropertyChanged(); }
        }

        public string FooterHint { get; }

        // ===== Commands =====
        public ICommand RefreshCommand { get; }
        public ICommand ExportExcelCommand { get; }
        public ICommand ExportCsvCommand { get; }
        public ICommand QuickRange30Command { get; }
        public ICommand QuickRangeMonthCommand { get; }
        public ICommand PresetFullCommand { get; }
        public ICommand PresetFinanceCommand { get; }
        public ICommand PresetDocsCommand { get; }
        public ICommand PresetOverdueCommand { get; }
        public ICommand ClearFieldsCommand { get; }

        // ===== Core =====
        private void Refresh()
        {
            if (EndDate < StartDate)
            {
                StatusText = "⚠️ خطأ: تاريخ النهاية أصغر من تاريخ البداية.";
                PreviewTable = new DataTable();
                PreviewCountText = "0 صف";
                return;
            }

            StatusText = "⏳ جاري تجهيز المعاينة...";
            var dt = BuildReport();
            PreviewTable = dt;
            PreviewCountText = $"{dt.Rows.Count} صف";
            StatusText = "✅ تم تجهيز المعاينة.";
            LastGeneratedText = $"آخر تحديث: {DateTime.Now:yyyy-MM-dd HH:mm:ss}";

            SaveState();
        }

        private void ExportExcel()
        {
            var dt = BuildReport();
            var path = _fileService.ExportToExcel(dt, "تقرير_ZAIN");
            if (!string.IsNullOrWhiteSpace(path))
            {
                StatusText = "✅ تم تصدير Excel بنجاح.";
                _fileService.OpenFileIfExists(path);
            }
        }

        private void ExportCsv()
        {
            var dt = BuildReport();
            var path = _fileService.ExportToCsv(dt, "تقرير_ZAIN");
            if (!string.IsNullOrWhiteSpace(path))
            {
                StatusText = "✅ تم تصدير CSV بنجاح.";
                _fileService.OpenFileIfExists(path);
            }
        }

        private DataTable BuildReport()
        {
            // الأعمدة المختارة
            var selectedFields = Fields.Where(f => f.IsSelected).Select(f => f.Key).ToList();
            if (selectedFields.Count == 0)
            {
                // افتراضي: لو المستخدم شال الكل
                ApplyPreset("FULL");
                selectedFields = Fields.Where(f => f.IsSelected).Select(f => f.Key).ToList();
            }

            using var db = _dbService.CreateDbContext();

            // فلترة الفرع
            bool filterBranch = !(string.IsNullOrWhiteSpace(SelectedBranch) || SelectedBranch == "الكل");
            string branch = SelectedBranch ?? "الكل";

            // ===== Data base queries =====
            var contractsQ = db.Contracts.AsNoTracking()
                .Where(c => c.StartDate >= StartDate && c.StartDate <= EndDate);

            if (filterBranch)
                contractsQ = contractsQ.Where(c => (c.BranchName ?? "") == branch);

            var contractList = contractsQ.ToList();

            // payments for these contracts
            var contractIds = contractList.Select(c => c.Id).ToList();

            var payments = db.Payments.AsNoTracking()
                .Where(p => contractIds.Contains(p.ContractId))
                .ToList();

            // expenses by contract number (your model uses ContractNumber)
            var contractNumbers = contractList.Select(c => c.ContractNumber).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct().ToList();

            var expensesQ = db.FinancialExpenses.AsNoTracking()
                .Where(e => e.ExpenseDate >= StartDate && e.ExpenseDate <= EndDate);

            if (filterBranch)
                expensesQ = expensesQ.Where(e => (e.BranchName ?? "") == branch);

            if (contractNumbers.Count > 0)
                expensesQ = expensesQ.Where(e => contractNumbers.Contains(e.ContractNumber));

            var expenses = expensesQ.ToList();

            // documents
            var docsQ = db.Documents.AsNoTracking();

            if (filterBranch)
                docsQ = docsQ.Where(d => (d.BranchName ?? "") == branch);

            if (!IncludeArchivedDocuments)
                docsQ = docsQ.Where(d => !d.IsArchived);

            if (contractNumbers.Count > 0)
                docsQ = docsQ.Where(d => contractNumbers.Contains(d.ContractNumber));

            var docs = docsQ.ToList();

            // ===== Build result table =====
            var dt = new DataTable("ZAIN_REPORT");

            // add columns by selectedFields
            foreach (var colName in selectedFields.Select(FieldToColumnName).Distinct())
                dt.Columns.Add(colName);

            // core mode
            if (SelectedMode == "BranchSummary")
            {
                var groups = contractList
                    .GroupBy(c => (c.BranchName ?? "غير محدد"))
                    .OrderBy(g => g.Key)
                    .ToList();

                foreach (var g in groups)
                {
                    var row = dt.NewRow();

                    var branchName = g.Key;
                    var gContracts = g.ToList();
                    var gIds = gContracts.Select(x => x.Id).ToList();
                    var gNumbers = gContracts.Select(x => x.ContractNumber).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();

                    var gPayments = payments.Where(p => gIds.Contains(p.ContractId)).ToList();
                    var gExpenses = expenses.Where(e => gNumbers.Contains(e.ContractNumber)).ToList();
                    var gDocs = docs.Where(d => gNumbers.Contains(d.ContractNumber)).ToList();

                    FillBranchSummaryRow(selectedFields, row, branchName, gContracts, gPayments, gExpenses, gDocs);
                    dt.Rows.Add(row);
                }

                if (IncludeTotalsRow && dt.Rows.Count > 0)
                    AddTotalsRow(dt, selectedFields, label: "الإجمالي");
            }
            else
            {
                // ContractDetailed
                foreach (var c in contractList.OrderBy(x => x.EndDate))
                {
                    var row = dt.NewRow();

                    var cPayments = payments.Where(p => p.ContractId == c.Id).ToList();
                    var cExpenses = expenses.Where(e => e.ContractNumber == c.ContractNumber).ToList();
                    var cDocs = docs.Where(d => d.ContractNumber == c.ContractNumber).ToList();

                    FillContractRow(selectedFields, row, c, cPayments, cExpenses, cDocs);
                    dt.Rows.Add(row);
                }

                if (IncludeTotalsRow && dt.Rows.Count > 0)
                    AddTotalsRow(dt, selectedFields, label: "الإجمالي");
            }

            return dt;
        }

        // ===== Row Fillers =====
        private void FillContractRow(List<string> selectedFields, DataRow row,
            LeaseContract c, List<Payment> payments, List<FinancialExpense> expenses, List<Document> docs)
        {
            decimal paid = payments.Where(p => p.IsPaid).Sum(p => p.Amount);
            decimal unpaid = payments.Where(p => !p.IsPaid).Sum(p => p.Amount);
            decimal exp = expenses.Sum(e => e.Amount + e.TaxAmount);

            int docsCount = docs.Count;
            int docsExpiring30 = docs.Count(d => d.ExpiryDate.HasValue && (d.ExpiryDate.Value.Date - DateTime.Today).TotalDays <= 30 && (d.ExpiryDate.Value.Date - DateTime.Today).TotalDays >= 0);
            int docsExpired = docs.Count(d => d.ExpiryDate.HasValue && d.ExpiryDate.Value.Date < DateTime.Today);

            foreach (var key in selectedFields)
            {
                var col = FieldToColumnName(key);
                if (!row.Table.Columns.Contains(col)) continue;

                row[col] = key switch
                {
                    // Branch / Contract
                    "BranchName" => c.BranchName ?? "",
                    "ContractNumber" => c.ContractNumber ?? "",
                    "LessorName" => c.LessorName ?? "",
                    "TenantName" => c.TenantName ?? "",
                    "StartDate" => c.StartDate.ToString("yyyy-MM-dd"),
                    "EndDate" => c.EndDate.ToString("yyyy-MM-dd"),
                    "ContractStatus" => c.Status ?? "",
                    "PaymentFrequency" => c.PaymentFrequency ?? "",
                    "ElectricityAccount" => c.ElectricityAccountNumber ?? "",
                    "WaterAccount" => c.WaterAccountNumber ?? "",
                    "InstallmentsCount" => c.InstallmentsCount,

                    // Contract amounts
                    "RentBeforeTax" => c.AmountBeforeTax,
                    "RentVat" => c.VatAmount,
                    "AdditionalFixed" => c.AdditionalFixedAmounts,
                    "RentTotal" => (c.AmountBeforeTax + c.VatAmount + c.AdditionalFixedAmounts),

                    // Payments aggregates
                    "PaidSum" => paid,
                    "UnpaidSum" => unpaid,
                    "NetAfterExpenses" => (paid - exp),

                    // Expenses aggregates
                    "ExpensesSum" => exp,

                    // Docs aggregates
                    "DocsCount" => docsCount,
                    "DocsExpiring30" => docsExpiring30,
                    "DocsExpired" => docsExpired,

                    // Flags
                    "HasPaymentAttachment" => payments.Any(p => !string.IsNullOrWhiteSpace(p.AttachmentPath)) ? "نعم" : "لا",
                    "HasExpenseAttachment" => expenses.Any(e => !string.IsNullOrWhiteSpace(e.AttachmentPath)) ? "نعم" : "لا",
                    "HasDocFile" => docs.Any(d => !string.IsNullOrWhiteSpace(d.FilePath)) ? "نعم" : "لا",

                    _ => ""
                };
            }
        }

        private void FillBranchSummaryRow(List<string> selectedFields, DataRow row,
            string branchName, List<LeaseContract> contracts, List<Payment> payments, List<FinancialExpense> expenses, List<Document> docs)
        {
            decimal paid = payments.Where(p => p.IsPaid).Sum(p => p.Amount);
            decimal unpaid = payments.Where(p => !p.IsPaid).Sum(p => p.Amount);
            decimal exp = expenses.Sum(e => e.Amount + e.TaxAmount);

            int contractsCount = contracts.Count;
            int expiringContracts30 = contracts.Count(c => c.EndDate >= DateTime.Today && c.EndDate <= DateTime.Today.AddDays(30));
            int expiredContracts = contracts.Count(c => c.EndDate < DateTime.Today);

            int docsCount = docs.Count;
            int docsExpiring30 = docs.Count(d => d.ExpiryDate.HasValue && (d.ExpiryDate.Value.Date - DateTime.Today).TotalDays <= 30 && (d.ExpiryDate.Value.Date - DateTime.Today).TotalDays >= 0);

            foreach (var key in selectedFields)
            {
                var col = FieldToColumnName(key);
                if (!row.Table.Columns.Contains(col)) continue;

                row[col] = key switch
                {
                    "BranchName" => branchName,

                    "ContractsCount" => contractsCount,
                    "ContractsExpiring30" => expiringContracts30,
                    "ContractsExpired" => expiredContracts,

                    "PaidSum" => paid,
                    "UnpaidSum" => unpaid,
                    "ExpensesSum" => exp,
                    "NetAfterExpenses" => (paid - exp),

                    "DocsCount" => docsCount,
                    "DocsExpiring30" => docsExpiring30,

                    _ => ""
                };
            }
        }

        // ===== Totals row =====
        private void AddTotalsRow(DataTable dt, List<string> selectedFields, string label)
        {
            var r = dt.NewRow();

            // ضع اللابل في أول عمود نصي موجود
            if (dt.Columns.Count > 0)
                r[0] = label;

            // اجمع أعمدة رقمية فقط
            for (int c = 0; c < dt.Columns.Count; c++)
            {
                decimal sum = 0;
                bool numeric = false;

                foreach (DataRow row in dt.Rows)
                {
                    var val = row[c];
                    if (val == null) continue;

                    if (val is int i) { sum += i; numeric = true; }
                    else if (val is long l) { sum += l; numeric = true; }
                    else if (val is decimal d) { sum += d; numeric = true; }
                    else if (decimal.TryParse(Convert.ToString(val), out var parsed))
                    {
                        // لو العمود كله أرقام في الغالب
                        sum += parsed;
                        numeric = true;
                    }
                }

                if (numeric)
                    r[c] = sum;
            }

            dt.Rows.Add(r);
        }

        // ===== Field definitions =====
        private List<ReportFieldOption> BuildAllFields()
        {
            // Key -> will be used internally, DisplayName -> column header
            return new List<ReportFieldOption>
            {
                // === Contracts (Detailed & Summary) ===
                new ReportFieldOption("BranchName", "الفرع", "عقود", true),
                new ReportFieldOption("ContractNumber", "رقم العقد", "عقود", true),
                new ReportFieldOption("LessorName", "المؤجر", "عقود"),
                new ReportFieldOption("TenantName", "المستأجر", "عقود"),
                new ReportFieldOption("StartDate", "بداية العقد", "عقود"),
                new ReportFieldOption("EndDate", "نهاية العقد", "عقود", true),
                new ReportFieldOption("ContractStatus", "حالة العقد", "عقود"),
                new ReportFieldOption("PaymentFrequency", "دورية الدفع", "عقود"),
                new ReportFieldOption("ElectricityAccount", "رقم الكهرباء", "عقود"),
                new ReportFieldOption("WaterAccount", "رقم المياه", "عقود"),
                new ReportFieldOption("InstallmentsCount", "عدد الدفعات", "عقود"),

                // Amounts
                new ReportFieldOption("RentBeforeTax", "قيمة الإيجار قبل الضريبة", "مالية"),
                new ReportFieldOption("RentVat", "قيمة الضريبة", "مالية"),
                new ReportFieldOption("AdditionalFixed", "مبالغ ثابتة إضافية", "مالية"),
                new ReportFieldOption("RentTotal", "إجمالي الإيجار", "مالية", true),

                // === Payments aggregates ===
                new ReportFieldOption("PaidSum", "إجمالي المسدد", "المدفوعات", true),
                new ReportFieldOption("UnpaidSum", "إجمالي غير المسدد", "المدفوعات", true),
                new ReportFieldOption("HasPaymentAttachment", "مرفقات دفعات", "المدفوعات"),

                // === Expenses aggregates ===
                new ReportFieldOption("ExpensesSum", "إجمالي المصاريف", "المصاريف", true),
                new ReportFieldOption("HasExpenseAttachment", "مرفقات مصاريف", "المصاريف"),

                // === Docs aggregates ===
                new ReportFieldOption("DocsCount", "عدد المستندات", "المستندات", true),
                new ReportFieldOption("DocsExpiring30", "قرب الانتهاء (30 يوم)", "المستندات", true),
                new ReportFieldOption("DocsExpired", "منتهي", "المستندات"),
                new ReportFieldOption("HasDocFile", "ملفات أرشفة موجودة", "المستندات"),

                // === Net ===
                new ReportFieldOption("NetAfterExpenses", "الصافي المالي", "مالية", true),

                // === Branch summary extras ===
                new ReportFieldOption("ContractsCount", "عدد العقود", "ملخص الفرع", true),
                new ReportFieldOption("ContractsExpiring30", "عقود قرب الانتهاء (30 يوم)", "ملخص الفرع"),
                new ReportFieldOption("ContractsExpired", "عقود منتهية", "ملخص الفرع"),
            };
        }

        private string FieldToColumnName(string key)
        {
            // DisplayName mapping
            var f = Fields.FirstOrDefault(x => x.Key == key);
            return f?.DisplayName ?? key;
        }

        // ===== Fields filter =====
        private bool FieldsFilter(object obj)
        {
            if (obj is not ReportFieldOption f) return true;
            if (string.IsNullOrWhiteSpace(FieldsSearchText)) return true;

            var s = FieldsSearchText.Trim();
            return (f.DisplayName?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false)
                || (f.Group?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false);
        }

        private void Field_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ReportFieldOption.IsSelected))
                Refresh();
        }

        private void ClearFields()
        {
            foreach (var f in Fields) f.IsSelected = false;
            Refresh();
        }

        private void ApplyPreset(string preset)
        {
            // turn off all first
            foreach (var f in Fields) f.IsSelected = false;

            if (preset == "FULL")
            {
                SelectKeys("BranchName", "ContractNumber", "EndDate", "RentTotal", "PaidSum", "UnpaidSum", "ExpensesSum", "DocsCount", "DocsExpiring30", "NetAfterExpenses");
            }
            else if (preset == "FINANCE")
            {
                SelectKeys("BranchName", "ContractNumber", "RentTotal", "PaidSum", "UnpaidSum", "ExpensesSum", "NetAfterExpenses");
            }
            else if (preset == "DOCS")
            {
                SelectKeys("BranchName", "ContractNumber", "DocsCount", "DocsExpiring30", "DocsExpired", "HasDocFile");
            }
            else if (preset == "OVERDUE")
            {
                SelectKeys("BranchName", "ContractNumber", "TenantName", "PaidSum", "UnpaidSum", "NetAfterExpenses");
            }

            Refresh();
        }

        private void SelectKeys(params string[] keys)
        {
            foreach (var k in keys)
            {
                var f = Fields.FirstOrDefault(x => x.Key == k);
                if (f != null) f.IsSelected = true;
            }
        }

        // ===== Load branches =====
        private void LoadBranches()
        {
            Branches.Clear();
            Branches.Add("الكل");

            using var db = _dbService.CreateDbContext();

            // prefer Branches table, fallback to Contracts branch names
            var fromBranches = db.Branches.AsNoTracking().Select(b => b.BranchName).ToList();
            if (fromBranches.Count > 0)
            {
                foreach (var b in fromBranches.Distinct().OrderBy(x => x))
                    Branches.Add(b);
                return;
            }

            var fromContracts = db.Contracts.AsNoTracking()
                .Select(c => c.BranchName)
                .Where(x => x != null && x != "")
                .ToList();

            foreach (var b in fromContracts.Distinct().OrderBy(x => x))
                Branches.Add(b);
        }

        // ===== Save/Load state =====
        private void SaveState()
        {
            var selectedKeys = Fields.Where(f => f.IsSelected).Select(f => f.Key).ToList();

            _stateStore.Save(
                StartDate,
                EndDate,
                SelectedBranch ?? "الكل",
                SelectedMode ?? "ContractDetailed",
                IncludeTotalsRow,
                IncludeArchivedDocuments,
                selectedKeys
            );
        }

        private void LoadStateOrDefaults()
        {
            if (_stateStore.TryLoad(out var s, out var e, out var branch, out var mode, out var totals, out var includeArchived, out var keys))
            {
                StartDate = s;
                EndDate = e;
                IncludeTotalsRow = totals;
                IncludeArchivedDocuments = includeArchived;

                if (Branches.Contains(branch)) SelectedBranch = branch;
                else SelectedBranch = "الكل";

                SelectedMode = ReportModes.Contains(mode) ? mode : "ContractDetailed";

                // apply selected field keys
                foreach (var f in Fields) f.IsSelected = keys.Contains(f.Key);
                if (Fields.All(x => !x.IsSelected))
                    ApplyPreset("FULL");

                return;
            }

            // defaults
            StartDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            EndDate = DateTime.Today;
            SelectedBranch = "الكل";
            SelectedMode = "ContractDetailed";
            IncludeTotalsRow = true;
            IncludeArchivedDocuments = false;
            ApplyPreset("FULL");
        }

        // ===== INotifyPropertyChanged =====
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}