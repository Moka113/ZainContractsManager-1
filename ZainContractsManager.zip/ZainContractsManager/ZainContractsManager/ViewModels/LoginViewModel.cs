﻿using System;
using System.Threading.Tasks;
using System.Windows;
using ZainContractsManager.Helpers;
using ZainContractsManager.Services;

namespace ZainContractsManager.ViewModels
{
    public class LoginViewModel : ObservableObject
    {
        private readonly AuthService _auth;

        private string _username = "";
        public string Username { get => _username; set => Set(ref _username, value); }

        private string _password = "";
        public string Password { get => _password; set => Set(ref _password, value); }

        private bool _rememberMe;
        public bool RememberMe { get => _rememberMe; set => Set(ref _rememberMe, value); }

        private bool _isBusy;
        public bool IsBusy { get => _isBusy; set { Set(ref _isBusy, value); LoginCommand.RaiseCanExecuteChanged(); } }

        private string _errorMessage = "";
        public string ErrorMessage { get => _errorMessage; set => Set(ref _errorMessage, value); }

        private bool _showPassword;
        public bool ShowPassword { get => _showPassword; set => Set(ref _showPassword, value); }

        public RelayCommand LoginCommand { get; }
        public RelayCommand OpenRegisterCommand { get; }

        public event Action? LoginSucceeded;
        public event Action? ShakeRequested;

        public LoginViewModel()
        {
            _auth = new AuthService();

            LoginCommand = new RelayCommand(async _ => await DoLogin(), _ => !IsBusy);
            OpenRegisterCommand = new RelayCommand(_ => OpenRegister());
        }

        private async Task DoLogin()
        {
            ErrorMessage = "";
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                ErrorMessage = "اكتب اسم المستخدم وكلمة المرور";
                ShakeRequested?.Invoke();
                return;
            }

            IsBusy = true;
            try
            {
                await Task.Delay(250); // إحساس loading بسيط

                var ok = _auth.ValidateLogin(Username.Trim(), Password);
                if (!ok)
                {
                    ErrorMessage = "بيانات الدخول غير صحيحة";
                    ShakeRequested?.Invoke();
                    return;
                }

                LoginSucceeded?.Invoke();
            }
            finally
            {
                IsBusy = false;
            }
        }

        private void OpenRegister()
        {
            try
            {
                var w = new Views.RegisterWindow(_auth);
                w.Owner = Application.Current.MainWindow;
                w.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                w.ShowDialog();
            }
            catch
            {
                // ignore
            }
        }
    }
}