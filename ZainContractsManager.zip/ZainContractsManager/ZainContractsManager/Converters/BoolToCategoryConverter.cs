﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace ZainContractsManager.Converters
{
    public class BoolToCategoryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool val) return val ? "مستثمر" : "مؤجر";
            return "غير محدد";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}