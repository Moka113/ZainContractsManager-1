﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace ZainContractsManager.Converters
{
    public class StatusToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string status = value as string;
            if (status == "ساري") return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#27ae60"));
            if (status == "منتهي") return new SolidColorBrush((Color)ColorConverter.ConvertFromString("#c0392b"));
            return Brushes.Gray;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotImplementedException();
    }
}