﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models
{
    public enum ContractDirection
    {
        CompanyPays = 0,    // الشركة مستأجر (Cash Out)
        CompanyReceives = 1 // الشركة مؤجر (Cash In)
    }

    public class LeaseContract : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // ✅ Multi-Tenant (Tenant Scope)
        [Required]
        public int CompanyId { get; set; } = 0;

        [Required, MaxLength(100)]
        public string ContractNumber { get; set; } = string.Empty;

        // الأطراف
        [MaxLength(200)]
        public string LessorName { get; set; } = string.Empty;

        [MaxLength(200)]
        public string TenantName { get; set; } = string.Empty;

        // ✅ اتجاه العقد
        public ContractDirection Direction { get; set; } = ContractDirection.CompanyPays;

        // =====================================================
        // ربط الفرع
        // =====================================================
        public int? BranchId { get; set; }

        [ForeignKey(nameof(BranchId))]
        public virtual Branch? Branch { get; set; }

        [MaxLength(200)]
        public string BranchName { get; set; } = string.Empty;

        [MaxLength(100)]
        public string ContractType { get; set; } = string.Empty;

        [MaxLength(50)]
        public string PaymentFrequency { get; set; } = string.Empty;

        // =====================================================
        // تواريخ
        // =====================================================
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public DateTime LastModifiedDate { get; set; } = DateTime.Now;

        [MaxLength(50)]
        public string Status { get; set; } = "Active"; // Active / Expired / Closed ...

        // =====================================================
        // مبالغ (يدوي)
        // =====================================================
        public decimal AmountBeforeTax { get; set; }              // قيمة الإيجار
        public decimal VatAmount { get; set; }                    // الضريبة
        public decimal AdditionalFixedAmounts { get; set; }       // رسوم ثابتة إضافية

        [NotMapped]
        public decimal TotalAmount => AmountBeforeTax + VatAmount + AdditionalFixedAmounts;

        // =====================================================
        // بيانات إضافية
        // =====================================================
        [MaxLength(2000)]
        public string Notes { get; set; } = string.Empty;

        [MaxLength(100)]
        public string ElectricityAccountNumber { get; set; } = string.Empty;

        [MaxLength(100)]
        public string WaterAccountNumber { get; set; } = string.Empty;

        public int InstallmentsCount { get; set; }

        // =====================================================
        // ✅ جاهز للـ Posting Engine
        // =====================================================
        public bool IsPostedToJournal { get; set; } = false;
        public int? JournalEntryId { get; set; }

        // ✅ ربط الدفعات
        public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
    }
}