﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ZainContractsManager.Models
{
    /// <summary>
    /// ميزانية تشغيلية (Budget) لكل فرع/شهر
    /// تستخدم في Budget vs Actual + Variance Analyzer
    /// </summary>
    public class BranchBudget
    {
        [Key]
        public int Id { get; set; }

        // لو عندك BranchId نستخدمه، ولو لأ نستخدم BranchName
        public int? BranchId { get; set; }

        public string BranchName { get; set; } = "";

        /// <summary>
        /// سنة الميزانية
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// شهر الميزانية (1-12)
        /// </summary>
        public int Month { get; set; }

        /// <summary>
        /// نوع الميزانية/التصنيف (OPEX / كهرباء / مياه ...إلخ)
        /// </summary>
        public string Category { get; set; } = "OPEX";

        /// <summary>
        /// مبلغ الميزانية (قبل الضريبة)
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// ضريبة الميزانية إن وجدت (اختياري)
        /// </summary>
        public decimal TaxAmount { get; set; }

        [NotMapped]
        public decimal Total => Amount + TaxAmount;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime? UpdatedAt { get; set; }
    }
}