﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore; // ✅ For [Index]
using ZainContractsManager.Models;   // ✅ Branch
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models.Finance
{
    public enum JournalStatus
    {
        Draft = 0,
        Posted = 1,
        Reversed = 2
    }

    // ✅ SaaS: Unique EntryNo per Company + fast filtering
    [Index(nameof(CompanyId), nameof(EntryNo), IsUnique = true)]
    [Index(nameof(CompanyId), nameof(EntryDate))]
    [Index(nameof(CompanyId), nameof(BranchId))]
    public class JournalEntry : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // =====================================================
        // Multi-Tenant
        // =====================================================
        public int CompanyId { get; set; } = 0;

        // =====================================================
        // Core Identity
        // =====================================================
        [Required, MaxLength(50)]
        public string EntryNo { get; set; } = "";

        public DateTime EntryDate { get; set; } = DateTime.Now;

        [MaxLength(500)]
        public string? Description { get; set; }

        public JournalStatus Status { get; set; } = JournalStatus.Draft;

        // =====================================================
        // Source Tracking (Expense / Payment / Manual / Sales ...)
        // =====================================================
        [MaxLength(50)]
        public string? SourceType { get; set; }

        public int? SourceId { get; set; }

        // =====================================================
        // ✅ Branch Scope (على مستوى القيد)
        // =====================================================
        public int? BranchId { get; set; }

        [ForeignKey(nameof(BranchId))]
        public virtual Branch? Branch { get; set; }

        // Snapshot مفيد للتقارير حتى لو الفرع اتحذف لاحقًا
        [MaxLength(200)]
        public string? BranchName { get; set; }

        // =====================================================
        // Audit & Metadata
        // =====================================================
        [MaxLength(2000)]
        public string? AuditLog { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // =====================================================
        // Navigation
        // =====================================================
        public virtual ICollection<JournalLine> Lines { get; set; } = new List<JournalLine>();

        // =====================================================
        // Helper Properties
        // =====================================================
        [NotMapped]
        public decimal TotalDebit => Lines.Sum(l => l.Debit);

        [NotMapped]
        public decimal TotalCredit => Lines.Sum(l => l.Credit);

        [NotMapped]
        public bool IsBalanced => Math.Abs(TotalDebit - TotalCredit) < 0.0001m;
    }
}