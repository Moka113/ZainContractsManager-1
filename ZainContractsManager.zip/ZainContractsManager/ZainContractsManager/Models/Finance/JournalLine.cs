﻿#nullable enable
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore; // ✅ For Index
using ZainContractsManager.Models;   // ✅ Branch
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models.Finance
{
    // ✅ تحسين الأداء في الفلترة والربط
    [Index(nameof(CompanyId))]
    [Index(nameof(JournalEntryId))]
    [Index(nameof(AccountId))]
    [Index(nameof(BranchId))]
    [Index(nameof(CompanyId), nameof(BranchId))]
    public class JournalLine : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // ✅ Multi-Tenant
        public int CompanyId { get; set; } = 0;

        // =====================================================
        // Journal Header Link
        // =====================================================
        public int JournalEntryId { get; set; }

        [ForeignKey(nameof(JournalEntryId))]
        public virtual JournalEntry? JournalEntry { get; set; }

        // =====================================================
        // Account Link
        // =====================================================
        public int AccountId { get; set; }

        [ForeignKey(nameof(AccountId))]
        public virtual Account? Account { get; set; }

        // =====================================================
        // ✅ Branch Scope (Option C)
        // سطر القيد ممكن يكون مربوط بفرع (مهم للتقارير والتحليل)
        // =====================================================
        public int? BranchId { get; set; }

        [ForeignKey(nameof(BranchId))]
        public virtual Branch? Branch { get; set; }

        // (اختياري) Snapshot للعرض والتقارير حتى لو الفرع اتحذف/اتعدل
        [MaxLength(200)]
        public string? BranchName { get; set; }

        // =====================================================
        // Financial Values
        // =====================================================
        public decimal Debit { get; set; }
        public decimal Credit { get; set; }

        // =====================================================
        // Description
        // =====================================================
        [MaxLength(500)]
        public string? Notes { get; set; }

        // =====================================================
        // Safety Helpers (NotMapped)
        // =====================================================
        [NotMapped]
        public bool IsDebit => Debit > 0;

        [NotMapped]
        public bool IsCredit => Credit > 0;

        [NotMapped]
        public decimal Net => Debit - Credit;
    }
}