﻿#nullable enable
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore; // ✅ Index
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models.Finance
{
    public enum AccountType
    {
        Asset = 1,
        Liability = 2,
        Equity = 3,
        Revenue = 4,
        Expense = 5
    }

    // ✅ Performance indexes
    [Index(nameof(CompanyId))]
    [Index(nameof(CompanyId), nameof(Code), IsUnique = true)]
    [Index(nameof(CompanyId), nameof(ParentId))]
    [Index(nameof(Name))]
    public class Account : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // ✅ Multi-Tenant
        public int CompanyId { get; set; } = 0;

        // =========================
        // Core identity
        // =========================
        [Required, MaxLength(50)]
        public string Code { get; set; } = string.Empty;

        [Required, MaxLength(200)]
        public string Name { get; set; } = string.Empty;

        public AccountType Type { get; set; } = AccountType.Asset;

        // =========================
        // Tree
        // =========================
        public int? ParentId { get; set; }

        [ForeignKey(nameof(ParentId))]
        public virtual Account? Parent { get; set; }

        public virtual ICollection<Account> Children { get; set; } = new List<Account>();

        // =========================
        // Optional branch bind
        // =========================
        public int? BranchId { get; set; }

        [MaxLength(200)]
        public string? BranchName { get; set; }

        // =========================
        // Flags
        // =========================
        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // =========================
        // Helper properties (UI/Reports)
        // =========================
        [NotMapped]
        public bool IsRoot => ParentId == null;

        // مفيد جداً في الـ TreeView والـ UI
        [NotMapped]
        public string Display => $"{Code} - {Name}";

        // لو حبيت تعرض اسم الفرع على الحساب
        [NotMapped]
        public string DisplayWithBranch =>
            string.IsNullOrWhiteSpace(BranchName) ? Display : $"{Display} ({BranchName})";
    }
}