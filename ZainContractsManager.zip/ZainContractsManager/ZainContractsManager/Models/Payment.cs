﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZainContractsManager.Models.SaaS;
using ZainContractsManager.Models.Finance;

namespace ZainContractsManager.Models
{
    public class Payment : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // =====================================================
        // ✅ Multi-Tenant (Tenant Scope)
        // =====================================================
        public int CompanyId { get; set; } = 0;

        // =====================================================
        // Relationship: Payment -> Contract
        // =====================================================
        public int ContractId { get; set; }

        [ForeignKey(nameof(ContractId))]
        public virtual LeaseContract? Contract { get; set; }

        // =====================================================
        // Money & Dates
        // =====================================================
        public decimal Amount { get; set; }

        public DateTime DueDate { get; set; }

        // =====================================================
        // Payment Status
        // =====================================================
        public bool IsPaid { get; set; } = false;

        public DateTime? PaidAt { get; set; }

        // =====================================================
        // Direction (Incoming / Outgoing)
        // =====================================================
        public PaymentDirection Direction { get; set; } = PaymentDirection.Incoming;

        // =====================================================
        // Classification
        // =====================================================
        public string? Category { get; set; }

        // =====================================================
        // Meta Data
        // =====================================================
        public string? PaymentMethod { get; set; }
        public string? ReferenceNo { get; set; }
        public string? Notes { get; set; }
        public string? AttachmentPath { get; set; }

        public string? AuditLog { get; set; }

        // =====================================================
        // ✅ Finance Engine Integration
        // =====================================================
        public bool IsPostedToJournal { get; set; } = false;

        public int? JournalEntryId { get; set; }

        [ForeignKey(nameof(JournalEntryId))]
        public JournalEntry? JournalEntry { get; set; }

        public DateTime? PostedAt { get; set; }
    }
}