﻿#nullable enable
using System.Collections.Generic;
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models
{
    public class User
    {
        public int Id { get; set; }

        // بيانات تسجيل الدخول
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;

        // الدور العام (Global Role)
        public string Role { get; set; } = "Admin";

        // صلاحيات أساسية (ممكن نطورها لاحقًا لنظام Permissions احترافي)
        public bool CanEditContracts { get; set; } = true;
        public bool CanViewFinancials { get; set; } = true;
        public bool CanExportExcel { get; set; } = true;

        // 🔥 SaaS: علاقة المستخدم بالشركات
        public List<CompanyUser> CompanyUsers { get; set; } = new();
    }
}