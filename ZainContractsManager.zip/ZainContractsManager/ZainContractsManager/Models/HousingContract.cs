﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ZainContractsManager.Models
{
    public class HousingContract
    {
        [Key]
        public int Id { get; set; }
        public string TenantName { get; set; }
        public string BranchName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string ContractPdfPath { get; set; }
    }
}