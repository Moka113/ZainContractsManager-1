﻿#nullable enable
using System;

namespace ZainContractsManager.Models.Settings
{
    public class AppSetting
    {
        public int Id { get; set; }

        public string Key { get; set; } = string.Empty;

        public string Value { get; set; } = string.Empty;

        public string? Description { get; set; }

        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}