﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore; // ✅ Index
using ZainContractsManager.Models.SaaS; // ✅ ICompanyScoped

namespace ZainContractsManager.Models
{
    [Index(nameof(CompanyId))]
    [Index(nameof(CompanyId), nameof(ExpiryDate))]
    public class Document : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // ✅ Multi-Tenant (مهم جداً لمنع تسريب البيانات بين الشركات)
        public int CompanyId { get; set; } = 0;

        // (اختياري) ربط مباشر بالعقد لو حابب لاحقاً
        public int? ContractId { get; set; }

        // ✅ (اختياري) Navigation للعقد — لو مش محتاجه الآن، ممكن تشيلها
        // [ForeignKey(nameof(ContractId))]
        // public virtual LeaseContract? Contract { get; set; }

        // بيانات تعريفية
        public string? ContractNumber { get; set; }
        public string? DocumentType { get; set; } // مثال: عقد إيجار، رخصة، صيانة
        public string? TenantName { get; set; }
        public string? LessorName { get; set; }
        public string? BranchName { get; set; }

        public DateTime? ExpiryDate { get; set; }
        public string? FilePath { get; set; }
        public string? Notes { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // --- الحقول المالية لدعم الـ Dashboard ---
        public decimal TotalAmount { get; set; } = 0m;
        public decimal VatAmount { get; set; } = 0m;
        public string? PaymentFrequency { get; set; }

        // --- خصائص الأرشفة ---
        public bool IsArchived { get; set; } = false;

        // ✅ ProviderName (متوافق مع تقارير قديمة) — نفس LessorName
        public string? ProviderName
        {
            get => LessorName;
            set => LessorName = value;
        }

        public bool IsArchivedVersion { get; set; } = false;

        // ⚠️ الاسم ده مربك (داخل Document) لكنه متروك لتوافق الكود الحالي
        public int? ParentContractId { get; set; }

        public string? AuditLog { get; set; }

        // ===== محسوبات =====
        [NotMapped]
        public string Status
        {
            get
            {
                if (!ExpiryDate.HasValue) return "غير محدد";
                var remainingDays = (ExpiryDate.Value.Date - DateTime.Today).TotalDays;

                if (remainingDays < 0) return "منتهي";
                if (remainingDays <= 30) return "قرب الانتهاء";
                return "ساري";
            }
        }

        [NotMapped]
        public decimal BaseAmount => TotalAmount - VatAmount;
    }
}