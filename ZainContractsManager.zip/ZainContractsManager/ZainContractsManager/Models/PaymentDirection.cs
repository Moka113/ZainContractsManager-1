﻿namespace ZainContractsManager.Models
{
    /// <summary>
    /// Incoming = تحصيل
    /// Outgoing = سداد
    /// </summary>
    public enum PaymentDirection
    {
        Incoming = 1,
        Outgoing = 2
    }
}