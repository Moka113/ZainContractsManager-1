﻿using System.Collections.Generic;

namespace ZainContractsManager.Models
{
    public class Asset
    {
        public int Id { get; set; }
        public string Name { get; set; } // اسم الفرع مثلاً B1
        public string Type { get; set; } // درايف ثرو، جلسات، إلخ
        public string Location { get; set; }
        public virtual ICollection<LeaseContract> Contracts { get; set; }
    }
}