﻿#nullable enable
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZainContractsManager.Models.Finance;
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Models
{
    /// <summary>
    /// مصروف تشغيلي / فاتورة مورد
    /// جاهز للـ SaaS + Posting Engine + VAT + Budget Engine
    /// </summary>
    public class FinancialExpense : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // =====================================================
        // ✅ Multi-Tenant
        // =====================================================
        [Required]
        public int CompanyId { get; set; } = 0;

        // =====================================================
        // بيانات أساسية
        // =====================================================
        [Required, MaxLength(50)]
        public string ExpenseNumber { get; set; } = "";

        [MaxLength(100)]
        public string InvoiceNumber { get; set; } = "";

        public DateTime InvoiceDate { get; set; } = DateTime.Now;

        public DateTime ExpenseDate { get; set; } = DateTime.Now;

        // =====================================================
        // ربط الفرع
        // =====================================================
        public int? BranchId { get; set; }

        [ForeignKey(nameof(BranchId))]
        public Branch? Branch { get; set; }

        [MaxLength(200)]
        public string BranchName { get; set; } = "";

        // =====================================================
        // ربط عقد (اختياري)
        // =====================================================
        [MaxLength(100)]
        public string ContractNumber { get; set; } = ""; // ✅ non-nullable لتفادي لخبطة null

        // =====================================================
        // التصنيف (Budget / Reporting)
        // =====================================================
        [MaxLength(100)]
        public string Category { get; set; } = "عام"; // ✅ Default محترم بدل ""

        // =====================================================
        // المبالغ
        // =====================================================
        public decimal Amount { get; set; }      // صافي
        public decimal TaxAmount { get; set; }   // ضريبة

        [NotMapped]
        public decimal TotalAmount => Amount + TaxAmount;

        // aliases (اختياريين للواجهات القديمة)
        [NotMapped] public decimal Total => TotalAmount;
        [NotMapped] public decimal GrandTotal => TotalAmount;

        // =====================================================
        // وصف + مرفقات
        // =====================================================
        [MaxLength(1000)]
        public string Description { get; set; } = "";

        public string? AttachmentPath { get; set; }

        // =====================================================
        // حالة الدفع
        // =====================================================
        public bool IsPaid { get; set; }

        public DateTime? PaidAt { get; set; }

        [MaxLength(50)]
        public string? PaymentMethod { get; set; }

        [MaxLength(100)]
        public string? ReferenceNo { get; set; }

        // =====================================================
        // ✅ Posting Engine Integration
        // =====================================================
        public bool IsPostedToJournal { get; set; } = false;

        public int? JournalEntryId { get; set; }

        [ForeignKey(nameof(JournalEntryId))]
        public JournalEntry? JournalEntry { get; set; }

        public DateTime? PostedAt { get; set; }

        // =====================================================
        // Audit Trail
        // =====================================================
        public string? AuditLog { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}