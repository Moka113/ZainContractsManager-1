﻿#nullable enable
using System;

namespace ZainContractsManager.Models.FinanceEngine
{
    public class FinancialSummary
    {
        public decimal TotalContractsValue { get; set; }

        public decimal TotalPaid { get; set; }

        public decimal TotalExpenses { get; set; }

        public decimal RemainingReceivables { get; set; }

        public decimal NetCashFlow { get; set; }

        public int ActiveContracts { get; set; }

        public DateTime GeneratedAt { get; set; } = DateTime.Now;
    }
}