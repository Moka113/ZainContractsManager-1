﻿#nullable enable
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ZainContractsManager.Models.SaaS; // ✅ ICompanyScoped

namespace ZainContractsManager.Models
{
    public class Branch : ICompanyScoped
    {
        [Key]
        public int Id { get; set; }

        // ✅ Multi-Tenant
        public int CompanyId { get; set; } = 0;

        [Required]
        public string BranchName { get; set; } = string.Empty; // الاسم المعتمد لديك

        public string? Location { get; set; }

        // ✅ Alias لتوافق أي Bindings/Code قديم بيستخدم Name بدل BranchName
        [NotMapped]
        public string Name => BranchName;
    }
}