﻿#nullable enable
namespace ZainContractsManager.Models.SaaS
{
    // أي جدول لازم يتفلتر حسب الشركة (Tenant)
    public interface ICompanyScoped
    {
        int CompanyId { get; set; }
    }
}