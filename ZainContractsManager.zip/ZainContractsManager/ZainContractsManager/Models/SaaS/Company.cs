﻿#nullable enable
using System;
using System.Collections.Generic;

namespace ZainContractsManager.Models.SaaS
{
    public class Company
    {
        public int Id { get; set; }

        // كود فريد للشركة (يتولد عند الإنشاء فقط)
        public string Code { get; set; } = string.Empty;

        public string Name { get; set; } = string.Empty;

        // بيانات ضريبية (ZATCA)
        public string? TaxNumber { get; set; }

        // بيانات عنوان (اختياري)
        public string? Country { get; set; }
        public string? City { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // علاقة Users
        public List<CompanyUser> Users { get; set; } = new();

        // ===============================
        // Factory Method (أفضل طريقة لإنشاء شركة)
        // ===============================
        public static Company Create(string name)
        {
            return new Company
            {
                Name = name,
                Code = GenerateCode(),
                CreatedAt = DateTime.UtcNow
            };
        }

        private static string GenerateCode()
        {
            return Guid.NewGuid()
                .ToString("N")
                .Substring(0, 10)
                .ToUpperInvariant();
        }
    }
}