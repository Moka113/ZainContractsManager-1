﻿#nullable enable
using System;
using ZainContractsManager.Models;

namespace ZainContractsManager.Models.SaaS
{
    // جدول ربط Many-to-Many بين User و Company
    public class CompanyUser
    {
        public int Id { get; set; }

        // ===============================
        // Foreign Keys
        // ===============================
        public int CompanyId { get; set; }
        public Company? Company { get; set; }   // nullable لتجنب تحذيرات EF

        public int UserId { get; set; }
        public User? User { get; set; }         // nullable لتجنب تحذيرات EF

        // ===============================
        // Role inside company
        // ===============================
        public string Role { get; set; } = "Owner";

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}