﻿#nullable disable // تعطيل التحذيرات ليتوافق مع إعدادات المشروع التي ضبطناها
// iText7
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using Microsoft.Win32;
using OfficeOpenXml;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

using ZainContractsManager.AI_Module;
using ZainContractsManager.Data;                 // ✅ AppDbContext
using ZainContractsManager.Services.Settings;     // ✅ Settings Engine
using ZainContractsManager.Views;
using ZainContractsManager.Views.Finance;         // ✅ Financial Engine Views
using WpfBorder = System.Windows.Controls.Border;

namespace ZainContractsManager
{
    public partial class MainWindow : Window
    {
        private bool _isDark = true;

        // ✅ Settings Engine
        private readonly SettingsService _settings = new SettingsService();

        // AI Core
        private readonly OllamaClient _aiClient = new OllamaClient();
        private CancellationTokenSource _aiCts;

        // ملف PDF المرفق قبل التحليل
        private string _pendingFilePath;

        public MainWindow()
        {
            InitializeComponent();

            // ✅ EPPlus License
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            // ✅ لازم شركة (Safe-by-default بعد تعديل Global Filter)
            if (!EnsureCompanyContextIsSet())
            {
                // رجّع المستخدم للّوجن بدل ما نكمل ببيانات غلط/فاضية
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var login = new LoginWindow();
                        login.Show();
                    }
                    catch { }
                    finally
                    {
                        Close();
                    }
                }));
                return;
            }

            // ✅ اقرأ الثيم من الإعدادات وطبقه مرة واحدة عند التشغيل
            _isDark = _settings.GetBool("ui.darkMode", true);
            ApplyTheme(_isDark);

            // صفحة البداية
            MainContentHost.Content = new ContractsView();

            // ✅ اقفل قسم المالية افتراضياً عند بداية البرنامج
            SetFinanceMenuExpanded(false);

            // Enter يرسل / Shift+Enter سطر جديد
            txtGlobalAIInput.PreviewKeyDown += TxtGlobalAIInput_PreviewKeyDown;

            // الشات LTR داخلياً
            aiChatPanel.FlowDirection = FlowDirection.LeftToRight;

            // Drag & Drop
            AllowDrop = true;
            Drop += MainWindow_Drop;
        }

        // ========================= Tenant Helpers =========================
        private int GetCurrentCompanyId()
        {
            try
            {
                if (Application.Current?.Properties == null) return 0;

                if (Application.Current.Properties.Contains("CurrentCompanyId"))
                {
                    var v = Application.Current.Properties["CurrentCompanyId"];
                    if (v != null && int.TryParse(v.ToString(), out var cid))
                        return cid;
                }
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// ✅ Safe: لا تعمل fallback لأول شركة.
        /// لازم CurrentCompanyId يكون موجود وصالح ( > 0 ) وإلا نرجع للّوجن.
        /// </summary>
        private bool EnsureCompanyContextIsSet()
        {
            try
            {
                if (Application.Current?.Properties == null) return false;

                var cid = GetCurrentCompanyId();
                if (cid <= 0)
                {
                    MessageBox.Show(
                        "لا يمكن فتح النظام بدون اختيار شركة.\nمن فضلك سجّل الدخول واختر الشركة أولاً.",
                        "ZAIN SYSTEM",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning);

                    return false;
                }

                Debug.WriteLine($"[Tenant] CurrentCompanyId={cid}");
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// ✅ يساعد الصفحات (Dashboard خاصة) التي تعتمد على static CurrentCompanyId
        /// </summary>
        private void SyncTenantToViews()
        {
            try
            {
                var cid = GetCurrentCompanyId();
                if (cid > 0)
                {
                    DashboardView.CurrentCompanyId = cid;
                }
            }
            catch { }
        }

        // ========================= Navigation =========================
        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not RadioButton btn || btn.Tag == null) return;

            // ✅ تأكد إن الشركة لسه موجودة (لو حد مسح الـ props بالغلط)
            if (!EnsureCompanyContextIsSet()) return;

            string tag = btn.Tag.ToString() ?? "";

            // ✅ عنوان لطيف بدل الإيموجي
            if (txtPageTitle != null)
                txtPageTitle.Text = GetPageTitle(tag, btn.Content?.ToString());

            // ✅ افتح/اقفل قسم المالية تلقائياً حسب الصفحة
            AutoToggleFinanceSection(tag);

            try
            {
                // ✅ Sync tenant قبل فتح Views
                SyncTenantToViews();

                switch (tag)
                {
                    case "Dashboard": MainContentHost.Content = new DashboardView(); break;
                    case "Contracts": MainContentHost.Content = new ContractsView(); break;
                    case "Payments": MainContentHost.Content = new PaymentsView(); break;
                    case "Docs": MainContentHost.Content = new DocumentsView(); break;
                    case "Expenses": MainContentHost.Content = new ExpensesView(); break;
                    case "Reports": MainContentHost.Content = new ReportsView(); break;
                    case "Settings": MainContentHost.Content = new SettingsView(); break;

                    // =================== Financial Engine ===================
                    case "JE": MainContentHost.Content = new JournalEntriesView(); break;
                    case "Ledger": MainContentHost.Content = new LedgerView(); break;
                    case "Trial": MainContentHost.Content = new TrialBalanceView(); break;
                    case "Accounts": MainContentHost.Content = new AccountsView(); break;
                    // ========================================================

                    default: MainContentHost.Content = new ContractsView(); break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "خطأ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsFinanceTag(string tag)
        {
            return tag == "JE" || tag == "Ledger" || tag == "Trial" || tag == "Accounts";
        }

        private void AutoToggleFinanceSection(string tag)
        {
            bool expand = IsFinanceTag(tag);
            SetFinanceMenuExpanded(expand);
        }

        private void SetFinanceMenuExpanded(bool expanded)
        {
            try
            {
                if (FinanceExpander != null)
                    FinanceExpander.IsExpanded = expanded;
            }
            catch { }
        }

        private string GetPageTitle(string tag, string fallback)
        {
            return tag switch
            {
                "Dashboard" => "لوحة التحكم",
                "Contracts" => "عقود الإيجار",
                "Payments" => "إدارة الدفعات",
                "Docs" => "المستندات والأرشفة",
                "Expenses" => "سجل المصاريف",
                "Reports" => "التقارير المالية",
                "Settings" => "الإعدادات",
                "JE" => "المحرك المالي | القيود اليومية",
                "Ledger" => "المحرك المالي | دفتر الأستاذ",
                "Trial" => "المحرك المالي | ميزان المراجعة",
                "Accounts" => "المحرك المالي | شجرة الحسابات",
                _ => string.IsNullOrWhiteSpace(fallback) ? "ZAIN SYSTEM" : fallback
            };
        }

        // ========================= Theme Toggle =========================
        private void ThemeToggle_Click(object sender, RoutedEventArgs e)
        {
            _isDark = !_isDark;
            ApplyTheme(_isDark);
            _settings.SetBool("ui.darkMode", _isDark, "تفعيل الوضع الداكن");
        }

        private void ApplyTheme(bool isDark)
        {
            var dicts = Application.Current.Resources.MergedDictionaries;
            var currentTheme = dicts.FirstOrDefault(d =>
                d.Source != null &&
                (d.Source.OriginalString.Contains("Colors.Light.xaml") ||
                 d.Source.OriginalString.Contains("Colors.Dark.xaml")));

            if (currentTheme != null)
                dicts.Remove(currentTheme);

            string themePath = isDark ? "Resources/Colors.Dark.xaml" : "Resources/Colors.Light.xaml";

            try
            {
                dicts.Add(new ResourceDictionary { Source = new Uri(themePath, UriKind.Relative) });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Theme Error: {ex.Message}");
            }
        }

        // ========================= Logout =========================
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            CancelAiIfRunning();
            if (MessageBox.Show("هل أنت متأكد من تسجيل الخروج؟", "تأكيد", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        // ========================= AI Sidebar =========================
        private void btnOpenAI_Click(object sender, RoutedEventArgs e)
        {
            GlobalAISidebar.Visibility = Visibility.Visible;
            txtGlobalAIInput.Focus();
        }

        private void btnCloseAI_Click(object sender, RoutedEventArgs e)
        {
            CancelAiIfRunning();
            GlobalAISidebar.Visibility = Visibility.Collapsed;
        }

        private void TxtGlobalAIInput_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) return;
                e.Handled = true;
                btnSendGlobalAI_Click(sender, e);
            }
            else if (e.Key == Key.Escape)
            {
                CancelAiIfRunning();
            }
        }

        private void btnUploadPdf_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog { Filter = "PDF Files (*.pdf)|*.pdf", Title = "اختر ملف عقد PDF للتحليل" };
            if (ofd.ShowDialog() == true)
            {
                _pendingFilePath = ofd.FileName;
                AddChatBubble("System", $"📎 تم إرفاق: {Path.GetFileName(_pendingFilePath)}", isUser: false);
            }
        }

        private void MainWindow_Drop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;
            var files = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (files != null && files.Length > 0)
            {
                string file = files[0];
                if (Path.GetExtension(file).Equals(".pdf", StringComparison.OrdinalIgnoreCase))
                {
                    _pendingFilePath = file;
                    AddChatBubble("System", $"📎 تم إرفاق: {Path.GetFileName(_pendingFilePath)}", isUser: false);
                }
            }
        }

        private async void btnSendGlobalAI_Click(object sender, RoutedEventArgs e)
        {
            // ✅ تأكد من الـ tenant قبل أي context build
            if (!EnsureCompanyContextIsSet()) return;

            string userQuestion = (txtGlobalAIInput.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(userQuestion) && _pendingFilePath == null) return;

            CancelAiIfRunning();
            _aiCts = new CancellationTokenSource();

            AddChatBubble("You", string.IsNullOrWhiteSpace(userQuestion) ? "تحليل العقد المرفق" : userQuestion, isUser: true);
            txtGlobalAIInput.Clear();
            SetAiUiBusy(true);

            var aiMessageTextBlock = CreateEmptyBubbleForAI(out var aiStatusText);
            aiStatusText.Text = "Typing…";

            try
            {
                string prompt;
                if (_pendingFilePath != null)
                {
                    string filePath = _pendingFilePath;
                    _pendingFilePath = null;
                    aiStatusText.Text = "Extracting PDF…";
                    string extractedText = await ExtractTextFromPdf_iText7(filePath);

                    if (string.IsNullOrWhiteSpace(extractedText))
                    {
                        aiStatusText.Text = "Error";
                        aiMessageTextBlock.Text = "مش قادر أقرأ نص الـ PDF. لو الملف صورة (Scan) لازم OCR.";
                        return;
                    }

                    prompt = $@"أنت محلل عقود قانوني محترف. استخرج الأطراف والتواريخ والمالية والشروط الجزائية.
نص العقد:
{extractedText}
سؤال المستخدم: {userQuestion}";
                }
                else
                {
                    var pageTitle = txtPageTitle?.Text ?? "غير محدد";
                    string dbContext = "";
                    try
                    {
                        dbContext = await ZainContextBuilder.BuildGlobalContextAsync(new ZainContextBuilder.ContextOptions
                        {
                            MaxChars = 6500,
                            TopRows = 8,
                            Question = userQuestion
                        });
                    }
                    catch (Exception ex) { dbContext = $"[DB Context Error]\n{ex.Message}"; }
                    prompt = ZainAiGuardrails.BuildFullPrompt(pageTitle, dbContext, userQuestion);
                }

                await RunAiInference(prompt, aiMessageTextBlock, aiStatusText);
            }
            finally
            {
                SetAiUiBusy(false);
            }
        }

        private async Task RunAiInference(string prompt, TextBlock textBlock, TextBlock statusBlock)
        {
            try
            {
                await _aiClient.AskZainAIStream(prompt, token =>
                {
                    if (_aiCts?.IsCancellationRequested == true) return;
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        textBlock.Text += token;
                        aiScroll.ScrollToEnd();
                    }));
                }, _aiCts.Token);
                statusBlock.Text = "Done";
            }
            catch (Exception ex)
            {
                statusBlock.Text = "Error";
                textBlock.Text += $"\n\n🛑 Error: {ex.Message}";
            }
        }

        private void SetAiUiBusy(bool busy)
        {
            txtGlobalAIInput.IsEnabled = !busy;
        }

        private void CancelAiIfRunning()
        {
            try
            {
                if (_aiCts != null && !_aiCts.IsCancellationRequested)
                    _aiCts.Cancel();
            }
            catch { }
            finally
            {
                _aiCts?.Dispose();
                _aiCts = null;
            }
        }

        private Task<string> ExtractTextFromPdf_iText7(string filePath)
        {
            return Task.Run(() =>
            {
                try
                {
                    var sb = new StringBuilder();
                    using var reader = new PdfReader(filePath);
                    using var pdf = new PdfDocument(reader);
                    for (int i = 1; i <= pdf.GetNumberOfPages(); i++)
                    {
                        var page = pdf.GetPage(i);
                        var strategy = new SimpleTextExtractionStrategy();
                        var text = PdfTextExtractor.GetTextFromPage(page, strategy);
                        if (!string.IsNullOrWhiteSpace(text)) sb.AppendLine(text);
                    }
                    return sb.ToString();
                }
                catch { return ""; }
            });
        }

        private TextBlock CreateEmptyBubbleForAI(out TextBlock statusText)
        {
            var msgWrapper = new StackPanel { Margin = new Thickness(0, 8, 60, 8), HorizontalAlignment = HorizontalAlignment.Left };
            statusText = new TextBlock { FontSize = 10, Foreground = Brushes.DarkGray, Margin = new Thickness(5, 0, 5, 4) };
            var bubble = new WpfBorder { Background = Brushes.White, CornerRadius = new CornerRadius(16, 16, 16, 4), Padding = new Thickness(12), BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E6E9EF")), BorderThickness = new Thickness(1) };
            var textBlock = new TextBlock { TextWrapping = TextWrapping.Wrap, FontSize = 14, Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1A1A1A")), MaxWidth = 330, FlowDirection = FlowDirection.RightToLeft };
            bubble.Child = textBlock;
            msgWrapper.Children.Add(statusText);
            msgWrapper.Children.Add(bubble);
            aiChatPanel.Children.Add(msgWrapper);
            aiScroll.ScrollToEnd();
            return textBlock;
        }

        private void AddChatBubble(string sender, string message, bool isUser)
        {
            var wrapper = new StackPanel { Margin = new Thickness(isUser ? 60 : 0, 8, isUser ? 0 : 60, 8), HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left };
            var header = new TextBlock { Text = sender, FontSize = 10, Foreground = Brushes.Gray, Margin = new Thickness(5, 0, 5, 4), HorizontalAlignment = isUser ? HorizontalAlignment.Right : HorizontalAlignment.Left };
            var bubble = new WpfBorder { Background = isUser ? new SolidColorBrush((Color)ColorConverter.ConvertFromString("#0088CC")) : Brushes.White, CornerRadius = isUser ? new CornerRadius(16, 16, 4, 16) : new CornerRadius(16, 16, 16, 4), Padding = new Thickness(12), BorderBrush = isUser ? Brushes.Transparent : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#E6E9EF")), BorderThickness = new Thickness(1) };
            var text = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, FontSize = 14, Foreground = isUser ? Brushes.White : new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1A1A1A")), MaxWidth = 330, FlowDirection = FlowDirection.RightToLeft };
            bubble.Child = text;
            wrapper.Children.Add(header);
            wrapper.Children.Add(bubble);
            aiChatPanel.Children.Add(wrapper);
            aiScroll.ScrollToEnd();
        }
    }
}