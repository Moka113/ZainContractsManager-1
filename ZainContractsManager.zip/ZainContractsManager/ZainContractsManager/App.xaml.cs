﻿#nullable enable
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;
using OfficeOpenXml;
using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows;
using ZainContractsManager.Data;
using ZainContractsManager.Services.Settings;
using ZainContractsManager.Views;

namespace ZainContractsManager
{
    public partial class App : Application
    {
        // ✅ IMPORTANT:
        // خليها true فقط أثناء التطوير لو ماعندكش بيانات مهمة.
        // في الإنتاج/البيانات الحقيقية لازم تكون false.
        private const bool ENABLE_AUTO_REPAIR_DELETE_DB = false;

        protected override void OnStartup(StartupEventArgs e)
        {
            // ✅ Safe: نحن نتحكم في الإغلاق يدويًا
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            // EPPlus License
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            base.OnStartup(e);

            try
            {
                InitializeDatabase_StrictWithAutoRepair();
                ApplyThemeSafe();
                LaunchLoginWindow();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "فشل تشغيل النظام بسبب قاعدة البيانات:\n\n" + ex.Message,
                    "DB Error",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                Shutdown();
            }
        }

        private void InitializeDatabase_StrictWithAutoRepair()
        {
            EnsureDbFolder();

            SafeAppendStartupLog($"Startup - DB Path: {AppDbContext.DbPath}");

            // محاولة 1: migrate طبيعي
            try
            {
                using (var db = new AppDbContext())
                {
                    db.Database.Migrate();
                    // ✅ ممنوع Seed هنا لأن الشركة لم تُحدد بعد
                }

                SafeAppendStartupLog("DB OK (Migrate).");
                return;
            }
            catch (Exception ex)
            {
                if (LooksLikeSchemaMismatch(ex))
                {
                    SafeAppendStartupLog("DB schema mismatch detected: " + ex.Message);

                    // ✅ لو الإصلاح التلقائي غير مفعّل: ارمِ الخطأ
                    if (!ENABLE_AUTO_REPAIR_DELETE_DB)
                        throw;
                }
                else
                {
                    SafeAppendStartupLog("DB error (non-schema): " + ex.Message);
                    throw;
                }
            }

            // ✅ إصلاح تلقائي (خطر): حذف قاعدة البيانات بالكامل ثم إعادة Migrate
            SafeAppendStartupLog("Attempting DB auto-repair: delete DB files then migrate...");

            DeleteDbFiles_WithRetry();

            using (var db2 = new AppDbContext())
            {
                db2.Database.Migrate();
                // ✅ برضه ممنوع Seed هنا
            }

            SafeAppendStartupLog("DB repaired successfully.");
        }

        private static bool LooksLikeSchemaMismatch(Exception ex)
        {
            var msg = FlattenExceptionMessages(ex).ToLowerInvariant();

            if (msg.Contains("no such column")) return true;
            if (msg.Contains("no such table")) return true;
            if (msg.Contains("has no column")) return true;

            if (msg.Contains("sqlite error") && (msg.Contains("column") || msg.Contains("table")))
                return true;

            return false;
        }

        private static string FlattenExceptionMessages(Exception ex)
        {
            var parts = "";
            var cur = ex;

            while (cur != null)
            {
                parts += cur.Message + " | ";
                cur = cur.InnerException;
            }

            return parts;
        }

        private static void EnsureDbFolder()
        {
            try
            {
                if (!Directory.Exists(AppDbContext.DbFolder))
                    Directory.CreateDirectory(AppDbContext.DbFolder);
            }
            catch { }
        }

        private static void DeleteDbFiles_WithRetry()
        {
            try
            {
                try { SqliteConnection.ClearAllPools(); } catch { }

                try
                {
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                }
                catch { }

                RetryDelete(AppDbContext.DbPath);
                RetryDelete(AppDbContext.DbPath + "-wal");
                RetryDelete(AppDbContext.DbPath + "-shm");

                SafeAppendStartupLog("DB files deleted successfully (with retry).");
            }
            catch (Exception ex)
            {
                SafeAppendStartupLog("DB auto-repair delete failed: " + ex.Message);
                throw;
            }
        }

        private static void RetryDelete(string path, int tries = 12, int delayMs = 250)
        {
            if (!File.Exists(path)) return;

            Exception? last = null;

            for (int i = 1; i <= tries; i++)
            {
                try
                {
                    try { SqliteConnection.ClearAllPools(); } catch { }

                    File.Delete(path);

                    if (!File.Exists(path))
                    {
                        SafeAppendStartupLog($"Deleted: {path} (try {i}/{tries})");
                        return;
                    }
                }
                catch (Exception ex)
                {
                    last = ex;
                    SafeAppendStartupLog($"Failed delete: {path} (try {i}/{tries}) | {ex.Message}");
                    Thread.Sleep(delayMs);
                }
            }

            throw new IOException($"تعذر حذف الملف بعد عدة محاولات: {path}", last);
        }

        private static void SafeAppendStartupLog(string line)
        {
            try
            {
                var logPath = Path.Combine(AppDbContext.DbFolder, "db_startup_log.txt");
                File.AppendAllText(logPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {line}{Environment.NewLine}");
            }
            catch { }
        }

        private static void ApplyThemeSafe()
        {
            try
            {
                var settings = new SettingsService();
                bool isDark = settings.GetBool("ui.darkMode", true);
                ThemeService.Apply(isDark);
            }
            catch
            {
                ThemeService.Apply(true);
            }
        }

        private void LaunchLoginWindow()
        {
            try
            {
                foreach (var w in Current.Windows.OfType<Window>().ToList())
                {
                    if (w is LoginWindow) continue;
                    w.Close();
                }
            }
            catch { }

            var loginWindow = new LoginWindow();

            // ✅ LoginWindow هو النافذة الأولى
            Current.MainWindow = loginWindow;

            // ✅ لما يقفل LoginWindow (بدون فتح MainWindow) نقفل التطبيق صراحة
            loginWindow.Closed += (_, __) =>
            {
                try
                {
                    // لو التطبيق لسه شغال ومفيش نافذة تانية مفتوحة
                    if (Current.Windows.OfType<Window>().All(w => !w.IsVisible))
                        Shutdown();
                }
                catch
                {
                    Shutdown();
                }
            };

            loginWindow.Show();
        }
    }
}