﻿using System.Windows;
using ZainContractsManager.Models;

namespace ZainContractsManager.Views
{
    public partial class AddTenantWindow : Window
    {
        // هذه الخاصية هي التي تحمل البيانات للشاشة الرئيسية
        public Tenant NewTenant { get; private set; }

        public AddTenantWindow()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            // التحقق من الاسم
            if (string.IsNullOrWhiteSpace(TxtName.Text))
            {
                MessageBox.Show("يرجى إدخال اسم المستأجر", "تنبيه", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // تعبئة البيانات
            NewTenant = new Tenant
            {
                Name = TxtName.Text,
                IdNumber = TxtIdNumber.Text,
                PhoneNumber = TxtPhone.Text,
                Email = TxtEmail.Text
            };

            this.DialogResult = true; // إغلاق النافذة مع تأكيد الحفظ
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false; // إغلاق بدون حفظ
        }
    }
}