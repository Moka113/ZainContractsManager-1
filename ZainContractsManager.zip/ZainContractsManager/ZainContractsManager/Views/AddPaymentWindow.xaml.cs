﻿#nullable enable
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

// ✅ FIX: Avoid ambiguity by aliasing the engine service only (NOT importing PaymentDirection from engine)
using FinanceEngineService = ZainContractsManager.Services.FinanceEngine.FinancialEngineService;

// ✅ FIX: Force PaymentDirection to be the Models enum (DB enum)
using PaymentDirection = ZainContractsManager.Models.PaymentDirection;

// السطر السحري لربط LeaseContract بكلمة Contract المستخدمة في الكود
using Contract = ZainContractsManager.Models.LeaseContract;

namespace ZainContractsManager.Views
{
    public partial class AddPaymentWindow : Window
    {
        // ✅ استخدم DB واحد للبحث/التحميل فقط
        private readonly AppDbContext _db = new AppDbContext();

        private Contract? _selectedContract;

        private readonly ObservableCollection<Payment> _paymentsList = new ObservableCollection<Payment>();

        // ✅ Default Direction based on contract direction (CompanyPays/CompanyReceives)
        private PaymentDirection _defaultDirectionForNewRows = PaymentDirection.Incoming;

        public AddPaymentWindow()
        {
            InitializeComponent();
            Title = "إضافة الدفعات اليدوية - نظام زين";
            GridPayments.ItemsSource = _paymentsList;

            TxtContractSearch.Focus();
        }

        public AddPaymentWindow(Payment targetPayment) : this()
        {
            try
            {
                // ✅ حماية: لازم CurrentCompanyId يكون محدد قبل أي حاجة
                var companyId = _db.CurrentCompanyId;
                if (companyId <= 0)
                {
                    MessageBox.Show("لا يمكن فتح نافذة الدفعات قبل اختيار الشركة.");
                    Close();
                    return;
                }

                // ✅ Load contract (محكوم بفلتر الشركة لو شغال)
                _selectedContract = _db.Contracts.AsNoTracking()
                    .FirstOrDefault(c => c.Id == targetPayment.ContractId);

                if (_selectedContract != null)
                {
                    TxtContractSearch.Text = _selectedContract.ContractNumber;
                    TxtContractSearch.IsEnabled = false;

                    // ✅ set default direction from contract
                    _defaultDirectionForNewRows = MapContractDirectionToPaymentDirection(_selectedContract.Direction);

                    UpdateContractLabels();

                    // ✅ تأكد إن الدفعة مربوطة بالشركة الحالية
                    targetPayment.CompanyId = companyId;

                    NormalizePayment(targetPayment);
                    _paymentsList.Add(targetPayment);
                }
                else
                {
                    MessageBox.Show("تعذر تحميل العقد الخاص بهذه الدفعة (قد لا يكون ضمن الشركة الحالية).");
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل بيانات الدفعة: " + ex.Message);
            }
        }

        private void TxtContractSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter) return;

            var companyId = _db.CurrentCompanyId;
            if (companyId <= 0)
            {
                MessageBox.Show("من فضلك اختر الشركة أولاً.");
                return;
            }

            string searchNum = (TxtContractSearch.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(searchNum)) return;

            var contract = _db.Contracts.AsNoTracking()
                // ✅ فلترة إضافية (حتى لو GlobalFilter شغال)
                .FirstOrDefault(c => c.CompanyId == companyId && c.ContractNumber == searchNum);

            if (contract != null)
            {
                _selectedContract = contract;

                // ✅ set default direction from contract
                _defaultDirectionForNewRows = MapContractDirectionToPaymentDirection(_selectedContract.Direction);

                // ✅ امسح صفوف قديمة لتفادي خلط دفعات عقدين
                _paymentsList.Clear();

                UpdateContractLabels();
            }
            else
            {
                MessageBox.Show("عذراً، رقم العقد غير موجود ضمن الشركة الحالية.");
                _selectedContract = null;
                _defaultDirectionForNewRows = PaymentDirection.Incoming;

                LblLessor.Text = "المؤجر: ---";
                LblTenant.Text = "المستأجر: ---";

                _paymentsList.Clear();
            }
        }

        private void UpdateContractLabels()
        {
            if (_selectedContract == null) return;

            LblLessor.Text = $"المؤجر: {_selectedContract.LessorName}";
            LblTenant.Text = $"المستأجر: {_selectedContract.TenantName}";
        }

        private void BtnAddRow_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedContract == null)
            {
                MessageBox.Show("يرجى اختيار العقد أولاً قبل إضافة دفعات.");
                return;
            }

            var companyId = _db.CurrentCompanyId;
            if (companyId <= 0)
            {
                MessageBox.Show("لا يمكن إضافة دفعات قبل اختيار الشركة.");
                return;
            }

            var p = new Payment
            {
                // ✅ أهم سطر: CompanyId
                CompanyId = companyId,

                ContractId = _selectedContract.Id,
                DueDate = DateTime.Today,
                Amount = 0,
                IsPaid = false,

                // ✅ Default direction from contract
                Direction = _defaultDirectionForNewRows,

                Category = null,
                PaymentMethod = null,
                ReferenceNo = null,
                Notes = "إدخال يدوي",

                AuditLog = $"[Manual] CreatedAt={DateTime.Now:yyyy-MM-dd HH:mm}"
            };

            _paymentsList.Add(p);
        }

        private void RemoveRow_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment != null)
                _paymentsList.Remove(payment);
        }

        private void SaveAll_Click(object sender, RoutedEventArgs e)
        {
            if (!_paymentsList.Any())
            {
                MessageBox.Show("لا توجد دفعات لحفظها.");
                return;
            }

            var companyId = _db.CurrentCompanyId;
            if (companyId <= 0)
            {
                MessageBox.Show("لا يمكن حفظ الدفعات قبل اختيار الشركة.");
                return;
            }

            if (_selectedContract == null && _paymentsList.Any(p => p.ContractId == 0))
            {
                MessageBox.Show("يرجى اختيار العقد أولاً.");
                return;
            }

            // ✅ حماية إضافية: العقد لازم يكون لنفس الشركة
            if (_selectedContract != null && _selectedContract.CompanyId != companyId)
            {
                MessageBox.Show("العقد المختار لا ينتمي للشركة الحالية.");
                return;
            }

            // Validation + Normalize
            foreach (var p in _paymentsList)
            {
                // ✅ أهم نقطة: تثبيت CompanyId لكل صف (جديد/قديم)
                p.CompanyId = companyId;

                // تأكيد ربط العقد
                if (p.ContractId == 0 && _selectedContract != null)
                    p.ContractId = _selectedContract.Id;

                if (p.Amount <= 0)
                {
                    MessageBox.Show("يرجى التأكد من إدخال مبالغ صحيحة لكافة الدفعات.");
                    return;
                }

                // ✅ سداد لازم يكون له تصنيف واضح
                if (p.Direction == PaymentDirection.Outgoing && string.IsNullOrWhiteSpace(p.Category))
                {
                    MessageBox.Show("الدفعات من نوع (سداد) لازم تحدد لها (تصنيف) مثل: إيجار / سعي / رسوم / عمولة / أخرى.");
                    return;
                }

                NormalizePayment(p);
            }

            try
            {
                // ✅ استخدم Context جديد للحفظ + Transaction
                using var context = new AppDbContext();

                // ✅ تأكيد إن context شايف نفس الشركة
                if (context.CurrentCompanyId != companyId)
                    context.CurrentCompanyId = companyId;

                using var tx = context.Database.BeginTransaction();

                foreach (var payment in _paymentsList)
                {
                    // مهم: ما نعتمدش على Navigation هنا
                    payment.Contract = null;

                    // ✅ تأكد إن العقد فعلاً موجود للشركة الحالية (حماية)
                    var contractOk = context.Contracts.AsNoTracking()
                        .Any(c => c.CompanyId == companyId && c.Id == payment.ContractId);

                    if (!contractOk)
                        throw new Exception($"العقد غير موجود ضمن الشركة الحالية. ContractId={payment.ContractId}");

                    if (payment.Id == 0)
                        context.Payments.Add(payment);
                    else
                        context.Payments.Update(payment);
                }

                // 1) Save Payments (يولد IDs)
                context.SaveChanges();

                // 2) ✅ Post to Financial Engine for paid payments
                var engine = new FinanceEngineService(context);

                foreach (var payment in _paymentsList.Where(p => p.IsPaid))
                {
                    engine.PostPaymentIfPaid(payment);
                }

                tx.Commit();

                MessageBox.Show("تم حفظ كافة الدفعات + ترحيلها للمحرك المالي بنجاح ✅");
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء عملية الحفظ/الترحيل: " + ex.Message);
            }
        }

        // ✅ تحويل اتجاه العقد لاتجاه الدفعة الافتراضي
        // CompanyPays (الشركة مستأجر) => غالباً سداد Outgoing
        // CompanyReceives (الشركة مؤجر) => غالباً تحصيل Incoming
        private static PaymentDirection MapContractDirectionToPaymentDirection(ContractDirection contractDirection)
        {
            return contractDirection == ContractDirection.CompanyPays
                ? PaymentDirection.Outgoing
                : PaymentDirection.Incoming;
        }

        /// <summary>
        /// توحيد البيانات + معالجة الحالات القديمة (Direction=0) + ضبط PaidAt
        /// </summary>
        private static void NormalizePayment(Payment p)
        {
            // لو جاية من Migration defaultValue=0
            if ((int)p.Direction == 0)
                p.Direction = PaymentDirection.Incoming;

            // Trim نصوص
            p.Category = string.IsNullOrWhiteSpace(p.Category) ? null : p.Category.Trim();
            p.PaymentMethod = string.IsNullOrWhiteSpace(p.PaymentMethod) ? null : p.PaymentMethod.Trim();
            p.ReferenceNo = string.IsNullOrWhiteSpace(p.ReferenceNo) ? null : p.ReferenceNo.Trim();

            // Notes بدل AuditLog للملاحظات
            if (string.IsNullOrWhiteSpace(p.Notes) && !string.IsNullOrWhiteSpace(p.AuditLog))
                p.Notes = p.AuditLog;

            p.Notes = string.IsNullOrWhiteSpace(p.Notes) ? null : p.Notes.Trim();

            // ✅ PaidAt logic (المرجع الأساسي IsPaid)
            if (p.IsPaid)
            {
                if (p.PaidAt == null)
                    p.PaidAt = DateTime.Now;
            }
            else
            {
                p.PaidAt = null;
            }

            // لو المستخدم اختار PaidAt يدويًا بالغلط وهو مش عامل IsPaid
            if (p.PaidAt != null && p.IsPaid == false)
                p.PaidAt = null;
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            try { _db.Dispose(); } catch { /* ignore */ }
        }
    }
}