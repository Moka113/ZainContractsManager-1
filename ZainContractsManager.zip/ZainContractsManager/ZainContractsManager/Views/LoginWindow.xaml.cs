﻿#nullable enable
using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

namespace ZainContractsManager.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            KeyDown += LoginWindow_KeyDown;
        }

        // =========================
        // Enter = Login
        // =========================
        private void LoginWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                Login_Click(this, new RoutedEventArgs());
            }
        }

        // =========================
        // Open Register (Optional)
        // =========================
        private void OpenRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var register = new RegisterWindow();
                register.Owner = this;
                register.ShowDialog();
            }
            catch
            {
                ShowError("نافذة إنشاء الحساب غير متوفرة حالياً.");
            }
        }

        // =========================
        // Login Logic (Clean & Safe)
        // =========================
        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HideError();

                var username = (UserTxt.Text ?? "").Trim();
                var password = (PassPwd.Password ?? "").Trim();

                if (string.IsNullOrWhiteSpace(username))
                {
                    ShowError("اكتب اسم المستخدم.");
                    UserTxt.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(password))
                {
                    ShowError("اكتب كلمة المرور.");
                    PassPwd.Focus();
                    return;
                }

                using var db = new AppDbContext();
                db.Database.Migrate();

                // ✅ لا تستخدم أي Method داخل LINQ
                var user = await db.Users
                    .AsNoTracking()
                    .FirstOrDefaultAsync(u => u.Username.ToLower() == username.ToLower());

                if (user == null || user.Password != password)
                {
                    ShowError("اسم المستخدم أو كلمة المرور غير صحيحة.");
                    return;
                }

                // حفظ المستخدم الحالي
                TrySetAppProperty("CurrentUserId", user.Id);

                // ===============================
                // اختيار الشركة
                // ===============================
                var picker = new CompanyPickerWindow(user.Id)
                {
                    Owner = this
                };

                var ok = picker.ShowDialog() == true;

                if (!ok || picker.SelectedCompanyId <= 0)
                {
                    ShowError("لم يتم اختيار شركة.");
                    return;
                }

                TrySetAppProperty("CurrentCompanyId", picker.SelectedCompanyId);

                // ===============================
                // دخول النظام
                // ===============================
                var main = new MainWindow();
                Application.Current.MainWindow = main;
                main.Show();

                Close();
            }
            catch (Exception ex)
            {
                ShowError("حدث خطأ أثناء تسجيل الدخول: " + ex.Message);
            }
        }

        // =========================
        // Helpers
        // =========================

        private static void TrySetAppProperty(string key, object value)
        {
            try
            {
                if (Application.Current?.Properties == null)
                    return;

                Application.Current.Properties[key] = value;
            }
            catch
            {
                // ignore
            }
        }

        private void ShowError(string msg)
        {
            ErrorTxt.Text = msg;
            ErrorTxt.Visibility = Visibility.Visible;
        }

        private void HideError()
        {
            ErrorTxt.Text = "";
            ErrorTxt.Visibility = Visibility.Collapsed;
        }
    }
}