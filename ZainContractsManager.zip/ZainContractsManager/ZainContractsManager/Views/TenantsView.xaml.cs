﻿using System.Windows;
using System.Windows.Controls;
using ZainContractsManager.ViewModels;
using ZainContractsManager.Views;

namespace ZainContractsManager.Views
{
    public partial class TenantsView : UserControl
    {
        public TenantsView()
        {
            InitializeComponent();
            this.DataContext = new TenantsViewModel();
        }

        private void AddTenant_Click(object sender, RoutedEventArgs e)
        {
            // فتح نافذة الإضافة
            AddTenantWindow addWindow = new AddTenantWindow();
            addWindow.Owner = Window.GetWindow(this);

            if (addWindow.ShowDialog() == true)
            {
                var newTenant = addWindow.NewTenant;
                if (newTenant != null)
                {
                    // جلب الـ ViewModel الحالي وإضافة المستأجر الجديد للقائمة
                    if (this.DataContext is TenantsViewModel viewModel)
                    {
                        viewModel.Tenants.Add(newTenant);
                        MessageBox.Show("تمت إضافة المستأجر بنجاح!", "نجاح", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
        }
    }
}