﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using ClosedXML.Excel;
using Microsoft.Win32;
using System.Collections.Generic;

namespace ZainContractsManager.Views
{
    public partial class ReportRequestWindow : Window
    {
        private AppDbContext _db = new AppDbContext();
        private string _reportType;

        public ReportRequestWindow(string type)
        {
            InitializeComponent();
            _reportType = type;
            this.Title = "نظام زين - استخراج " + type;

            // ضبط التواريخ آلياً بناءً على نوع التقرير المختار (الذكاء الاصطناعي للنظام)
            SetAutoDates(type);
        }

        private void SetAutoDates(string type)
        {
            DateTime now = DateTime.Today;
            switch (type)
            {
                case "تقرير استحقاق الشهر الحالي":
                    DateFrom.SelectedDate = new DateTime(now.Year, now.Month, 1);
                    DateTo.SelectedDate = new DateTime(now.Year, now.Month, DateTime.DaysInMonth(now.Year, now.Month));
                    break;
                case "تقرير استحقاق الشهر القادم":
                    var nextMonth = now.AddMonths(1);
                    DateFrom.SelectedDate = new DateTime(nextMonth.Year, nextMonth.Month, 1);
                    DateTo.SelectedDate = new DateTime(nextMonth.Year, nextMonth.Month, DateTime.DaysInMonth(nextMonth.Year, nextMonth.Month));
                    break;
                case "تقرير استحقاق العام":
                    DateFrom.SelectedDate = new DateTime(now.Year, 1, 1);
                    DateTo.SelectedDate = new DateTime(now.Year, 12, 31);
                    break;
            }
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var query = _db.Payments.Include(p => p.Contract).AsNoTracking().AsQueryable();

                // 1. فلترة النوع (مسدد / متأخر)
                if (_reportType == "الدفعات التي تم سدادها")
                    query = query.Where(p => p.IsPaid == true);
                else if (_reportType == "الدفعات المتأخرة")
                    query = query.Where(p => p.IsPaid == false && p.DueDate < DateTime.Today);

                // 2. فلترة رقم العقد
                if (!string.IsNullOrWhiteSpace(TxtContractNum.Text))
                    query = query.Where(p => p.Contract.ContractNumber == TxtContractNum.Text.Trim());

                // 3. فلترة التاريخ
                if (DateFrom.SelectedDate != null)
                    query = query.Where(p => p.DueDate >= DateFrom.SelectedDate);
                if (DateTo.SelectedDate != null)
                    query = query.Where(p => p.DueDate <= DateTo.SelectedDate);

                var dataResult = query.OrderBy(p => p.DueDate).ToList();

                if (!dataResult.Any())
                {
                    MessageBox.Show("لا توجد بيانات تطابق هذه المعايير في نظام زين.");
                    return;
                }

                ExecuteExcelExportWithBranding(dataResult);
            }
            catch (Exception ex) { MessageBox.Show("خطأ تقني في التقارير: " + ex.Message); }
        }

        private void ExecuteExcelExportWithBranding(List<Payment> data)
        {
            using (var workbook = new XLWorkbook())
            {
                var sheet = workbook.Worksheets.Add("كشف الدفعات");
                sheet.RightToLeft = true; // توافق كامل مع اللغة العربية

                // --- إعداد الختم وحقوق الملكية (ملاحظة الختم) ---
                sheet.Cell("A1").Value = "ZAIN SYSTEM - نظام زين لإدارة العقارات والتعاقدات";
                sheet.Range("A1:G1").Merge().Style
                    .Font.SetBold().Font.SetFontSize(16).Font.SetFontColor(XLColor.FromHtml("#2C3E50"))
                    .Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);

                sheet.Cell("A2").Value = $"نوع التقرير: {_reportType} | تاريخ الاستخراج: {DateTime.Now:yyyy/MM/dd HH:mm}";
                sheet.Range("A2:G2").Merge().Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);

                // --- تصميم جدول البيانات الاحترافي ---
                string[] headers = { "م", "رقم العقد", "المؤجر", "المستأجر", "المبلغ (ر.س)", "تاريخ الاستحقاق", "حالة الدفعة" };
                for (int i = 0; i < headers.Length; i++)
                {
                    var cell = sheet.Cell(4, i + 1);
                    cell.Value = headers[i];
                    cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#27AE60");
                    cell.Style.Font.FontColor = XLColor.White;
                    cell.Style.Font.Bold = true;
                    cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                }

                // --- تعبئة البيانات وتلوين الحالة ذكياً ---
                for (int i = 0; i < data.Count; i++)
                {
                    int row = i + 5;
                    sheet.Cell(row, 1).Value = i + 1;
                    sheet.Cell(row, 2).Value = data[i].Contract?.ContractNumber;
                    sheet.Cell(row, 3).Value = data[i].Contract?.LessorName;
                    sheet.Cell(row, 4).Value = data[i].Contract?.TenantName;
                    sheet.Cell(row, 5).Value = data[i].Amount;
                    sheet.Cell(row, 6).Value = data[i].DueDate.ToString("yyyy/MM/dd");

                    var statusCell = sheet.Cell(row, 7);
                    statusCell.Value = data[i].IsPaid ? "تم السداد ✅" : (data[i].DueDate < DateTime.Today ? "متأخرة ⚠️" : "مستحقة ⏳");

                    // تلوين الحالة في الإكسل (احترافي)
                    if (data[i].IsPaid) statusCell.Style.Font.FontColor = XLColor.Green;
                    else if (data[i].DueDate < DateTime.Today) statusCell.Style.Font.FontColor = XLColor.Red;
                }

                // --- ختم حقوق الملكية في أسفل الشيت (ملاحظة الختم) ---
                int lastRow = data.Count + 7;
                var footerRange = sheet.Range(lastRow, 1, lastRow, 7);
                footerRange.Merge().Value = "جميع الحقوق محفوظة لنظام زين © 2026 - ZAIN SYSTEM";
                footerRange.Style.Font.SetItalic().Font.SetFontColor(XLColor.Gray).Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);

                // تنسيق تلقائي وحماية الشيت
                sheet.Columns().AdjustToContents();
                sheet.Style.Font.FontName = "Segoe UI";

                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Excel Files|*.xlsx",
                    FileName = $"{_reportType}_{DateTime.Now:yyyyMMdd}"
                };

                if (sfd.ShowDialog() == true)
                {
                    workbook.SaveAs(sfd.FileName);
                    MessageBox.Show("تم استخراج التقرير الرسمي بنجاح 📗\nالآن يمكنك طباعته بختم النظام.");
                    this.Close();
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e) => this.Close();
    }
}