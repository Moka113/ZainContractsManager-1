﻿#nullable disable // لضمان عدم ظهور تحذيرات النول وتوافقها مع إعدادات المشروع
using Microsoft.Win32;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Drawing; // Color فقط
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

// ✅ ربط المحرك المالي
using ZainContractsManager.Services.FinanceEngine;

// ✅ صفحة القيود (UserControl)
using ZainContractsManager.Views.Finance;

// ✅ Fix: تعارض LicenseContext بين System.ComponentModel و EPPlus
using EpplusLicenseContext = OfficeOpenXml.LicenseContext;

// ✅ Accounts
using ZainContractsManager.Models.Finance; // Account + AccountType

namespace ZainContractsManager.Views
{
    public partial class ExpensesView : UserControl
    {
        private List<FinancialExpense> _allExpenses = new List<FinancialExpense>();

        public ExpensesView()
        {
            InitializeComponent();

            // ✅ EPPlus License (بدون Ambiguous)
            ExcelPackage.LicenseContext = EpplusLicenseContext.NonCommercial;

            Loaded += (_, __) => LoadInitialData();
        }

        private void LoadInitialData()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    // ✅ الفروع فلترتها Multi-tenant بتحصل من AppDbContext (HasQueryFilter)
                    var branches = db.Branches.AsNoTracking()
                        .OrderBy(b => b.BranchName)
                        .ToList();

                    // عنصر وهمي للفلترة
                    branches.Insert(0, new Branch { BranchName = "كل الفروع" });

                    ComboBranchFilter.ItemsSource = branches;
                    ComboBranchFilter.SelectedIndex = 0;
                }

                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("نظام زين - خطأ في التحميل: " + ex.Message);
            }
        }

        public void RefreshData()
        {
            try
            {
                using (var db = new AppDbContext())
                {
                    // ✅ FinancialExpenses فلترتها Multi-tenant بتحصل تلقائيًا من AppDbContext
                    _allExpenses = db.FinancialExpenses
                        .AsNoTracking()
                        .OrderByDescending(x => x.ExpenseDate)
                        .ThenByDescending(x => x.Id)
                        .ToList();
                }

                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء تحديث المصروفات: " + ex.Message);
            }
        }

        // =========================
        // Filters
        // =========================
        private void ApplyFilters()
        {
            var filtered = _allExpenses.AsEnumerable();

            string searchText = (TxtSearch.Text ?? "").Trim().ToLowerInvariant();
            if (!string.IsNullOrEmpty(searchText))
            {
                filtered = filtered.Where(x =>
                    ((x.ExpenseNumber ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.ContractNumber ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.Description ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.BranchName ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.Category ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.ReferenceNo ?? "").ToLowerInvariant().Contains(searchText)) ||
                    ((x.InvoiceNumber ?? "").ToLowerInvariant().Contains(searchText))
                );
            }

            // فرع محدد
            if (ComboBranchFilter.SelectedIndex > 0)
            {
                var selectedBranch = ComboBranchFilter.SelectedItem as Branch;
                if (selectedBranch != null && !string.IsNullOrWhiteSpace(selectedBranch.BranchName))
                    filtered = filtered.Where(x => (x.BranchName ?? "") == selectedBranch.BranchName);
            }

            var result = filtered.ToList();
            GridExpenses.ItemsSource = result;

            CalculateSummaries(result);

            if (TxtStatusCount != null)
                TxtStatusCount.Text = result.Count.ToString();
        }

        private void CalculateSummaries(List<FinancialExpense> data)
        {
            decimal baseAmount = data.Sum(x => x.Amount);
            decimal taxAmount = data.Sum(x => x.TaxAmount);
            decimal totalAmount = data.Sum(x => x.TotalAmount);

            if (TxtTotalBase != null) TxtTotalBase.Text = baseAmount.ToString("N2") + " ريال";
            if (TxtTotalTax != null) TxtTotalTax.Text = taxAmount.ToString("N2") + " ريال";
            if (TxtTotalAll != null) TxtTotalAll.Text = totalAmount.ToString("N2") + " ريال";
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();
        private void ComboBranchFilter_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();
        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => RefreshData();

        // =========================
        // Add New
        // =========================
        private void BtnAddNew_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var addWin = new AddExpenseWindow();
                addWin.Owner = Window.GetWindow(this);
                if (addWin.ShowDialog() == true)
                    RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح شاشة إضافة مصروف: " + ex.Message);
            }
        }

        // =========================
        // Export Report (EPPlus - Professional)
        // =========================
        private void BtnExportReport_Click(object sender, RoutedEventArgs e)
        {
            var data = GridExpenses.ItemsSource as List<FinancialExpense>;
            if (data == null || data.Count == 0)
            {
                MessageBox.Show("لا توجد بيانات لتصديرها!", "تنبيه");
                return;
            }

            string reportType = (ComboReportType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "تقرير عام";

            if (reportType.Contains("عقد معين"))
            {
                string searchVal = (TxtSearch.Text ?? "").Trim();
                if (string.IsNullOrEmpty(searchVal))
                {
                    MessageBox.Show("يرجى كتابة رقم العقد في خانة البحث أولاً لتحديد التقرير.", "تنبيه");
                    return;
                }

                data = data.Where(x => (x.ContractNumber ?? "") == searchVal).ToList();
                if (data.Count == 0)
                {
                    MessageBox.Show("لم يتم العثور على مصروفات لهذا العقد.");
                    return;
                }
            }

            var sfd = new SaveFileDialog()
            {
                Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                FileName = $"{reportType}_{DateTime.Now:yyyyMMdd_HHmm}"
            };

            if (sfd.ShowDialog() != true) return;

            try
            {
                ExcelPackage.LicenseContext = EpplusLicenseContext.NonCommercial;

                using (var package = new ExcelPackage())
                {
                    var sheet = package.Workbook.Worksheets.Add("Expenses");
                    sheet.View.RightToLeft = true;

                    // ======= Title =======
                    sheet.Cells["A1:I1"].Merge = true;
                    sheet.Cells["A1"].Value = $"ZAIN SYSTEM ™️ | تقرير المصروفات - {reportType}";
                    sheet.Cells["A1"].Style.Font.Size = 16;
                    sheet.Cells["A1"].Style.Font.Bold = true;
                    sheet.Cells["A1"].Style.Font.Color.SetColor(Color.White);
                    sheet.Cells["A1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    sheet.Cells["A1"].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59)); // #1E293B
                    sheet.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    sheet.Cells["A1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    sheet.Row(1).Height = 28;

                    // ======= Sub Info =======
                    sheet.Cells["A3:I3"].Merge = true;
                    sheet.Cells["A3"].Value = "تاريخ الاستخراج: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                    sheet.Cells["A3"].Style.Font.Bold = true;
                    sheet.Cells["A3"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    // ======= Logo (Top Right for RTL) =======
                    TryAddLogo(sheet);

                    // ======= Headers =======
                    string[] headers =
                    {
                        "رقم السند",
                        "تاريخ المصروف",
                        "الفرع",
                        "رقم العقد",
                        "نوع المصروف",
                        "البيان / الوصف",
                        "المبلغ الصافي",
                        "ضريبة 15%",
                        "الإجمالي الشامل"
                    };

                    for (int i = 0; i < headers.Length; i++)
                    {
                        var cell = sheet.Cells[6, i + 1];
                        cell.Value = headers[i];
                        cell.Style.Font.Bold = true;
                        cell.Style.Font.Color.SetColor(Color.White);
                        cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        cell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59));
                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                    }
                    sheet.Row(6).Height = 22;

                    // Freeze & Filter
                    sheet.View.FreezePanes(7, 1);
                    sheet.Cells[6, 1, 6, headers.Length].AutoFilter = true;

                    int row = 7;
                    foreach (var exp in data.OrderByDescending(x => x.ExpenseDate).ThenByDescending(x => x.Id))
                    {
                        sheet.Cells[row, 1].Value = exp.ExpenseNumber;
                        sheet.Cells[row, 2].Value = exp.ExpenseDate;
                        sheet.Cells[row, 3].Value = exp.BranchName ?? "";

                        // Contract number as text
                        sheet.Cells[row, 4].Style.Numberformat.Format = "@";
                        sheet.Cells[row, 4].Value = exp.ContractNumber ?? "";

                        sheet.Cells[row, 5].Value = exp.Category ?? "";
                        sheet.Cells[row, 6].Value = exp.Description ?? "";

                        sheet.Cells[row, 7].Value = exp.Amount;
                        sheet.Cells[row, 8].Value = exp.TaxAmount;
                        sheet.Cells[row, 9].Value = exp.TotalAmount;

                        // formats
                        sheet.Cells[row, 2].Style.Numberformat.Format = "yyyy/mm/dd";
                        sheet.Cells[row, 7, row, 9].Style.Numberformat.Format = "#,##0.00";

                        // borders + align
                        for (int col = 1; col <= 9; col++)
                        {
                            var c = sheet.Cells[row, col];
                            c.Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                            c.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                            c.Style.WrapText = true;
                        }

                        row++;
                    }

                    // Totals row
                    int lastRow = row;
                    sheet.Cells[lastRow, 1, lastRow, 5].Merge = true;
                    sheet.Cells[lastRow, 1].Value = "الإجماليات:";
                    sheet.Cells[lastRow, 1].Style.Font.Bold = true;
                    sheet.Cells[lastRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    sheet.Cells[lastRow, 7].Formula = $"SUM(G7:G{lastRow - 1})";
                    sheet.Cells[lastRow, 8].Formula = $"SUM(H7:H{lastRow - 1})";
                    sheet.Cells[lastRow, 9].Formula = $"SUM(I7:I{lastRow - 1})";

                    sheet.Cells[lastRow, 7, lastRow, 9].Style.Font.Bold = true;
                    sheet.Cells[lastRow, 7, lastRow, 9].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    sheet.Cells[lastRow, 7, lastRow, 9].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));
                    sheet.Cells[lastRow, 7, lastRow, 9].Style.Numberformat.Format = "#,##0.00";

                    // Stamp (Watermark style)
                    TryAddStamp(sheet);

                    // Footer / Rights
                    int footerRow = lastRow + 3;
                    sheet.Cells[footerRow, 1, footerRow, 9].Merge = true;
                    sheet.Cells[footerRow, 1].Value =
                        "ZAIN SYSTEM 2026 ©️ | All Rights Reserved to Mustafa Zain | هذا النظام بجميع ملكياته الفكرية وحقوقه القانونية تعود لـ مصطفى زين";
                    sheet.Cells[footerRow, 1].Style.Font.Size = 10;
                    sheet.Cells[footerRow, 1].Style.Font.Bold = true;
                    sheet.Cells[footerRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    sheet.Cells[footerRow, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    sheet.Cells[footerRow, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));
                    sheet.Row(footerRow).Height = 22;

                    // Fit columns
                    sheet.Cells[sheet.Dimension.Address].AutoFitColumns(12, 55);

                    File.WriteAllBytes(sfd.FileName, package.GetAsByteArray());
                }

                MessageBox.Show($"تم استخراج {reportType} بنجاح.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ تقني في التصدير: " + ex.Message);
            }
        }

        // =========================
        // Delete
        // =========================
        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var expense = ((Button)sender).DataContext as FinancialExpense;
            if (expense == null) return;

            if (MessageBox.Show("هل أنت متأكد من حذف هذا السند؟", "تحذير",
                MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                using (var db = new AppDbContext())
                {
                    var itemToDelete = db.FinancialExpenses.Find(expense.Id);
                    if (itemToDelete != null)
                    {
                        db.FinancialExpenses.Remove(itemToDelete);
                        db.SaveChanges();
                    }
                }

                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء الحذف: " + ex.Message);
            }
        }

        // =========================
        // View Attachment
        // =========================
        private void BtnViewFile_Click(object sender, RoutedEventArgs e)
        {
            var expense = ((Button)sender).DataContext as FinancialExpense;
            if (expense != null &&
                !string.IsNullOrEmpty(expense.AttachmentPath) &&
                File.Exists(expense.AttachmentPath))
            {
                try
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(expense.AttachmentPath) { UseShellExecute = true });
                }
                catch
                {
                    MessageBox.Show("تعذر فتح الملف.");
                }
            }
            else
            {
                MessageBox.Show("لا يوجد ملف مرفق أو الملف غير موجود.");
            }
        }

        // =========================
        // ✅ View Journal for Expense (UserControl Navigation)
        // =========================
        private void BtnViewJournal_Click(object sender, RoutedEventArgs e)
        {
            var exp = (sender as Button)?.DataContext as FinancialExpense;
            if (exp == null) return;

            try
            {
                var main = Application.Current.MainWindow as ZainContractsManager.MainWindow;
                if (main == null)
                {
                    MessageBox.Show("تعذر الوصول للنافذة الرئيسية.");
                    return;
                }

                main.MainContentHost.Content = new JournalEntriesView(sourceType: "Expense", sourceId: exp.Id);
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح القيود: " + ex.Message);
            }
        }

        // =========================
        // ✅ Post old paid expense to Financial Engine (safe + no duplicates)
        // =========================
        private void BtnPostToEngine_Click(object sender, RoutedEventArgs e)
        {
            var exp = (sender as Button)?.DataContext as FinancialExpense;
            if (exp == null) return;

            if (!exp.IsPaid)
            {
                MessageBox.Show("لا يمكن الترحيل: المصروف غير مدفوع.");
                return;
            }

            try
            {
                using (var db = new AppDbContext())
                {
                    var entity = db.FinancialExpenses.FirstOrDefault(x => x.Id == exp.Id);
                    if (entity == null)
                    {
                        MessageBox.Show("تعذر تحميل السند من قاعدة البيانات.");
                        return;
                    }

                    // ✅ منع التكرار: لو متسجل عليه قيد بالفعل
                    bool hasJournal = db.JournalEntries.Any(j => j.SourceType == "Expense" && j.SourceId == entity.Id);
                    if (entity.IsPostedToJournal || entity.JournalEntryId.HasValue || hasJournal)
                    {
                        MessageBox.Show("هذا السند مُرحّل بالفعل (يوجد قيد محاسبي مرتبط به).");
                        RefreshData();
                        return;
                    }

                    // ✅ Fix: (الحساب غير موجود / غير نشط) - حل فعلي صحيح
                    EnsureExpenseAccountReady(db, entity);

                    var engine = new FinancialEngineService(db);
                    engine.PostExpenseIfPaid(entity);
                }

                MessageBox.Show("تم ترحيل السند للمحرك المالي بنجاح ✅");
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء الترحيل: " + ex.Message);
            }
        }

        // =========================
        // Edit (enabled)
        // =========================
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var exp = (sender as Button)?.DataContext as FinancialExpense;
            if (exp == null) return;

            try
            {
                var win = new AddExpenseWindow(exp);
                win.Owner = Window.GetWindow(this);

                if (win.ShowDialog() == true)
                    RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح شاشة التعديل: " + ex.Message);
            }
        }

        // =========================================================
        // ✅ Helpers: Accounts safety + Logo/Stamp (EPPlus)
        // =========================================================

        private void EnsureExpenseAccountReady(AppDbContext db, FinancialExpense exp)
        {
            try
            {
                // 1) اقرأ AccountCode/AccountName من السند (لو عندك)
                var accountCode = TryReadProp(exp, "AccountCode");
                var accountName = TryReadProp(exp, "AccountName");

                // لو ما فيه AccountCode، غالباً المحرك يحدد الحساب من Category
                if (string.IsNullOrWhiteSpace(accountCode))
                    return;

                accountCode = accountCode.Trim();
                if (string.IsNullOrWhiteSpace(accountName))
                    accountName = accountCode;
                else
                    accountName = accountName.Trim();

                // 2) CompanyId
                int companyId = GetCompanyId(db, exp);

                // 3) دور على الحساب داخل نفس الشركة حتى لو QueryFilter مخفيه
                var acc = db.Set<Account>()
                    .IgnoreQueryFilters()
                    .FirstOrDefault(a => a.CompanyId == companyId && a.Code == accountCode);

                if (acc == null)
                {
                    acc = new Account
                    {
                        CompanyId = companyId,
                        Code = accountCode,
                        Name = accountName,
                        Type = AccountType.Expense,
                        IsActive = true,
                        ParentId = null
                    };

                    db.Set<Account>().Add(acc);
                    db.SaveChanges();
                }
                else
                {
                    if (!acc.IsActive)
                    {
                        acc.IsActive = true;
                        db.SaveChanges();
                    }
                }
            }
            catch
            {
                // ignore: لا نكسر الترحيل
            }
        }

        private int GetCompanyId(AppDbContext db, FinancialExpense exp)
        {
            try
            {
                // 1) من السند
                var cProp = exp.GetType().GetProperty("CompanyId");
                if (cProp != null && int.TryParse(cProp.GetValue(exp)?.ToString(), out int cid) && cid > 0)
                    return cid;

                // 2) من db (لو عندك CurrentCompanyId أو CompanyId)
                var dbCompanyProp = db.GetType().GetProperty("CurrentCompanyId")
                                 ?? db.GetType().GetProperty("CompanyId");

                if (dbCompanyProp != null && int.TryParse(dbCompanyProp.GetValue(db)?.ToString(), out int dbCid) && dbCid > 0)
                    return dbCid;
            }
            catch { }

            // fallback
            return 0;
        }

        private static string TryReadProp(object obj, string propName)
        {
            try
            {
                var p = obj.GetType().GetProperty(propName);
                return p?.GetValue(obj)?.ToString();
            }
            catch
            {
                return null;
            }
        }

        // ✅ بدون Image.FromFile نهائياً
        private void TryAddLogo(ExcelWorksheet ws)
        {
            try
            {
                var logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "logo.png");
                if (!File.Exists(logoPath)) return;

                var pic = ws.Drawings.AddPicture($"Logo_{Guid.NewGuid():N}", new FileInfo(logoPath));
                pic.SetPosition(0, 0, 7, 0); // أعلى يمين (RTL)
                pic.SetSize(80, 80);
            }
            catch
            {
                // ignore
            }
        }

        // ✅ بدون Image.FromFile نهائياً
        private void TryAddStamp(ExcelWorksheet ws)
        {
            try
            {
                var stampPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "stamp.png");
                if (!File.Exists(stampPath)) return;

                var pic = ws.Drawings.AddPicture($"Stamp_{Guid.NewGuid():N}", new FileInfo(stampPath));
                pic.SetPosition(8, 0, 4, 0); // وسط تقريباً
                pic.SetSize(300, 300);
            }
            catch
            {
                // ignore
            }
        }
    }
}