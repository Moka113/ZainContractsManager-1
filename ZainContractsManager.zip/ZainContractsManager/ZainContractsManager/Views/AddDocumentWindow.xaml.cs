﻿#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

namespace ZainContractsManager.Views
{
    public partial class AddDocumentWindow : Window
    {
        private string _selectedFilePath = string.Empty;
        private AppDbContext _db = new AppDbContext();
        private string _detectedBranch = string.Empty;
        private readonly Document? _editDoc = null;

        public AddDocumentWindow(Document? doc = null)
        {
            InitializeComponent();
            _editDoc = doc;

            if (_editDoc != null)
            {
                // إظهار خيار الأرشفة عند التعديل/التجديد فقط
                ArchiveOptionArea.Visibility = Visibility.Visible;
                LblTitle.Text = "تحديث أو تجديد مستند في أرشيف زين";
                BtnSave.Content = "حفظ التعديلات والتجديد ✅";
                PrepareForEdit();
            }
        }

        private void PrepareForEdit()
        {
            if (_editDoc == null) return;

            TxtContractNo.Text = _editDoc.ContractNumber ?? string.Empty;
            TxtLesseeName.Text = _editDoc.TenantName ?? string.Empty;
            TxtLessorName.Text = _editDoc.LessorName ?? string.Empty;
            DateExpiry.SelectedDate = _editDoc.ExpiryDate;
            TxtNotes.Text = _editDoc.Notes ?? string.Empty;

            _selectedFilePath = _editDoc.FilePath ?? string.Empty;
            _detectedBranch = _editDoc.BranchName ?? string.Empty;

            TxtFileName.Text = string.IsNullOrWhiteSpace(_selectedFilePath)
                ? "لا يوجد ملف"
                : Path.GetFileName(_selectedFilePath);

            // اختيار نوع المستند بشكل صحيح من القائمة
            foreach (ComboBoxItem item in ComboDocType.Items)
            {
                if ((item.Content?.ToString() ?? string.Empty) == (_editDoc.DocumentType ?? string.Empty))
                {
                    ComboDocType.SelectedItem = item;
                    break;
                }
            }
        }

        private void TxtContractNo_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_editDoc != null) return; // لا نغير البيانات تلقائياً في وضع التعديل

            try
            {
                var contractNo = (TxtContractNo.Text ?? string.Empty).Trim();
                if (string.IsNullOrWhiteSpace(contractNo))
                    return;

                // البحث عن العقد لجلب اسم المستأجر والمؤجر والفرع تلقائياً
                var contract = _db.Contracts.FirstOrDefault(c => c.ContractNumber == contractNo);
                if (contract != null)
                {
                    TxtLesseeName.Text = contract.TenantName ?? string.Empty;
                    TxtLessorName.Text = contract.LessorName ?? string.Empty;
                    _detectedBranch = contract.BranchName ?? string.Empty;
                }
            }
            catch
            {
                // تجاهل هادئ حتى لا نزعج المستخدم أثناء الكتابة
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string contractNo = (TxtContractNo.Text ?? string.Empty).Trim();
                string tenantName = (TxtLesseeName.Text ?? string.Empty).Trim();
                string lessorName = (TxtLessorName.Text ?? string.Empty).Trim();
                string notes = (TxtNotes.Text ?? string.Empty).Trim();
                string docType = (ComboDocType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? string.Empty;

                if (string.IsNullOrWhiteSpace(contractNo))
                {
                    MessageBox.Show("من فضلك أدخل رقم العقد أولاً.", "نظام زين");
                    return;
                }

                if (string.IsNullOrWhiteSpace(docType))
                {
                    MessageBox.Show("من فضلك اختر نوع المستند.", "نظام زين");
                    return;
                }

                // ✅ مهم جداً: هذا هو سبب أن المستند لا يظهر بعد الحفظ غالباً
                int currentCompanyId = _db.CurrentCompanyId;
                if (currentCompanyId <= 0)
                {
                    MessageBox.Show("تعذر تحديد الشركة الحالية. أعد تسجيل الدخول واختر الشركة أولاً.", "نظام زين");
                    return;
                }

                if (_editDoc == null)
                {
                    // --- إضافة مستند جديد ---
                    var newDoc = new Document
                    {
                        CompanyId = currentCompanyId, // ✅ FIX
                        ContractNumber = contractNo,
                        DocumentType = docType,
                        TenantName = tenantName,
                        LessorName = lessorName,
                        BranchName = _detectedBranch,
                        ExpiryDate = DateExpiry.SelectedDate,
                        Notes = notes,
                        FilePath = _selectedFilePath,
                        CreatedAt = DateTime.Now,
                        IsArchivedVersion = false, // النسخة الأساسية النشطة
                        ParentContractId = null,
                        AuditLog = $"تمت الأرشفة لأول مرة في {DateTime.Now:yyyy-MM-dd HH:mm:ss}"
                    };

                    _db.Documents.Add(newDoc);
                }
                else
                {
                    // --- تعديل / تجديد ---
                    var docInDb = _db.Documents.FirstOrDefault(d => d.Id == _editDoc.Id);
                    if (docInDb == null)
                    {
                        MessageBox.Show("تعذر العثور على المستند المراد تعديله.", "نظام زين");
                        return;
                    }

                    // ✅ حماية إضافية: لو CompanyId القديم صفر، أصلحه
                    if (docInDb.CompanyId <= 0)
                        docInDb.CompanyId = currentCompanyId;

                    if (ChkArchiveOldVersion.IsChecked == true)
                    {
                        // إنشاء نسخة تاريخية مؤرشفة من الوضع القديم
                        var historyVersion = new Document
                        {
                            CompanyId = docInDb.CompanyId, // ✅ FIX
                            ContractNumber = docInDb.ContractNumber,
                            DocumentType = docInDb.DocumentType,
                            TenantName = docInDb.TenantName,
                            LessorName = docInDb.LessorName,
                            BranchName = docInDb.BranchName,
                            ExpiryDate = docInDb.ExpiryDate,
                            FilePath = docInDb.FilePath,
                            Notes = $"نسخة قديمة مؤرشفة تلقائياً بتاريخ {DateTime.Now:yyyy-MM-dd HH:mm:ss}",
                            CreatedAt = docInDb.CreatedAt,
                            IsArchivedVersion = true,
                            ParentContractId = docInDb.Id,
                            AuditLog = (docInDb.AuditLog ?? string.Empty) + $"\nتم إنشاء نسخة أرشيفية في {DateTime.Now:yyyy-MM-dd HH:mm:ss}"
                        };

                        _db.Documents.Add(historyVersion);
                    }

                    // تحديث النسخة الحالية
                    docInDb.CompanyId = currentCompanyId; // ✅ FIX
                    docInDb.ContractNumber = contractNo;
                    docInDb.DocumentType = docType;
                    docInDb.TenantName = tenantName;
                    docInDb.LessorName = lessorName;
                    docInDb.BranchName = _detectedBranch;
                    docInDb.ExpiryDate = DateExpiry.SelectedDate;
                    docInDb.Notes = notes;
                    docInDb.FilePath = _selectedFilePath;
                    docInDb.AuditLog = (docInDb.AuditLog ?? string.Empty) + $"\nتم التجديد/التحديث في {DateTime.Now:yyyy-MM-dd HH:mm:ss}";
                }

                _db.SaveChanges();

                MessageBox.Show("تمت العملية بنجاح! تم تحديث الأرشيف الرقمي.", "نظام زين");
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"خطأ أثناء الحفظ: {ex.Message}", "خطأ تقني");
            }
        }

        // =========================
        // Drag & Drop
        // =========================
        private void FileDropArea_Drop(object sender, DragEventArgs e)
        {
            try
            {
                if (!e.Data.GetDataPresent(DataFormats.FileDrop)) return;

                var files = (string[])e.Data.GetData(DataFormats.FileDrop);
                if (files.Length <= 0) return;

                _selectedFilePath = files[0];
                TxtFileName.Text = Path.GetFileName(_selectedFilePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"تعذر قراءة الملف: {ex.Message}", "نظام زين");
            }
        }

        private void FileDropArea_DragOver(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Copy;
            e.Handled = true;
        }

        private void SelectFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var ofd = new OpenFileDialog
                {
                    Title = "اختر ملف المستند",
                    Filter = "كل الملفات|*.*|PDF Files|*.pdf|Image Files|*.png;*.jpg;*.jpeg"
                };

                if (ofd.ShowDialog() == true)
                {
                    _selectedFilePath = ofd.FileName;
                    TxtFileName.Text = ofd.SafeFileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"تعذر اختيار الملف: {ex.Message}", "نظام زين");
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}