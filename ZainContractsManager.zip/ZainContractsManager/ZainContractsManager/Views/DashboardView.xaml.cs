﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

using Microsoft.EntityFrameworkCore;
using ClosedXML.Excel;

using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.WPF;
using SkiaSharp;

using ZainContractsManager.AI_Module;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

namespace ZainContractsManager.Views
{
    public partial class DashboardView : UserControl, IAiPageContextProvider
    {
        private DispatcherTimer? _refreshTimer;
        private readonly Stopwatch _sw = new Stopwatch();
        private readonly SemaphoreSlim _loadGate = new SemaphoreSlim(1, 1);
        private CancellationTokenSource? _loadCts;

        // ✅ Backward compatibility (fallback فقط)
        // المصدر الأساسي للـ CompanyId هو Application.Current.Properties["CurrentCompanyId"]
        public static int CurrentCompanyId { get; set; } = 0;

        private static readonly CultureInfo UiCulture = CultureInfo.InvariantCulture; // أو new CultureInfo("ar-SA");

        public string PageTitle => "لوحة التحكم";
        public string GetAiContext() => GetAiContextSnapshot();

        public DashboardView()
        {
            InitializeComponent();
            Loaded += DashboardView_Loaded;
            Unloaded += DashboardView_Unloaded;
        }

        // -------------------- Helpers --------------------
        private static string Norm(string? s) => (s ?? "").Trim().ToLowerInvariant();

        private static bool IsActiveContract(LeaseContract c, DateTime today) => c.EndDate.Date >= today;
        private static bool IsExpiredContract(LeaseContract c, DateTime today) => c.EndDate.Date < today;
        private static bool IsWarningContract(LeaseContract c, DateTime today)
            => c.EndDate.Date >= today && c.EndDate.Date <= today.AddDays(30);

        private static double SafeMoney(double v) => double.IsNaN(v) || double.IsInfinity(v) ? 0 : v;

        // ✅ Fix RTL numbers (force LTR)
        private static string LRM(string? s) => "\u200E" + (s ?? "");
        private static string Money0(double v) => LRM(SafeMoney(v).ToString("N0", UiCulture));
        private static string Money2(double v) => LRM(SafeMoney(v).ToString("N2", UiCulture));

        private static void SafeSetText(TextBlock? t, string? text, Brush? fg = null)
        {
            try
            {
                if (t == null) return;
                t.Text = text ?? "";
                if (fg != null) t.Foreground = fg;
            }
            catch { }
        }

        private static void SafeSetBorder(Border? b, Brush brush)
        {
            try { if (b != null) b.BorderBrush = brush; } catch { }
        }

        // ===================== CompanyId Resolver (Source of Truth) =====================

        private static int TryGetCompanyIdFromApp()
        {
            try
            {
                var props = Application.Current?.Properties;
                if (props == null) return 0;

                if (props.Contains("CurrentCompanyId"))
                {
                    var v = props["CurrentCompanyId"];
                    if (v != null && int.TryParse(v.ToString(), out var cid))
                        return cid;
                }
            }
            catch { }
            return 0;
        }

        /// <summary>
        /// ✅ Source of truth:
        /// 1) Application.Current.Properties["CurrentCompanyId"]
        /// 2) fallback: DashboardView.CurrentCompanyId (legacy)
        /// + sync fallback back to static to keep old code consistent
        /// </summary>
        private static int ResolveCompanyId()
        {
            var cid = TryGetCompanyIdFromApp();
            if (cid <= 0) cid = CurrentCompanyId;

            if (cid > 0 && CurrentCompanyId != cid)
                CurrentCompanyId = cid;

            return cid;
        }

        private static bool EnsureCompanySelected(out int companyId)
        {
            companyId = ResolveCompanyId();
            return companyId > 0;
        }

        private static bool TrySetTenant(AppDbContext db, out int companyId)
        {
            companyId = ResolveCompanyId();
            if (companyId <= 0) return false;

            db.CurrentCompanyId = companyId;
            return true;
        }

        // -------------------- Lifecycle --------------------
        private void DashboardView_Loaded(object sender, RoutedEventArgs e)
        {
            cbBranchFilter.SelectionChanged -= AnyFilterChanged;
            cbBranchFilter.SelectionChanged += AnyFilterChanged;

            cbPeriodFilter.SelectionChanged -= PeriodChanged;
            cbPeriodFilter.SelectionChanged += PeriodChanged;

            dpFrom.SelectedDateChanged -= AnyDateChanged;
            dpTo.SelectedDateChanged -= AnyDateChanged;
            dpFrom.SelectedDateChanged += AnyDateChanged;
            dpTo.SelectedDateChanged += AnyDateChanged;

            cbPeriodFilter.SelectedIndex = 2; // آخر 12 شهر
            dpTo.SelectedDate = DateTime.Today;
            dpFrom.SelectedDate = DateTime.Today.AddMonths(-12);

            if (!EnsureCompanySelected(out _))
            {
                MessageBox.Show("لازم تختار شركة قبل عرض لوحة التحكم.", "ZAIN BI",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _ = LoadBranchFilterAsync();
            SetupTimer();
            _ = LoadAnalyticsAsync();
        }

        private void DashboardView_Unloaded(object sender, RoutedEventArgs e)
        {
            try
            {
                _loadCts?.Cancel();
                _loadCts?.Dispose();
                _loadCts = null;
            }
            catch { }

            if (_refreshTimer != null)
            {
                _refreshTimer.Stop();
                _refreshTimer.Tick -= RefreshTimer_Tick;
                _refreshTimer = null;
            }
        }

        private void SetupTimer()
        {
            if (_refreshTimer != null) return;
            _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromMinutes(5) };
            _refreshTimer.Tick += RefreshTimer_Tick;
            _refreshTimer.Start();
        }

        private void RefreshTimer_Tick(object? sender, EventArgs e) => _ = LoadAnalyticsAsync();
        private void AnyFilterChanged(object sender, SelectionChangedEventArgs e) => _ = LoadAnalyticsAsync();

        private void PeriodChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyPeriodPreset();
            _ = LoadAnalyticsAsync();
        }

        private void AnyDateChanged(object? sender, SelectionChangedEventArgs e)
        {
            var txt = (cbPeriodFilter.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            if (txt.Contains("مخصص")) _ = LoadAnalyticsAsync();
        }

        private void btnRefreshNow_Click(object sender, RoutedEventArgs e) => _ = LoadAnalyticsAsync();

        private void ApplyPeriodPreset()
        {
            var today = DateTime.Today;
            dpTo.SelectedDate = today;

            var txt = (cbPeriodFilter.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "";
            if (txt.Contains("آخر 3")) dpFrom.SelectedDate = today.AddMonths(-3);
            else if (txt.Contains("آخر 6")) dpFrom.SelectedDate = today.AddMonths(-6);
            else dpFrom.SelectedDate = today.AddMonths(-12);
        }

        private string? GetSelectedBranchOrNull()
        {
            var it = cbBranchFilter.SelectedItem as ComboBoxItem;
            var name = it?.Content?.ToString()?.Trim();
            if (string.IsNullOrWhiteSpace(name)) return null;
            if (name == "جميع الفروع والمراكز") return null;
            return name;
        }

        private (DateTime from, DateTime to) GetSelectedRange()
        {
            var to = dpTo.SelectedDate ?? DateTime.Today;
            var from = dpFrom.SelectedDate ?? to.AddMonths(-12);
            if (from > to) (from, to) = (to, from);
            return (from.Date, to.Date.AddDays(1).AddTicks(-1));
        }

        // -------------------- Branch Filter --------------------
        private async Task LoadBranchFilterAsync()
        {
            try
            {
                using var db = new AppDbContext();
                if (!TrySetTenant(db, out _)) return;

                var docBranchesTask = db.Documents.AsNoTracking()
                    .Select(d => d.BranchName).Where(b => b != null && b != "")
                    .ToListAsync();

                var expBranchesTask = db.FinancialExpenses.AsNoTracking()
                    .Select(e => e.BranchName).Where(b => b != null && b != "")
                    .ToListAsync();

                var conBranchesTask = db.Contracts.AsNoTracking()
                    .Select(c => c.BranchName).Where(b => b != null && b != "")
                    .ToListAsync();

                await Task.WhenAll(docBranchesTask, expBranchesTask, conBranchesTask);

                var branches = docBranchesTask.Result
                    .Concat(expBranchesTask.Result)
                    .Concat(conBranchesTask.Result)
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(x => x!.Trim())
                    .Distinct()
                    .OrderBy(x => x)
                    .ToList();

                cbBranchFilter.Items.Clear();
                cbBranchFilter.Items.Add(new ComboBoxItem { Content = "جميع الفروع والمراكز" });
                foreach (var b in branches) cbBranchFilter.Items.Add(new ComboBoxItem { Content = b });
                cbBranchFilter.SelectedIndex = 0;
            }
            catch { }
        }

        // -------------------- Main Loader --------------------
        public async Task LoadAnalyticsAsync()
        {
            if (!EnsureCompanySelected(out _)) return;

            try { _loadCts?.Cancel(); _loadCts?.Dispose(); } catch { }
            _loadCts = new CancellationTokenSource();
            var ct = _loadCts.Token;

            if (!await _loadGate.WaitAsync(0)) return;
            _sw.Restart();

            try
            {
                using var db = new AppDbContext();
                if (!TrySetTenant(db, out _)) return;

                var today = DateTime.Today;

                var branch = GetSelectedBranchOrNull();
                var (from, to) = GetSelectedRange();

                var spanDays = (to.Date - from.Date).TotalDays;
                var prevTo = from.AddTicks(-1);
                var prevFrom = from.AddDays(-spanDays);

                IQueryable<Document> docsQ = db.Documents.AsNoTracking();
                IQueryable<FinancialExpense> expQ = db.FinancialExpenses.AsNoTracking();
                IQueryable<LeaseContract> conQ = db.Contracts.AsNoTracking();

                IQueryable<Payment> payQ = db.Payments
                    .AsNoTracking()
                    .Include(p => p.Contract);

                if (!string.IsNullOrWhiteSpace(branch))
                {
                    var bn = branch.Trim().ToLowerInvariant();

                    docsQ = docsQ.Where(d => (d.BranchName ?? "").Trim().ToLower() == bn);
                    expQ = expQ.Where(e => (e.BranchName ?? "").Trim().ToLower() == bn);
                    conQ = conQ.Where(c => (c.BranchName ?? "").Trim().ToLower() == bn);

                    payQ = payQ.Where(p => p.Contract != null && (p.Contract.BranchName ?? "").Trim().ToLower() == bn);
                }

                var docsTask = docsQ.ToListAsync(ct);
                var conTask = conQ.ToListAsync(ct);

                var expPeriodTask = expQ.Where(e => e.ExpenseDate >= from && e.ExpenseDate <= to).ToListAsync(ct);
                var expPrevTask = expQ.Where(e => e.ExpenseDate >= prevFrom && e.ExpenseDate <= prevTo).ToListAsync(ct);

                var payPeriodDueTask = payQ.Where(p => p.DueDate >= from && p.DueDate <= to).ToListAsync(ct);
                var payPrevDueTask = payQ.Where(p => p.DueDate >= prevFrom && p.DueDate <= prevTo).ToListAsync(ct);

                var payPeriodPaidTask = payQ.Where(p => p.IsPaid && p.PaidAt != null && p.PaidAt.Value >= from && p.PaidAt.Value <= to).ToListAsync(ct);
                var payPrevPaidTask = payQ.Where(p => p.IsPaid && p.PaidAt != null && p.PaidAt.Value >= prevFrom && p.PaidAt.Value <= prevTo).ToListAsync(ct);

                await Task.WhenAll(docsTask, conTask, expPeriodTask, expPrevTask, payPeriodDueTask, payPrevDueTask, payPeriodPaidTask, payPrevPaidTask);
                ct.ThrowIfCancellationRequested();

                var docs = docsTask.Result ?? new List<Document>();
                var contracts = conTask.Result ?? new List<LeaseContract>();
                var expPeriod = expPeriodTask.Result ?? new List<FinancialExpense>();
                var expPrev = expPrevTask.Result ?? new List<FinancialExpense>();

                var payDuePeriod = payPeriodDueTask.Result ?? new List<Payment>();
                var payDuePrev = payPrevDueTask.Result ?? new List<Payment>();

                var payPaidPeriod = payPeriodPaidTask.Result ?? new List<Payment>();
                var payPaidPrev = payPrevPaidTask.Result ?? new List<Payment>();

                CalculateKPIsAndDeltas(docs, contracts, expPeriod, expPrev, today);

                await ApplyBudgetVarianceToExistingDeltasAsync(db, branch, from, to, expPeriod, ct);

                CalculateFinanceKPIs_FromPayments(payDuePeriod, payDuePrev, payPaidPeriod, payPaidPrev, expPeriod, expPrev, today);

                UpdateTrendWithForecast(expPeriod);
                UpdateCategoryChart(expPeriod);
                UpdateStatusChartFromContracts(contracts, today);

                await UpdateTopBranchesAsync(db, from, to, ct);
                await BuildHeatmapOptimizedAsync(db, today, ct);

                GenerateInsights(docs, contracts, expPeriod, expPrev, today);
                AppendWhatChangedSummary(expPeriod, expPrev, contracts, today);

                txtLastRefresh.Text = DateTime.Now.ToString("HH:mm:ss", UiCulture);

                _sw.Stop();
                txtPerfLog.Text = $"Refresh={_sw.ElapsedMilliseconds}ms | Contracts={contracts.Count} | Docs={docs.Count} | Exp={expPeriod.Count} | PayDue={payDuePeriod.Count} | PayPaid={payPaidPeriod.Count}";
            }
            catch (OperationCanceledException) { }
            catch (Exception ex)
            {
                MessageBox.Show($"خطأ في الداشبورد: {ex.Message}", "ZAIN BI", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            finally
            {
                _loadGate.Release();
            }
        }

        // -------------------- KPIs --------------------
        private void CalculateKPIsAndDeltas(
            List<Document> docs,
            List<LeaseContract> contracts,
            List<FinancialExpense> curExp,
            List<FinancialExpense> prevExp,
            DateTime today)
        {
            (string text, Brush brush) Delta(double cur, double prev)
            {
                cur = SafeMoney(cur);
                prev = SafeMoney(prev);

                if (prev <= 0 && cur <= 0) return ("—", Brushes.Gray);
                if (prev <= 0) return ("↑ جديد (أساس=0)", Brushes.SeaGreen);

                var pct = ((cur - prev) / prev) * 100.0;
                if (pct > 0) return ($"↑ {pct:0.0}% عن السابقة", pct >= 25 ? Brushes.Crimson : Brushes.SeaGreen);
                if (pct < 0) return ($"↓ {Math.Abs(pct):0.0}% عن السابقة", Brushes.SeaGreen);
                return ("↔️ 0.0% ثابت", Brushes.Gray);
            }

            double ExpTotal(List<FinancialExpense> list)
                => list.Sum(e => (double)e.Amount + (double)e.TaxAmount);

            double ExpByCategory(List<FinancialExpense> list, string key)
                => list.Where(e => ((e.Category ?? "").Contains(key)))
                       .Sum(e => (double)e.Amount + (double)e.TaxAmount);

            decimal totalRent = contracts.Where(c => IsActiveContract(c, today)).Sum(c => c.TotalAmount);
            txtTotalRentals.Text = LRM(totalRent.ToString("N0", UiCulture));
            txtTotalRentalsDelta.Text = $"📌 عقود سارية: {contracts.Count(c => IsActiveContract(c, today))}";
            txtTotalRentalsDelta.Foreground = Brushes.Gray;

            double curVat = contracts.Sum(c => (double)c.VatAmount) + curExp.Sum(e => (double)e.TaxAmount) + docs.Sum(d => (double)d.VatAmount);
            double prevVat = contracts.Sum(c => (double)c.VatAmount) + prevExp.Sum(e => (double)e.TaxAmount) + docs.Sum(d => (double)d.VatAmount);
            txtTaxExposure.Text = Money2(curVat);
            var dv = Delta(curVat, prevVat);
            txtTaxExposureDelta.Text = dv.text;
            txtTaxExposureDelta.Foreground = dv.brush;

            int archivedCount = docs.Count(d => d.IsArchived || !string.IsNullOrWhiteSpace(d.FilePath));
            double archive = docs.Any() ? (double)archivedCount / docs.Count * 100 : 0;
            txtArchiveQuality.Text = LRM($"{archive:F1}%");
            txtArchiveQualityDelta.Text = $"📁 مؤرشف: {archivedCount}/{docs.Count}";
            txtArchiveQualityDelta.Foreground = Brushes.Gray;

            double curElec = ExpByCategory(curExp, "كهرباء");
            double prevElec = ExpByCategory(prevExp, "كهرباء");
            txtElectricityCost.Text = Money0(curElec);
            var de = Delta(curElec, prevElec);
            txtElectricityDelta.Text = de.text; txtElectricityDelta.Foreground = de.brush;

            double curWater = ExpByCategory(curExp, "مياه");
            double prevWater = ExpByCategory(prevExp, "مياه");
            txtWaterCost.Text = Money0(curWater);
            var dw = Delta(curWater, prevWater);
            txtWaterDelta.Text = dw.text; txtWaterDelta.Foreground = dw.brush;

            int expired = contracts.Count(c => IsExpiredContract(c, today));
            txtExpiredRisk.Text = LRM(expired.ToString(UiCulture));
            txtExpiredDelta.Text = expired > 0 ? "⚠️ يتطلب معالجة" : "✅ لا يوجد";
            txtExpiredDelta.Foreground = expired > 0 ? Brushes.Crimson : Brushes.SeaGreen;

            int warning = contracts.Count(c => IsWarningContract(c, today));
            txtWarningContracts.Text = LRM(warning.ToString(UiCulture));
            txtWarningDelta.Text = warning > 0 ? "🔔 متابعة مطلوبة" : "✅ لا يوجد";
            txtWarningDelta.Foreground = warning > 0 ? Brushes.DarkOrange : Brushes.SeaGreen;

            double avg = contracts.Any() ? contracts.Average(c => (double)c.TotalAmount) : 0;
            txtAvgContractValue.Text = Money0(avg);
            txtAvgDelta.Text = contracts.Any() ? "✅ محسوب من عقود الإيجار" : "—";
            txtAvgDelta.Foreground = Brushes.Gray;

            double curOpex = ExpTotal(curExp);
            double prevOpex = ExpTotal(prevExp);
            txtTotalOpex.Text = Money0(curOpex);
            var dox = Delta(curOpex, prevOpex);
            txtOpexDelta.Text = dox.text; txtOpexDelta.Foreground = dox.brush;

            double compliance = contracts.Any()
                ? (double)contracts.Count(c => IsActiveContract(c, today)) / contracts.Count * 100
                : 0;

            pbCompliance.Value = Math.Round(compliance, 1);
            txtComplianceValue.Text = LRM($"{compliance:0.0}%");
            txtComplianceDelta.Text = compliance >= 85 ? "🟢 ممتاز" : compliance >= 65 ? "🟡 متوسط" : "🔴 منخفض";
            txtComplianceDelta.Foreground = compliance >= 85 ? Brushes.SeaGreen : compliance >= 65 ? Brushes.DarkOrange : Brushes.Crimson;

            SafeSetBorder(cardCompliance, compliance >= 85 ? Brushes.SeaGreen : compliance >= 65 ? Brushes.DarkOrange : Brushes.Crimson);
            SafeSetBorder(cardOpex, (prevOpex > 0 && curOpex > prevOpex * 1.25) ? Brushes.Crimson : Brushes.SeaGreen);
            SafeSetBorder(cardElec, (prevElec > 0 && curElec > prevElec * 1.5) ? Brushes.Crimson : Brushes.DarkOrange);
            SafeSetBorder(cardWater, (prevWater > 0 && curWater > prevWater * 1.5) ? Brushes.Crimson : Brushes.DarkOrange);
        }

        // ===================== ✅ Budget vs Actual (Variance Analyzer) =====================

        private sealed class BudgetPack
        {
            public double OpexBudget { get; set; }
            public double ElectricityBudget { get; set; }
            public double WaterBudget { get; set; }
            public bool HasAny => OpexBudget > 0 || ElectricityBudget > 0 || WaterBudget > 0;
        }

        private static string VarianceText(double actual, double budget)
        {
            actual = SafeMoney(actual);
            budget = SafeMoney(budget);

            if (budget <= 0) return "Budget: —";
            var varAbs = actual - budget;
            var pct = (budget > 0) ? (varAbs / budget) * 100.0 : 0;

            var sign = varAbs > 0 ? "Over" : varAbs < 0 ? "Under" : "On";
            varAbs = Math.Abs(varAbs);

            return $"Budget={Money0(budget)} | Var={LRM(varAbs.ToString("N0", UiCulture))} ({sign} {LRM(Math.Abs(pct).ToString("0.0", UiCulture))}%)";
        }

        private static Brush VarianceBrush(double actual, double budget)
        {
            if (budget <= 0) return Brushes.Gray;
            var diff = actual - budget;
            if (diff > budget * 0.15) return Brushes.Crimson;
            if (diff > 0) return Brushes.DarkOrange;
            if (diff < 0) return Brushes.SeaGreen;
            return Brushes.Gray;
        }

        private async Task ApplyBudgetVarianceToExistingDeltasAsync(
            AppDbContext db,
            string? selectedBranch,
            DateTime from,
            DateTime to,
            List<FinancialExpense> expPeriod,
            CancellationToken ct)
        {
            try
            {
                var budget = await ReadBudgetsFromSqliteAsync(db, selectedBranch, from, to, ct);
                if (budget == null || !budget.HasAny) return;

                double actualOpex = expPeriod.Sum(e => (double)e.Amount + (double)e.TaxAmount);
                double actualElec = expPeriod.Where(e => (e.Category ?? "").Contains("كهرباء"))
                    .Sum(e => (double)e.Amount + (double)e.TaxAmount);
                double actualWater = expPeriod.Where(e => (e.Category ?? "").Contains("مياه"))
                    .Sum(e => (double)e.Amount + (double)e.TaxAmount);

                if (budget.OpexBudget > 0)
                {
                    txtOpexDelta.Text = $"{txtOpexDelta.Text}  |  🎯 {VarianceText(actualOpex, budget.OpexBudget)}";
                    txtOpexDelta.Foreground = VarianceBrush(actualOpex, budget.OpexBudget);
                    SafeSetBorder(cardOpex, VarianceBrush(actualOpex, budget.OpexBudget));
                }

                if (budget.ElectricityBudget > 0)
                {
                    txtElectricityDelta.Text = $"{txtElectricityDelta.Text}  |  🎯 {VarianceText(actualElec, budget.ElectricityBudget)}";
                    txtElectricityDelta.Foreground = VarianceBrush(actualElec, budget.ElectricityBudget);
                    SafeSetBorder(cardElec, VarianceBrush(actualElec, budget.ElectricityBudget));
                }

                if (budget.WaterBudget > 0)
                {
                    txtWaterDelta.Text = $"{txtWaterDelta.Text}  |  🎯 {VarianceText(actualWater, budget.WaterBudget)}";
                    txtWaterDelta.Foreground = VarianceBrush(actualWater, budget.WaterBudget);
                    SafeSetBorder(cardWater, VarianceBrush(actualWater, budget.WaterBudget));
                }

                if (lstInsights != null)
                {
                    AddInsight("📊 Budget vs Actual مفعل: تم احتساب الانحرافات (OPEX/كهرباء/مياه) حسب الفترة المختارة.", Brushes.SeaGreen);
                }
            }
            catch { }
        }

        private async Task<BudgetPack> ReadBudgetsFromSqliteAsync(
            AppDbContext db,
            string? selectedBranch,
            DateTime from,
            DateTime to,
            CancellationToken ct)
        {
            var pack = new BudgetPack();

            var conn = db.Database.GetDbConnection();
            if (conn.State != System.Data.ConnectionState.Open)
                await conn.OpenAsync(ct);

            var cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            using (var cmd = conn.CreateCommand())
            {
                cmd.CommandText = "PRAGMA table_info('BranchBudgets');";
                using var r = await cmd.ExecuteReaderAsync(ct);
                while (await r.ReadAsync(ct))
                {
                    var name = r["name"]?.ToString();
                    if (!string.IsNullOrWhiteSpace(name)) cols.Add(name);
                }
            }
            if (cols.Count == 0) return pack;

            bool hasBranchId = cols.Contains("BranchId");
            bool hasBranchName = cols.Contains("BranchName");
            bool hasYear = cols.Contains("Year");
            bool hasMonth = cols.Contains("Month");

            bool hasAmount = cols.Contains("Amount");
            bool hasCategory = cols.Contains("Category");

            bool hasOpexBudget = cols.Contains("OpexBudget") || cols.Contains("BudgetOpex") || cols.Contains("TotalBudget");
            bool hasElecBudget = cols.Contains("ElectricityBudget") || cols.Contains("BudgetElectricity");
            bool hasWaterBudget = cols.Contains("WaterBudget") || cols.Contains("BudgetWater");

            int? branchId = null;
            if (!string.IsNullOrWhiteSpace(selectedBranch) && hasBranchId)
            {
                branchId = await db.Branches.AsNoTracking()
                    .Where(b => (b.BranchName ?? "").Trim().ToLower() == selectedBranch.Trim().ToLower())
                    .Select(b => (int?)b.Id)
                    .FirstOrDefaultAsync(ct);
            }

            var start = new DateTime(from.Year, from.Month, 1);
            var end = new DateTime(to.Year, to.Month, 1);

            var months = new List<(int y, int m)>();
            for (var d = start; d <= end; d = d.AddMonths(1))
                months.Add((d.Year, d.Month));

            if (hasAmount && hasCategory && hasYear && hasMonth)
            {
                foreach (var (y, m) in months)
                {
                    using var cmd = conn.CreateCommand();

                    var where = "WHERE Year=@y AND Month=@m";
                    if (!string.IsNullOrWhiteSpace(selectedBranch))
                    {
                        if (hasBranchId && branchId.HasValue)
                            where += " AND BranchId=@bid";
                        else if (hasBranchName)
                            where += " AND lower(trim(BranchName))=lower(trim(@bname))";
                    }

                    cmd.CommandText = $@"
SELECT Category, Amount
FROM BranchBudgets
{where};";

                    var pY = cmd.CreateParameter(); pY.ParameterName = "@y"; pY.Value = y; cmd.Parameters.Add(pY);
                    var pM = cmd.CreateParameter(); pM.ParameterName = "@m"; pM.Value = m; cmd.Parameters.Add(pM);

                    if (!string.IsNullOrWhiteSpace(selectedBranch))
                    {
                        if (hasBranchId && branchId.HasValue)
                        {
                            var pB = cmd.CreateParameter(); pB.ParameterName = "@bid"; pB.Value = branchId.Value; cmd.Parameters.Add(pB);
                        }
                        else if (hasBranchName)
                        {
                            var pB = cmd.CreateParameter(); pB.ParameterName = "@bname"; pB.Value = selectedBranch; cmd.Parameters.Add(pB);
                        }
                    }

                    using var r = await cmd.ExecuteReaderAsync(ct);
                    while (await r.ReadAsync(ct))
                    {
                        var cat = (r["Category"]?.ToString() ?? "").Trim().ToLowerInvariant();
                        var amountObj = r["Amount"];
                        double amount = 0;
                        if (amountObj != null && double.TryParse(amountObj.ToString(), out var dv)) amount = dv;

                        if (string.IsNullOrWhiteSpace(cat) || cat.Contains("opex") || cat.Contains("مصروف") || cat.Contains("تشغيل"))
                            pack.OpexBudget += amount;
                        else if (cat.Contains("كهرباء") || cat.Contains("electric"))
                            pack.ElectricityBudget += amount;
                        else if (cat.Contains("مياه") || cat.Contains("water"))
                            pack.WaterBudget += amount;
                        else
                            pack.OpexBudget += amount;
                    }
                }

                return pack;
            }

            if ((hasOpexBudget || hasElecBudget || hasWaterBudget) && hasYear && hasMonth)
            {
                string? colOpex = cols.Contains("OpexBudget") ? "OpexBudget" :
                                  cols.Contains("BudgetOpex") ? "BudgetOpex" :
                                  cols.Contains("TotalBudget") ? "TotalBudget" : null;

                string? colElec = cols.Contains("ElectricityBudget") ? "ElectricityBudget" :
                                  cols.Contains("BudgetElectricity") ? "BudgetElectricity" : null;

                string? colWater = cols.Contains("WaterBudget") ? "WaterBudget" :
                                   cols.Contains("BudgetWater") ? "BudgetWater" : null;

                foreach (var (y, m) in months)
                {
                    using var cmd = conn.CreateCommand();

                    var selectCols = new List<string>();
                    if (!string.IsNullOrWhiteSpace(colOpex)) selectCols.Add(colOpex);
                    if (!string.IsNullOrWhiteSpace(colElec)) selectCols.Add(colElec);
                    if (!string.IsNullOrWhiteSpace(colWater)) selectCols.Add(colWater);

                    var where = "WHERE Year=@y AND Month=@m";
                    if (!string.IsNullOrWhiteSpace(selectedBranch))
                    {
                        if (hasBranchId && branchId.HasValue)
                            where += " AND BranchId=@bid";
                        else if (hasBranchName)
                            where += " AND lower(trim(BranchName))=lower(trim(@bname))";
                    }

                    cmd.CommandText = $@"
SELECT {string.Join(",", selectCols)}
FROM BranchBudgets
{where};";

                    var pY = cmd.CreateParameter(); pY.ParameterName = "@y"; pY.Value = y; cmd.Parameters.Add(pY);
                    var pM = cmd.CreateParameter(); pM.ParameterName = "@m"; pM.Value = m; cmd.Parameters.Add(pM);

                    if (!string.IsNullOrWhiteSpace(selectedBranch))
                    {
                        if (hasBranchId && branchId.HasValue)
                        {
                            var pB = cmd.CreateParameter(); pB.ParameterName = "@bid"; pB.Value = branchId.Value; cmd.Parameters.Add(pB);
                        }
                        else if (hasBranchName)
                        {
                            var pB = cmd.CreateParameter(); pB.ParameterName = "@bname"; pB.Value = selectedBranch; cmd.Parameters.Add(pB);
                        }
                    }

                    using var r = await cmd.ExecuteReaderAsync(ct);
                    while (await r.ReadAsync(ct))
                    {
                        double ReadDouble(string? c)
                        {
                            if (string.IsNullOrWhiteSpace(c)) return 0;
                            try
                            {
                                var obj = r[c];
                                if (obj == null) return 0;
                                if (double.TryParse(obj.ToString(), out var dv)) return dv;
                                return 0;
                            }
                            catch { return 0; }
                        }

                        pack.OpexBudget += ReadDouble(colOpex);
                        pack.ElectricityBudget += ReadDouble(colElec);
                        pack.WaterBudget += ReadDouble(colWater);
                    }
                }

                return pack;
            }

            return pack;
        }

        // ===================== ✅ Finance KPIs =====================
        private void CalculateFinanceKPIs_FromPayments(
            List<Payment> curPaysDue,
            List<Payment> prevPaysDue,
            List<Payment> curPaysPaid,
            List<Payment> prevPaysPaid,
            List<FinancialExpense> curExp,
            List<FinancialExpense> prevExp,
            DateTime today)
        {
            (string text, Brush brush) Delta(double cur, double prev)
            {
                cur = SafeMoney(cur);
                prev = SafeMoney(prev);

                if (prev <= 0 && cur <= 0) return ("—", Brushes.Gray);
                if (prev <= 0) return ("↑ جديد (أساس=0)", Brushes.SeaGreen);

                var pct = ((cur - prev) / prev) * 100.0;
                if (pct > 0) return ($"↑ {pct:0.0}% عن السابقة", pct >= 25 ? Brushes.Crimson : Brushes.SeaGreen);
                if (pct < 0) return ($"↓ {Math.Abs(pct):0.0}% عن السابقة", Brushes.SeaGreen);
                return ("↔️ 0.0% ثابت", Brushes.Gray);
            }

            PaymentDirection FixDir(Payment p)
            {
                if ((int)p.Direction == 0) return PaymentDirection.Incoming;
                return p.Direction;
            }

            double ExpTotal(List<FinancialExpense> list)
                => list.Sum(e => (double)e.Amount + (double)e.TaxAmount);

            double curOpex = SafeMoney(ExpTotal(curExp));
            double prevOpex = SafeMoney(ExpTotal(prevExp));

            double curIncomingAccrual = curPaysDue.Where(p => FixDir(p) == PaymentDirection.Incoming).Sum(p => (double)p.Amount);
            double curOutgoingAccrual = curPaysDue.Where(p => FixDir(p) == PaymentDirection.Outgoing).Sum(p => (double)p.Amount);

            double prevIncomingAccrual = prevPaysDue.Where(p => FixDir(p) == PaymentDirection.Incoming).Sum(p => (double)p.Amount);
            double prevOutgoingAccrual = prevPaysDue.Where(p => FixDir(p) == PaymentDirection.Outgoing).Sum(p => (double)p.Amount);

            double curNetProfit = SafeMoney(curIncomingAccrual - curOutgoingAccrual - curOpex);
            double prevNetProfit = SafeMoney(prevIncomingAccrual - prevOutgoingAccrual - prevOpex);

            SafeSetText(txtNetProfit, Money0(curNetProfit));
            var dnp = Delta(curNetProfit, prevNetProfit);
            SafeSetText(txtNetProfitDelta, dnp.text, dnp.brush);
            SafeSetBorder(cardNetProfit, curNetProfit < 0 ? Brushes.Crimson : Brushes.SeaGreen);

            double curIncomingPaid = curPaysPaid.Where(p => FixDir(p) == PaymentDirection.Incoming).Sum(p => (double)p.Amount);
            double curOutgoingPaid = curPaysPaid.Where(p => FixDir(p) == PaymentDirection.Outgoing).Sum(p => (double)p.Amount);

            double prevIncomingPaid = prevPaysPaid.Where(p => FixDir(p) == PaymentDirection.Incoming).Sum(p => (double)p.Amount);
            double prevOutgoingPaid = prevPaysPaid.Where(p => FixDir(p) == PaymentDirection.Outgoing).Sum(p => (double)p.Amount);

            double curCashFlow = SafeMoney(curIncomingPaid - curOutgoingPaid - curOpex);
            double prevCashFlow = SafeMoney(prevIncomingPaid - prevOutgoingPaid - prevOpex);

            SafeSetText(txtCashFlow, Money0(curCashFlow));
            var dcf = Delta(curCashFlow, prevCashFlow);
            SafeSetText(txtCashFlowDelta, dcf.text, dcf.brush);
            SafeSetBorder(cardCashFlow, curCashFlow < 0 ? Brushes.Crimson : Brushes.SeaGreen);

            double ar = curPaysDue
                .Where(p => FixDir(p) == PaymentDirection.Incoming && !p.IsPaid && p.DueDate.Date <= today.Date)
                .Sum(p => (double)p.Amount);

            double ap = curPaysDue
                .Where(p => FixDir(p) == PaymentDirection.Outgoing && !p.IsPaid && p.DueDate.Date <= today.Date)
                .Sum(p => (double)p.Amount);

            SafeSetText(txtAR, Money0(ar));
            SafeSetText(txtARDelta, ar > 0 ? "🔔 تحصيلات متأخرة" : "✅ لا يوجد متأخرات تحصيل", ar > 0 ? Brushes.DarkOrange : Brushes.SeaGreen);
            SafeSetBorder(cardAR, ar > 0 ? Brushes.DarkOrange : Brushes.SeaGreen);

            SafeSetText(txtAP, Money0(ap));
            SafeSetText(txtAPDelta, ap > 0 ? "⚠️ سداد متأخر" : "✅ لا يوجد متأخرات سداد", ap > 0 ? Brushes.Crimson : Brushes.SeaGreen);
            SafeSetBorder(cardAP, ap > 0 ? Brushes.Crimson : Brushes.SeaGreen);

            double curInputVat = SafeMoney(curExp.Sum(e => (double)e.TaxAmount));
            double curVatPayable = SafeMoney(0 - curInputVat);

            SafeSetText(txtVatPayable, Money2(curVatPayable));
            SafeSetText(txtVatPayableDelta, "ℹ️ مؤقت: يعتمد على VAT المصروفات فقط (بدون VAT مبيعات)", Brushes.Gray);
            SafeSetBorder(cardVatPayable, Brushes.Gray);
        }

        // -------------------- Charts --------------------
        private void UpdateTrendWithForecast(List<FinancialExpense> exp)
        {
            try { chartMonthlyTrend.FlowDirection = FlowDirection.LeftToRight; } catch { }

            var monthly = exp
                .GroupBy(e => new { e.ExpenseDate.Year, e.ExpenseDate.Month })
                .Select(g => new
                {
                    Date = new DateTime(g.Key.Year, g.Key.Month, 1),
                    Total = g.Sum(x => (double)x.Amount) + g.Sum(x => (double)x.TaxAmount)
                })
                .OrderBy(x => x.Date)
                .ToList();

            var last = monthly.TakeLast(12).ToList();
            var actual = last.Select(x => SafeMoney(x.Total)).ToList();

            double forecast = 0;
            if (actual.Count >= 3)
                forecast = SafeMoney(actual[^1] * 0.5 + actual[^2] * 0.3 + actual[^3] * 0.2);
            else if (actual.Count > 0)
                forecast = SafeMoney(actual.Average());

            var labels = last.Select(x => LRM(x.Date.ToString("MM/yyyy", UiCulture))).ToList();
            labels.Add(LRM((last.Count > 0 ? last.Last().Date.AddMonths(1) : DateTime.Today.AddMonths(1)).ToString("MM/yyyy", UiCulture)));

            var strokeActual = new SolidColorPaint(new SKColor(37, 99, 235)) { StrokeThickness = 3 };
            var strokeForecast = new SolidColorPaint(new SKColor(147, 51, 234)) { StrokeThickness = 3 };
            strokeForecast.PathEffect = new LiveChartsCore.SkiaSharpView.Painting.Effects.DashEffect(new float[] { 6, 6 });

            chartMonthlyTrend.Series = new ISeries[]
            {
                new LineSeries<double>
                {
                    Name = "Actual OPEX",
                    Values = actual,
                    Stroke = strokeActual,
                    Fill = null,
                    GeometrySize = 8,
                    LineSmoothness = 0.35
                },
                new LineSeries<double>
                {
                    Name = "Forecast",
                    Values = BuildForecastLine(actual, forecast),
                    Stroke = strokeForecast,
                    Fill = null,
                    GeometrySize = 8,
                    LineSmoothness = 0.35
                }
            };

            chartMonthlyTrend.XAxes = new Axis[]
            {
                new Axis { Name = "Month", Labels = labels.ToArray() }
            };

            chartMonthlyTrend.YAxes = new Axis[]
            {
                new Axis { Name = "SAR", Labeler = v => Money0(v) }
            };

            chartMonthlyTrend.AnimationsSpeed = TimeSpan.FromMilliseconds(650);
        }

        private static List<double> BuildForecastLine(List<double> actual, double forecast)
        {
            var values = new List<double>();
            if (actual.Count == 0) { values.Add(forecast); return values; }
            for (int i = 0; i < actual.Count - 1; i++) values.Add(double.NaN);
            values.Add(actual[^1]);
            values.Add(forecast);
            return values;
        }

        private void UpdateCategoryChart(List<FinancialExpense> exp)
        {
            try { chartCategoryDist.FlowDirection = FlowDirection.LeftToRight; } catch { }

            var cats = exp
                .GroupBy(e => e.Category ?? "Other")
                .Select(g => new
                {
                    Name = g.Key,
                    Total = g.Sum(x => (double)x.Amount) + g.Sum(x => (double)x.TaxAmount)
                })
                .OrderByDescending(x => x.Total)
                .Take(8)
                .ToList();

            var palette = new[]
            {
                new SKColor(37, 99, 235),
                new SKColor(34, 197, 94),
                new SKColor(249, 115, 22),
                new SKColor(168, 85, 247),
                new SKColor(239, 68, 68),
                new SKColor(20, 184, 166),
                new SKColor(234, 179, 8),
                new SKColor(100, 116, 139),
            };

            var series = new List<ISeries>();
            for (int i = 0; i < cats.Count; i++)
            {
                var c = cats[i];
                var color = palette[i % palette.Length];

                series.Add(new PieSeries<double>
                {
                    Name = c.Name,
                    Values = new[] { SafeMoney(c.Total) },
                    DataLabelsSize = 12,
                    DataLabelsPaint = new SolidColorPaint(SKColors.White),
                    Fill = new SolidColorPaint(color),
                    Stroke = new SolidColorPaint(SKColors.White) { StrokeThickness = 2 }
                });
            }

            chartCategoryDist.Series = series.ToArray();
            chartCategoryDist.AnimationsSpeed = TimeSpan.FromMilliseconds(650);
        }

        private void UpdateStatusChartFromContracts(List<LeaseContract> contracts, DateTime today)
        {
            try { chartStatus.FlowDirection = FlowDirection.LeftToRight; } catch { }

            int active = contracts.Count(c => IsActiveContract(c, today));
            int expired = contracts.Count(c => IsExpiredContract(c, today));
            int warn = contracts.Count(c => IsWarningContract(c, today));

            chartStatus.Series = new ISeries[]
            {
                new PieSeries<int> { Name = "Active", Values = new[] { active }, Fill = new SolidColorPaint(new SKColor(34, 197, 94)), DataLabelsPaint = new SolidColorPaint(SKColors.White), DataLabelsSize = 12 },
                new PieSeries<int> { Name = "Expired", Values = new[] { expired }, Fill = new SolidColorPaint(new SKColor(239, 68, 68)), DataLabelsPaint = new SolidColorPaint(SKColors.White), DataLabelsSize = 12 },
                new PieSeries<int> { Name = "Expiring", Values = new[] { warn }, Fill = new SolidColorPaint(new SKColor(249, 115, 22)), DataLabelsPaint = new SolidColorPaint(SKColors.White), DataLabelsSize = 12 }
            };

            chartStatus.AnimationsSpeed = TimeSpan.FromMilliseconds(650);
        }

        // -------------------- Top 5 branches --------------------
        private async Task UpdateTopBranchesAsync(AppDbContext db, DateTime from, DateTime to, CancellationToken ct)
        {
            try { chartBranchRanking.FlowDirection = FlowDirection.LeftToRight; } catch { }

            var allContracts = await db.Contracts.AsNoTracking().ToListAsync(ct);

            var contractsByBranch = allContracts
                .Where(c => !string.IsNullOrWhiteSpace(c.BranchName))
                .GroupBy(c => Norm(c.BranchName))
                .Select(g => new
                {
                    Key = g.Key,
                    Name = g.First().BranchName.Trim(),
                    Contracts = g.Sum(x => (double)x.TotalAmount)
                })
                .ToList();

            var opexByBranch = await db.FinancialExpenses.AsNoTracking()
                .Where(e => !string.IsNullOrWhiteSpace(e.BranchName) && e.ExpenseDate >= from && e.ExpenseDate <= to)
                .GroupBy(e => (e.BranchName ?? "").Trim().ToLower())
                .Select(g => new
                {
                    Key = g.Key,
                    Opex = g.Sum(x => (double)x.Amount) + g.Sum(x => (double)x.TaxAmount)
                })
                .ToListAsync(ct);

            var opexMap = opexByBranch.ToDictionary(x => x.Key, x => x.Opex);

            var top = contractsByBranch
                .Select(x => new
                {
                    Name = x.Name,
                    Contracts = SafeMoney(x.Contracts),
                    Opex = opexMap.ContainsKey(x.Key) ? SafeMoney(opexMap[x.Key]) : 0
                })
                .OrderByDescending(x => x.Contracts + x.Opex)
                .Take(5)
                .ToList();

            chartBranchRanking.Series = new ISeries[]
            {
                new ColumnSeries<double> { Name = "Contracts", Values = top.Select(x => x.Contracts).ToArray(), Fill = new SolidColorPaint(new SKColor(37, 99, 235)), Stroke = null },
                new ColumnSeries<double> { Name = "OPEX", Values = top.Select(x => x.Opex).ToArray(), Fill = new SolidColorPaint(new SKColor(249, 115, 22)), Stroke = null }
            };

            chartBranchRanking.XAxes = new Axis[]
            {
                new Axis { Labels = top.Select(x => x.Name).ToArray(), Name = "Branch" }
            };

            chartBranchRanking.YAxes = new Axis[]
            {
                new Axis { Name = "SAR", Labeler = v => Money0(v) }
            };

            chartBranchRanking.AnimationsSpeed = TimeSpan.FromMilliseconds(650);
        }

        // -------------------- Heatmap --------------------
        private sealed class HeatmapRow
        {
            public string Branch { get; set; } = "";
            public double Contracts { get; set; }
            public double Opex { get; set; }
            public double Compliance { get; set; }
            public string RiskLabel { get; set; } = "";
            public double HealthScore { get; set; }
        }

        private sealed class ExpenseAggRow
        {
            public string Key { get; set; } = "";
            public double Amount { get; set; }
            public double Tax { get; set; }
        }

        private async Task BuildHeatmapOptimizedAsync(AppDbContext db, DateTime today, CancellationToken ct)
        {
            var docBranchesTask = db.Documents.AsNoTracking()
                .Where(d => d.BranchName != null && d.BranchName != "")
                .Select(d => d.BranchName!)
                .ToListAsync(ct);

            var expBranchesTask = db.FinancialExpenses.AsNoTracking()
                .Where(e => e.BranchName != null && e.BranchName != "")
                .Select(e => e.BranchName!)
                .ToListAsync(ct);

            var conBranchesTask = db.Contracts.AsNoTracking()
                .Where(c => c.BranchName != null && c.BranchName != "")
                .Select(c => c.BranchName!)
                .ToListAsync(ct);

            await Task.WhenAll(docBranchesTask, expBranchesTask, conBranchesTask);

            var branches = docBranchesTask.Result
                .Concat(expBranchesTask.Result)
                .Concat(conBranchesTask.Result)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .ToList();

            var allContractsTask = db.Contracts.AsNoTracking().ToListAsync(ct);
            var allDocsTask = db.Documents.AsNoTracking().ToListAsync(ct);

            var expAggTask = db.FinancialExpenses.AsNoTracking()
                .Where(e => e.BranchName != null && e.BranchName != "")
                .GroupBy(e => (e.BranchName ?? "").Trim().ToLower())
                .Select(g => new ExpenseAggRow
                {
                    Key = g.Key,
                    Amount = g.Sum(x => (double)x.Amount),
                    Tax = g.Sum(x => (double)x.TaxAmount)
                })
                .ToListAsync(ct);

            await Task.WhenAll(allContractsTask, allDocsTask, expAggTask);

            var allContracts = allContractsTask.Result ?? new List<LeaseContract>();
            var allDocs = allDocsTask.Result ?? new List<Document>();
            var expAgg = expAggTask.Result ?? new List<ExpenseAggRow>();

            var expMap = expAgg.ToDictionary(
                x => x.Key,
                x => SafeMoney(x.Amount) + SafeMoney(x.Tax));

            var rows = new List<HeatmapRow>();

            foreach (var b in branches)
            {
                var bKey = Norm(b);

                var branchContracts = allContracts.Where(c => Norm(c.BranchName) == bKey).ToList();
                var branchDocs = allDocs.Where(d => Norm(d.BranchName) == bKey).ToList();

                double contractsValue = SafeMoney(branchContracts.Sum(c => (double)c.TotalAmount));

                double compliance = branchContracts.Any()
                    ? (double)branchContracts.Count(c => IsActiveContract(c, today)) / branchContracts.Count * 100
                    : 0;

                double expiredPenalty = branchContracts.Count(c => IsExpiredContract(c, today)) * 20;
                double warningPenalty = branchContracts.Count(c => IsWarningContract(c, today)) * 10;

                double opex = expMap.ContainsKey(bKey) ? expMap[bKey] : 0;

                int archivedDocs = branchDocs.Count(d => d.IsArchived || !string.IsNullOrWhiteSpace(d.FilePath));
                double docArchiveScore = branchDocs.Any() ? (double)archivedDocs / branchDocs.Count * 100 : 0;

                double opexScore = 100 - Math.Min(100, (opex / 200000.0) * 100);
                double riskPenalty = Math.Min(100, expiredPenalty + warningPenalty);

                double health = (compliance * 0.40) + ((100 - riskPenalty) * 0.25) + (opexScore * 0.20) + (docArchiveScore * 0.15);
                health = Math.Max(0, Math.Min(100, health));

                string risk =
                    (compliance < 60 || riskPenalty >= 50) ? "High" :
                    (compliance < 80 || riskPenalty >= 20) ? "Medium" : "Low";

                string riskLabel = risk == "High" ? "🔴 عالي" : risk == "Medium" ? "🟠 متوسط" : "🟢 منخفض";

                rows.Add(new HeatmapRow
                {
                    Branch = b,
                    Contracts = contractsValue,
                    Opex = opex,
                    Compliance = compliance,
                    RiskLabel = riskLabel,
                    HealthScore = health
                });
            }

            dgBranchHeatmap.ItemsSource = rows.OrderBy(x => x.HealthScore).Take(20).ToList();
        }

        // -------------------- Insights --------------------
        private void GenerateInsights(
            List<Document> docs,
            List<LeaseContract> contracts,
            List<FinancialExpense> curExp,
            List<FinancialExpense> prevExp,
            DateTime today)
        {
            lstInsights.Items.Clear();

            int expired = contracts.Count(c => IsExpiredContract(c, today));
            if (expired > 0) AddInsight($"⚠️ يوجد {expired} عقود منتهية - خطر امتثال.", Brushes.Crimson);

            int warning = contracts.Count(c => IsWarningContract(c, today));
            if (warning > 0) AddInsight($"🔔 {warning} عقود قريبة الانتهاء (30 يوم).", Brushes.DarkOrange);

            int archivedCount = docs.Count(d => d.IsArchived || !string.IsNullOrWhiteSpace(d.FilePath));
            if (docs.Any()) AddInsight($"📁 الأرشفة: {archivedCount}/{docs.Count} مستندات محفوظة.", Brushes.Gray);

            double SumTotal(List<FinancialExpense> list) => list.Sum(e => (double)e.Amount + (double)e.TaxAmount);

            double curOpex = SafeMoney(SumTotal(curExp));
            double prevOpex = SafeMoney(SumTotal(prevExp));

            if (prevOpex > 0 && curOpex > prevOpex * 1.25)
                AddInsight($"🚨 انحراف: المصروفات ارتفعت {((curOpex / prevOpex) - 1) * 100:0}% عن الفترة السابقة.", Brushes.Crimson);

            var topCat = curExp
                .GroupBy(e => e.Category ?? "Other")
                .Select(g => new { Cat = g.Key, Total = g.Sum(x => (double)x.Amount + (double)x.TaxAmount) })
                .OrderByDescending(x => x.Total)
                .FirstOrDefault();

            if (topCat != null && topCat.Total > 0)
                AddInsight($"📌 أعلى بند مصاريف: {topCat.Cat} = {Money0(topCat.Total)} SAR.", Brushes.Gray);

            AddInsight($"✅ Finance KPIs: NetProfit من DueDate و CashFlow من PaidAt.", Brushes.SeaGreen);
            AddInsight($"🔄 آخر تحديث: {DateTime.Now:HH:mm:ss}", Brushes.Gray);
        }

        private void AppendWhatChangedSummary(
            List<FinancialExpense> curExp,
            List<FinancialExpense> prevExp,
            List<LeaseContract> contracts,
            DateTime today)
        {
            double SumTotal(List<FinancialExpense> list) => list.Sum(e => (double)e.Amount + (double)e.TaxAmount);
            double curOpex = SafeMoney(SumTotal(curExp));
            double prevOpex = SafeMoney(SumTotal(prevExp));

            string deltaTxt;
            Brush deltaBrush;

            if (prevOpex <= 0 && curOpex <= 0) { deltaTxt = "لا تغيّر واضح في المصروفات (لا بيانات/0)."; deltaBrush = Brushes.Gray; }
            else if (prevOpex <= 0) { deltaTxt = "مصروفات جديدة ظهرت مقارنةً بالفترة السابقة (أساس=0)."; deltaBrush = Brushes.SeaGreen; }
            else
            {
                var pct = ((curOpex - prevOpex) / prevOpex) * 100.0;
                if (pct > 0) { deltaTxt = $"المصروفات زادت {pct:0.0}% عن الفترة السابقة."; deltaBrush = pct >= 25 ? Brushes.Crimson : Brushes.DarkOrange; }
                else if (pct < 0) { deltaTxt = $"المصروفات قلت {Math.Abs(pct):0.0}% عن الفترة السابقة."; deltaBrush = Brushes.SeaGreen; }
                else { deltaTxt = "المصروفات ثابتة تقريبًا."; deltaBrush = Brushes.Gray; }
            }

            int expired = contracts.Count(c => IsExpiredContract(c, today));
            int warning = contracts.Count(c => IsWarningContract(c, today));

            AddInsight($"📌 What changed: {deltaTxt}", deltaBrush);
            if (expired > 0 || warning > 0)
                AddInsight($"🧭 مخاطر العقود: منتهي={expired} | وشيك={warning}", (expired > 0) ? Brushes.Crimson : Brushes.DarkOrange);
        }

        private void AddInsight(string text, Brush color)
        {
            lstInsights.Items.Add(new TextBlock
            {
                Text = text,
                Foreground = color,
                FontWeight = FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap
            });
        }

        // -------------------- Quick Actions --------------------
        private void QA_ShowExpired_Click(object sender, RoutedEventArgs e)
            => MessageBox.Show("هنا هنفتح شاشة Drilldown للعقود المنتهية (الخطوة القادمة).", "ZAIN BI");

        private void QA_ShowWarnings_Click(object sender, RoutedEventArgs e)
            => MessageBox.Show("هنا هنفتح شاشة Drilldown للعقود القريبة الانتهاء (الخطوة القادمة).", "ZAIN BI");

        private void QA_ShowTopOpex_Click(object sender, RoutedEventArgs e)
            => MessageBox.Show("هنا هنطلع أعلى بنود OPEX + أعلى فروع (الخطوة القادمة).", "ZAIN BI");

        private void QA_ExportPdf_Click(object sender, RoutedEventArgs e)
            => MessageBox.Show("تقرير PDF سيُضاف بعد تثبيت قالب QuestPDF للداشبورد.", "ZAIN BI");

        private void QA_RunAudit_Click(object sender, RoutedEventArgs e)
            => MessageBox.Show("تشغيل تدقيق سريع: كشف تكرارات/نواقص/تواريخ منتهية (الخطوة القادمة).", "ZAIN BI");

        // -------------------- Export Excel --------------------
        private void btnExportStrategicReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using var workbook = new XLWorkbook();
                var ws = workbook.Worksheets.Add("Zain Strategic Report");
                ws.RightToLeft = true;

                var header = ws.Range("A1:F1");
                header.Merge().Value = "تقرير تحليل البيانات الاستراتيجي - " + DateTime.Now.ToShortDateString();
                header.Style.Fill.BackgroundColor = XLColor.FromHtml("#111827");
                header.Style.Font.FontColor = XLColor.White;
                header.Style.Font.Bold = true;
                header.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                using var db = new AppDbContext();
                if (!TrySetTenant(db, out _))
                {
                    MessageBox.Show("لازم تختار شركة قبل التصدير.", "Zain BI", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var data = db.Documents.AsNoTracking().Select(d => new
                {
                    الفرع = d.BranchName,
                    المؤجر = d.LessorName,
                    المبلغ = d.TotalAmount,
                    الضريبة = d.VatAmount,
                    الانتهاء = d.ExpiryDate,
                    الحالة = d.Status
                }).ToList();

                ws.Cell("A3").InsertTable(data);
                ws.Columns().AdjustToContents();

                var sfd = new Microsoft.Win32.SaveFileDialog
                {
                    Filter = "Excel|*.xlsx",
                    FileName = $"Zain_BI_Report_{DateTime.Now:yyyyMMdd}"
                };

                if (sfd.ShowDialog() == true)
                {
                    workbook.SaveAs(sfd.FileName);
                    MessageBox.Show("تم التصدير بنجاح", "Zain BI Center", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"خطأ في التصدير: {ex.Message}", "ZAIN BI", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // -------------------- AI Snapshot --------------------
        public string GetAiContextSnapshot()
        {
            string T(TextBlock t) => (t?.Text ?? "").Trim();
            string C(ComboBox c)
            {
                var it = c?.SelectedItem as ComboBoxItem;
                return it != null ? (it.Content?.ToString() ?? "").Trim() : (c?.Text ?? "").Trim();
            }
            string D(DatePicker p) => p?.SelectedDate?.ToString("yyyy-MM-dd") ?? "";

            var sb = new StringBuilder();
            sb.AppendLine("[Dashboard Snapshot]");
            sb.AppendLine($"- الفرع: {C(cbBranchFilter)}");
            sb.AppendLine($"- الفترة: {C(cbPeriodFilter)} | From={D(dpFrom)} | To={D(dpTo)}");
            sb.AppendLine($"- آخر تحديث: {T(txtLastRefresh)}");
            sb.AppendLine();
            sb.AppendLine("## KPIs");
            sb.AppendLine($"- إجمالي الإيجارات: {T(txtTotalRentals)} ريال | {T(txtTotalRentalsDelta)}");
            sb.AppendLine($"- VAT: {T(txtTaxExposure)} ريال | {T(txtTaxExposureDelta)}");
            sb.AppendLine($"- جودة الأرشفة: {T(txtArchiveQuality)} | {T(txtArchiveQualityDelta)}");
            sb.AppendLine($"- كهرباء: {T(txtElectricityCost)} ريال | {T(txtElectricityDelta)}");
            sb.AppendLine($"- مياه: {T(txtWaterCost)} ريال | {T(txtWaterDelta)}");
            sb.AppendLine($"- عقود منتهية: {T(txtExpiredRisk)} | {T(txtExpiredDelta)}");
            sb.AppendLine($"- قرب الانتهاء: {T(txtWarningContracts)} | {T(txtWarningDelta)}");
            sb.AppendLine($"- متوسط قيمة العقد: {T(txtAvgContractValue)} ريال | {T(txtAvgDelta)}");
            sb.AppendLine($"- المصروفات: {T(txtTotalOpex)} ريال | {T(txtOpexDelta)}");
            sb.AppendLine($"- الامتثال: {pbCompliance.Value:0.0}% | {T(txtComplianceDelta)}");

            sb.AppendLine();
            sb.AppendLine("## Finance KPIs");
            sb.AppendLine($"- Net Profit: {T(txtNetProfit)} | {T(txtNetProfitDelta)}");
            sb.AppendLine($"- Cash Flow: {T(txtCashFlow)} | {T(txtCashFlowDelta)}");
            sb.AppendLine($"- AR: {T(txtAR)} | {T(txtARDelta)}");
            sb.AppendLine($"- AP: {T(txtAP)} | {T(txtAPDelta)}");
            sb.AppendLine($"- VAT Payable: {T(txtVatPayable)} | {T(txtVatPayableDelta)}");

            return sb.ToString();
        }
    }
}