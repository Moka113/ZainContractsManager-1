﻿#nullable enable
using System;
using System.Configuration; // ✅ App.config
using System.Linq;
using System.Reflection;
using System.Windows;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using ZainContractsManager.Models.SaaS;
using ZainContractsManager.Services;
using ZainContractsManager.Services.Security;

namespace ZainContractsManager.Views
{
    public partial class RegisterWindow : Window
    {
        private readonly AuthService _auth;
        private readonly EmailOtpService _otp;

        private bool _otpVerified = false;
        private string _otpVerifiedEmail = "";

        // ✅ SMTP loaded from config
        private readonly string _smtpUser;
        private readonly string _smtpPass;

        public RegisterWindow() : this(new AuthService()) { }

        public RegisterWindow(AuthService auth)
        {
            InitializeComponent();
            _auth = auth ?? new AuthService();

            // ✅ اقرأ SMTP settings من App.config
            _smtpUser = ReadSetting("smtp.user", "");
            _smtpPass = ReadSetting("smtp.pass", "");

            var fromEmail = ReadSetting("smtp.fromEmail", _smtpUser);
            var fromName = ReadSetting("smtp.fromName", "ZAIN SYSTEM");
            var expiresMinutes = ReadIntSetting("otp.expiresMinutes", 5);
            var enableSsl = ReadBoolSetting("otp.enableSsl", true);

            // ✅ لو SMTP ناقص: اعرض تنبيه + اقفل زر الإرسال
            if (string.IsNullOrWhiteSpace(_smtpUser) || string.IsNullOrWhiteSpace(_smtpPass))
            {
                OtpStatusTxt.Text = "⚠️ إعدادات SMTP غير مكتملة في App.config (smtp.user / smtp.pass).";
                if (SendOtpBtn != null) SendOtpBtn.IsEnabled = false;
            }
            else
            {
                OtpStatusTxt.Text = "لازم تفعيل الإيميل بالكود قبل إنشاء المستخدم.";
                if (SendOtpBtn != null) SendOtpBtn.IsEnabled = true;
            }

            _otp = new EmailOtpService(
                smtpUser: _smtpUser,
                smtpPass: _smtpPass,
                fromEmail: fromEmail,
                fromName: fromName,
                expiresMinutes: expiresMinutes,
                enableSsl: enableSsl);
        }

        // ----------------- UI Buttons -----------------
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private async void SendOtp_Click(object sender, RoutedEventArgs e)
        {
            ClearError();

            if (string.IsNullOrWhiteSpace(_smtpUser) || string.IsNullOrWhiteSpace(_smtpPass))
            {
                ShowError("إعدادات SMTP غير موجودة/غير كاملة في App.config.");
                OtpStatusTxt.Text = "❌ تعذر إرسال الكود لأن إعدادات SMTP ناقصة.";
                return;
            }

            string email = (EmailTxt.Text ?? "").Trim();

            if (!EmailOtpService.IsValidEmail(email))
            {
                ShowError("اكتب بريد إلكتروني صحيح.");
                return;
            }

            try
            {
                SendOtpBtn.IsEnabled = false;
                SendOtpBtn.Content = "جاري الإرسال...";

                await _otp.SendOtpAsync(email);

                _otpVerified = false;
                _otpVerifiedEmail = "";
                OtpStatusTxt.Text = "✅ تم إرسال كود التفعيل للإيميل. اكتبه واضغط (تأكيد).";
            }
            catch (Exception ex)
            {
                // ✅ مهم: ده هيعرض رسالة Gmail 5.7.0 لو موجودة
                ShowError("فشل إرسال الكود: " + ex.Message);
                OtpStatusTxt.Text = "❌ تعذر إرسال الكود.";
            }
            finally
            {
                SendOtpBtn.IsEnabled = true;
                SendOtpBtn.Content = "إرسال كود";
            }
        }

        private void VerifyOtp_Click(object sender, RoutedEventArgs e)
        {
            ClearError();

            string email = (EmailTxt.Text ?? "").Trim();
            string code = (OtpTxt.Text ?? "").Trim();

            if (!EmailOtpService.IsValidEmail(email))
            {
                ShowError("اكتب بريد إلكتروني صحيح.");
                return;
            }

            if (code.Length != 6)
            {
                ShowError("اكتب كود صحيح (6 أرقام).");
                return;
            }

            var result = _otp.VerifyOtp(email, code);

            switch (result)
            {
                case OtpVerifyResult.Ok:
                    _otpVerified = true;
                    _otpVerifiedEmail = email;
                    OtpStatusTxt.Text = "✅ تم تفعيل الإيميل بنجاح.";
                    return;

                case OtpVerifyResult.Expired:
                    _otpVerified = false;
                    _otpVerifiedEmail = "";
                    OtpStatusTxt.Text = "❌ انتهت صلاحية الكود. أعد الإرسال.";
                    ShowError("انتهت صلاحية الكود. اضغط (إرسال كود) مرة أخرى.");
                    return;

                case OtpVerifyResult.WrongCode:
                    _otpVerified = false;
                    _otpVerifiedEmail = "";
                    OtpStatusTxt.Text = "❌ الكود غير صحيح.";
                    ShowError("الكود غير صحيح.");
                    return;

                default:
                    _otpVerified = false;
                    _otpVerifiedEmail = "";
                    OtpStatusTxt.Text = "❌ لا يوجد كود لهذا الإيميل. اضغط (إرسال كود).";
                    ShowError("لا يوجد كود مُرسل لهذا الإيميل. اضغط (إرسال كود).");
                    return;
            }
        }

        private void Create_Click(object sender, RoutedEventArgs e)
        {
            ClearError();

            string email = (EmailTxt.Text ?? "").Trim();
            if (!_otpVerified || !string.Equals(_otpVerifiedEmail, email, StringComparison.OrdinalIgnoreCase))
            {
                ShowError("لازم تفعل نفس الإيميل بالكود قبل إنشاء المستخدم.");
                return;
            }

            string username = (UserTxt.Text ?? "").Trim();
            string pass = PassPwd.Password ?? "";
            string confirm = ConfirmPwd.Password ?? "";

            if (string.IsNullOrWhiteSpace(username))
            {
                ShowError("اكتب اسم المستخدم.");
                return;
            }

            if (pass.Length < 4)
            {
                ShowError("كلمة المرور قصيرة جدًا (على الأقل 4 أحرف).");
                return;
            }

            if (!string.Equals(pass, confirm, StringComparison.Ordinal))
            {
                ShowError("كلمة المرور وتأكيدها غير متطابقين.");
                return;
            }

            try
            {
                // 1) إنشاء المستخدم (Reflection كما هو)
                var mi = _auth.GetType().GetMethod(
                    "CreateUser",
                    BindingFlags.Instance | BindingFlags.Public,
                    binder: null,
                    types: new[] { typeof(string), typeof(string) },
                    modifiers: null);

                if (mi == null)
                {
                    ShowError("لم يتم العثور على الدالة CreateUser داخل AuthService.");
                    return;
                }

                object? result = mi.Invoke(_auth, new object[] { username, pass });

                if (mi.ReturnType == typeof(bool) && result is bool ok && ok == false)
                {
                    ShowError("لم يتم إنشاء المستخدم (قد يكون الاسم موجود مسبقًا).");
                    return;
                }

                // 2) ✅ SaaS: إنشاء Company + ربطها بالمستخدم
                var (companyId, userId) = EnsureCompanyAndLinkUser(username);

                // 3) ✅ ثبت CurrentCompanyId لكل DbContext بعد كده
                try
                {
                    Application.Current.Properties["CurrentCompanyId"] = companyId;
                    Application.Current.Properties["CurrentUserId"] = userId;
                }
                catch { }

                // 4) اقفل OTP بعد النجاح
                _otp.Invalidate(email);

                MessageBox.Show("تم إنشاء المستخدم بنجاح ✅", "Create User", MessageBoxButton.OK, MessageBoxImage.Information);

                DialogResult = true;
                Close();
            }
            catch (TargetInvocationException tie)
            {
                ShowError("خطأ أثناء إنشاء المستخدم: " + (tie.InnerException?.Message ?? tie.Message));
            }
            catch (Exception ex)
            {
                // ✅ أظهر InnerException لو موجودة (مهمة في مشاكل EF/SQLite)
                var msg = ex.Message;
                if (ex.InnerException != null) msg += "\n" + ex.InnerException.Message;
                ShowError("خطأ أثناء إنشاء المستخدم: " + msg);
            }
        }

        // ----------------- SaaS helper -----------------
        private (int companyId, int userId) EnsureCompanyAndLinkUser(string username)
        {
            using var db = new AppDbContext();

            // ⚠️ ملاحظة: لو أنت عامل Migrate في App Startup، السطر ده اختياري
            db.InitializeDatabase();

            // هات المستخدم اللي اتعمل (Case-insensitive)
            var uName = (username ?? "").Trim().ToLowerInvariant();
            var user = db.Users.FirstOrDefault(u => (u.Username ?? "").ToLower() == uName);

            if (user == null)
                throw new Exception("تم إنشاء المستخدم لكن لم يتم العثور عليه في قاعدة البيانات.");

            // لو مفيش شركة خالص -> اعمل واحدة افتراضي (مع Code إلزامي)
            var company = db.Companies.OrderBy(c => c.Id).FirstOrDefault();
            if (company == null)
            {
                company = new Company
                {
                    Name = "ZAIN Default Company",
                    Country = "SA",
                    City = "—",

                    // ✅ FIX: Code Required + Unique
                    Code = ("COMP-" + Guid.NewGuid().ToString("N")[..8]).ToUpperInvariant()
                };
                db.Companies.Add(company);
                db.SaveChanges();
            }
            else
            {
                // احتياط: لو شركة قديمة بدون Code
                if (string.IsNullOrWhiteSpace(company.Code))
                {
                    company.Code = ("COMP-" + Guid.NewGuid().ToString("N")[..8]).ToUpperInvariant();
                    db.SaveChanges();
                }
            }

            // اربط المستخدم بالشركة لو مش مربوط
            var link = db.CompanyUsers.FirstOrDefault(x => x.CompanyId == company.Id && x.UserId == user.Id);
            if (link == null)
            {
                link = new CompanyUser
                {
                    CompanyId = company.Id,
                    UserId = user.Id,
                    Role = "Owner",
                    IsActive = true
                };
                db.CompanyUsers.Add(link);
                db.SaveChanges();
            }

            return (company.Id, user.Id);
        }

        // ----------------- Settings helpers -----------------
        private static string ReadSetting(string key, string fallback)
        {
            try
            {
                var v = ConfigurationManager.AppSettings[key];
                return string.IsNullOrWhiteSpace(v) ? fallback : v.Trim();
            }
            catch { return fallback; }
        }

        private static int ReadIntSetting(string key, int fallback)
        {
            var s = ReadSetting(key, "");
            return int.TryParse(s, out var n) ? n : fallback;
        }

        private static bool ReadBoolSetting(string key, bool fallback)
        {
            var s = ReadSetting(key, "");
            return bool.TryParse(s, out var b) ? b : fallback;
        }

        // ----------------- Error UI -----------------
        private void ShowError(string msg)
        {
            ErrorTxt.Text = msg;
            ErrorTxt.Visibility = Visibility.Visible;
        }

        private void ClearError()
        {
            ErrorTxt.Text = "";
            ErrorTxt.Visibility = Visibility.Collapsed;
        }
    }
}