﻿#nullable enable
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;

namespace ZainContractsManager.Views.Finance
{
    public partial class LedgerView : UserControl
    {
        public LedgerView()
        {
            InitializeComponent();

            Loaded += (_, __) =>
            {
                LoadAccounts();
                // الملخص يتصفّر افتراضيًا
                SetTotals(0m, 0m);
            };
        }

        // =========================
        // Helpers
        // =========================

        private void SetTotals(decimal totalDebit, decimal totalCredit)
        {
            try
            {
                // الرصيد النهائي = مدين - دائن (ممكن يكون موجب/سالب حسب طبيعة الحساب)
                var finalBalance = totalDebit - totalCredit;

                if (FindName("TxtTotalDebit") is TextBlock d) d.Text = totalDebit.ToString("N2");
                if (FindName("TxtTotalCredit") is TextBlock c) c.Text = totalCredit.ToString("N2");
                if (FindName("TxtFinalBalance") is TextBlock b) b.Text = finalBalance.ToString("N2");
            }
            catch
            {
                // ignore (لو الـ XAML لسه ما اتعدلش)
            }
        }

        private int RequireCompanyId(AppDbContext db)
        {
            var companyId = db.CurrentCompanyId;
            if (companyId <= 0)
                throw new InvalidOperationException("لازم تختار شركة أولاً قبل عرض دفتر الأستاذ.");
            return companyId;
        }

        // =========================
        // Load Accounts
        // =========================

        private void LoadAccounts()
        {
            try
            {
                using var db = new AppDbContext();
                var companyId = RequireCompanyId(db);

                var accounts = db.Accounts
                    .AsNoTracking()
                    .Where(a => a.CompanyId == companyId && a.IsActive)
                    .OrderBy(a => a.Code)
                    .ToList();

                CmbAccounts.ItemsSource = accounts;

                if (accounts.Any())
                {
                    // لو فيه اختيار سابق حاول حافظ عليه
                    if (CmbAccounts.SelectedValue is int oldId && accounts.Any(a => a.Id == oldId))
                        CmbAccounts.SelectedValue = oldId;
                    else
                        CmbAccounts.SelectedValue = accounts.First().Id;
                }
                else
                {
                    CmbAccounts.SelectedValue = null;
                    GridLedger.ItemsSource = null;
                    SetTotals(0m, 0m);
                }
            }
            catch (Exception ex)
            {
                GridLedger.ItemsSource = null;
                SetTotals(0m, 0m);
                MessageBox.Show("خطأ في تحميل الحسابات: " + ex.Message);
            }
        }

        // =========================
        // Load Ledger
        // =========================

        private void LoadLedger(int accountId)
        {
            try
            {
                using var db = new AppDbContext();
                var companyId = RequireCompanyId(db);

                // ✅ Ledger rows (Tenant-safe) + مرتب
                var data =
                    (from l in db.JournalLines.AsNoTracking()
                     join e in db.JournalEntries.AsNoTracking() on l.JournalEntryId equals e.Id
                     where l.CompanyId == companyId
                           && e.CompanyId == companyId
                           && l.AccountId == accountId
                     orderby e.EntryDate descending, e.Id descending, l.Id descending
                     select new
                     {
                         e.EntryDate,
                         e.EntryNo,
                         e.Description,
                         l.Debit,
                         l.Credit,
                         l.Notes
                     }).ToList();

                GridLedger.ItemsSource = data;

                // ✅ Totals
                var totalDebit = data.Sum(x => (decimal)x.Debit);
                var totalCredit = data.Sum(x => (decimal)x.Credit);

                SetTotals(totalDebit, totalCredit);
            }
            catch (Exception ex)
            {
                GridLedger.ItemsSource = null;
                SetTotals(0m, 0m);
                MessageBox.Show("خطأ في تحميل دفتر الأستاذ: " + ex.Message);
            }
        }

        // =========================
        // Events
        // =========================

        private void CmbAccounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (CmbAccounts.SelectedValue is int id)
                    LoadLedger(id);
                else
                {
                    GridLedger.ItemsSource = null;
                    SetTotals(0m, 0m);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ: " + ex.Message);
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadAccounts();

            if (CmbAccounts.SelectedValue is int id)
                LoadLedger(id);
            else
            {
                GridLedger.ItemsSource = null;
                SetTotals(0m, 0m);
            }
        }
    }
}