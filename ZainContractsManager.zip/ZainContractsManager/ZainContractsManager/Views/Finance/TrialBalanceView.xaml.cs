﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;

namespace ZainContractsManager.Views.Finance
{
    public partial class TrialBalanceView : UserControl
    {
        private sealed class TrialBalanceRow
        {
            public string Code { get; set; } = "";
            public string Name { get; set; } = "";

            public decimal Debit { get; set; }
            public decimal Credit { get; set; }
            public decimal Balance => Debit - Credit; // موجب = مدين / سالب = دائن
        }

        public TrialBalanceView()
        {
            InitializeComponent();
            Loaded += (_, __) => LoadTrialBalance();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => LoadTrialBalance();

        private void LoadTrialBalance()
        {
            try
            {
                using var db = new AppDbContext();

                var companyId = db.CurrentCompanyId;
                if (companyId <= 0)
                {
                    GridTrial.ItemsSource = Array.Empty<TrialBalanceRow>();
                    SetTotals(0m, 0m);
                    MessageBox.Show("اختيار (شركة) مطلوب لعرض ميزان المراجعة.");
                    return;
                }

                // ✅ أهم نقطة: تجاهل QueryFilters لتفادي crash بسبب صفوف قديمة CompanyId فيها NULL
                // ثم فلترة Tenant يدويًا داخل الاستعلام
                var sumsQ =
                    db.JournalLines
                      .IgnoreQueryFilters()
                      .AsNoTracking()
                      .Where(l => l.CompanyId == companyId)
                      .GroupBy(l => l.AccountId)
                      .Select(g => new
                      {
                          AccountId = g.Key,
                          Debit = g.Sum(x => (decimal?)x.Debit) ?? 0m,
                          Credit = g.Sum(x => (decimal?)x.Credit) ?? 0m
                      });

                var rows =
                    db.Accounts
                      .IgnoreQueryFilters()
                      .AsNoTracking()
                      .Where(a => a.CompanyId == companyId && a.IsActive)
                      .GroupJoin(
                          sumsQ,
                          a => a.Id,
                          s => s.AccountId,
                          (a, gj) => new { a, gj }
                      )
                      .SelectMany(
                          x => x.gj.DefaultIfEmpty(),
                          (x, s) => new TrialBalanceRow
                          {
                              Code = x.a.Code,
                              Name = x.a.Name,
                              Debit = s != null ? s.Debit : 0m,
                              Credit = s != null ? s.Credit : 0m
                          }
                      )
                      .OrderBy(r => r.Code)
                      .ToList();

                GridTrial.ItemsSource = rows;

                var totalD = rows.Sum(x => x.Debit);
                var totalC = rows.Sum(x => x.Credit);
                SetTotals(totalD, totalC);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل ميزان المراجعة: " + ex.Message);
            }
        }

        private void SetTotals(decimal totalDebit, decimal totalCredit)
        {
            var diff = totalDebit - totalCredit;

            // ✅ ما نكتبش null نهائيًا
            if (TxtTotalDebit != null) TxtTotalDebit.Text = $"إجمالي المدين: {totalDebit:N2}";
            if (TxtTotalCredit != null) TxtTotalCredit.Text = $"إجمالي الدائن: {totalCredit:N2}";
            if (TxtDiff != null) TxtDiff.Text = $"الفرق: {diff:N2}";
        }
    }
}