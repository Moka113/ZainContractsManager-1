﻿#nullable enable
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models.Finance;

namespace ZainContractsManager.Views.Finance
{
    public partial class JournalEntriesView : UserControl
    {
        private readonly string? _sourceType;
        private readonly int? _sourceId;

        public JournalEntriesView()
        {
            InitializeComponent();

            // ✅ توصيل الحدث برمجيًا (حتى لو XAML مش موصل)
            GridEntries.SelectionChanged += GridEntries_SelectionChanged;

            // ✅ تحميل بعد اكتمال الواجهة
            Loaded += (_, __) => LoadEntries();
        }

        // ✅ Filter constructor
        public JournalEntriesView(string sourceType, int sourceId) : this()
        {
            _sourceType = sourceType;
            _sourceId = sourceId;
        }

        private void LoadEntries()
        {
            try
            {
                using var db = new AppDbContext();

                var companyId = db.CurrentCompanyId;
                if (companyId <= 0)
                {
                    GridEntries.ItemsSource = null;
                    GridLines.ItemsSource = null;
                    SetTotals(0m, 0m);
                    MessageBox.Show("اختيار (شركة) مطلوب لعرض القيود اليومية.");
                    return;
                }

                var q = db.JournalEntries
                    .AsNoTracking()
                    .Where(e => e.CompanyId == companyId)
                    .AsQueryable();

                if (!string.IsNullOrWhiteSpace(_sourceType) && _sourceId.HasValue)
                {
                    q = q.Where(e => e.SourceType == _sourceType && e.SourceId == _sourceId.Value);
                }

                var entries = q
                    .OrderByDescending(e => e.EntryDate)
                    .ThenByDescending(e => e.Id)
                    .ToList();

                GridEntries.ItemsSource = entries;
                GridLines.ItemsSource = null;
                SetTotals(0m, 0m);

                // ✅ أهم نقطة: اختار أول صف تلقائيًا عشان السطور + الإجماليات تظهر فورًا
                if (entries.Count > 0)
                {
                    GridEntries.SelectedIndex = 0; // ده هيشغل SelectionChanged
                    GridEntries.ScrollIntoView(GridEntries.SelectedItem);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل القيود: " + ex.Message);
            }
        }

        private void GridEntries_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (GridEntries.SelectedItem is not JournalEntry entry)
                {
                    GridLines.ItemsSource = null;
                    SetTotals(0m, 0m);
                    return;
                }

                using var db = new AppDbContext();

                var companyId = db.CurrentCompanyId;
                if (companyId <= 0)
                {
                    GridLines.ItemsSource = null;
                    SetTotals(0m, 0m);
                    MessageBox.Show("اختيار (شركة) مطلوب لعرض سطور القيد.");
                    return;
                }

                var lines = db.JournalLines
                    .AsNoTracking()
                    .Include(l => l.Account)
                    .Where(l => l.CompanyId == companyId && l.JournalEntryId == entry.Id)
                    .OrderBy(l => l.Id)
                    .ToList();

                GridLines.ItemsSource = lines;

                var debit = lines.Sum(x => x.Debit);
                var credit = lines.Sum(x => x.Credit);
                SetTotals(debit, credit);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل سطور القيد: " + ex.Message);
            }
        }

        private void SetTotals(decimal debit, decimal credit)
        {
            try
            {
                if (FindName("TxtDebitTotal") is TextBlock d) d.Text = debit.ToString("N2");
                if (FindName("TxtCreditTotal") is TextBlock c) c.Text = credit.ToString("N2");
                if (FindName("TxtDiff") is TextBlock diff) diff.Text = (debit - credit).ToString("N2");
            }
            catch
            {
                // ignore
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => LoadEntries();
    }
}