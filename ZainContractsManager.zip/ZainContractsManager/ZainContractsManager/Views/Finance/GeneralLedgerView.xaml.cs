﻿#nullable enable
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ZainContractsManager.Data;

// ✅ Alias لحل التضارب
using EngineReports = ZainContractsManager.Services.FinanceEngine.FinancialReportsService;

namespace ZainContractsManager.Views.Finance
{
    public partial class GeneralLedgerView : UserControl
    {
        private class AccountPick
        {
            public int Id { get; set; }
            public string Display { get; set; } = "";
        }

        public GeneralLedgerView()
        {
            InitializeComponent();
            LoadAccounts();
        }

        private void LoadAccounts()
        {
            try
            {
                using var db = new AppDbContext();

                var list = db.Accounts
                    .Where(a => a.IsActive)
                    .OrderBy(a => a.Code)
                    .Select(a => new AccountPick
                    {
                        Id = a.Id,
                        Display = $"{a.Code} - {a.Name}"
                    })
                    .ToList();

                CmbAccounts.ItemsSource = list;

                if (list.Count > 0)
                    CmbAccounts.SelectedIndex = 0;

                LoadLedger();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل الحسابات: " + ex.Message);
            }
        }

        private void LoadLedger()
        {
            if (CmbAccounts.SelectedValue is not int accountId) return;

            try
            {
                using var db = new AppDbContext();
                var svc = new EngineReports(db);

                DateTime? from = DpFrom.SelectedDate?.Date;

                // ✅ "إلى" شامل آخر اليوم (اختياري بس أدق)
                DateTime? to = DpTo.SelectedDate?.Date.AddDays(1).AddTicks(-1);

                var lines = svc.GetGeneralLedger(accountId, from, to);
                GridLedger.ItemsSource = lines;

                var debit = lines.Sum(x => x.Debit);
                var credit = lines.Sum(x => x.Credit);
                var net = debit - credit;

                TxtDebit.Text = debit.ToString("N2");
                TxtCredit.Text = credit.ToString("N2");
                TxtNet.Text = net.ToString("N2");
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل الأستاذ: " + ex.Message);
            }
        }

        private void Apply_Click(object sender, RoutedEventArgs e) => LoadLedger();
        private void Refresh_Click(object sender, RoutedEventArgs e) => LoadAccounts();

        // ✅ اختياري: تحميل تلقائي عند تغيير الحساب
        private void CmbAccounts_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded) LoadLedger();
        }
    }
}