﻿#nullable enable
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;

namespace ZainContractsManager.Views.Finance
{
    public partial class AccountsView : UserControl
    {
        public AccountsView()
        {
            InitializeComponent();
            LoadAccounts();
        }

        private void LoadAccounts()
        {
            try
            {
                using var db = new AppDbContext();
                var data = db.Accounts
                    .AsNoTracking()
                    .OrderBy(a => a.Code)
                    .ToList();

                GridAccounts.ItemsSource = data;
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل الحسابات: " + ex.Message);
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e) => LoadAccounts();
    }
}