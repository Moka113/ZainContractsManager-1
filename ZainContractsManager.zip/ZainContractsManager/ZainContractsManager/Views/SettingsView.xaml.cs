﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ZainContractsManager.Data;
using ZainContractsManager.ViewModels;

namespace ZainContractsManager.Views
{
    public partial class SettingsView : UserControl
    {
        public SettingsView()
        {
            InitializeComponent();
            DataContext = new SettingsViewModel();

            Loaded += SettingsView_Loaded;
        }

        private void SettingsView_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadSettingsFromDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر تحميل الإعدادات: " + ex.Message, "نظام زين");
            }
        }

        // =========================================================
        // Save Settings
        // =========================================================
        private void SaveSettings_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (DataContext is not SettingsViewModel vm)
                {
                    MessageBox.Show("تعذر الوصول إلى نموذج الإعدادات.", "نظام زين");
                    return;
                }

                using var db = new AppDbContext();

                SaveOrUpdateSetting(db, "CompanyName", vm.CompanyName ?? "ZAIN SYSTEM");
                SaveOrUpdateSetting(db, "DarkMode", vm.DarkMode ? "true" : "false");

                db.SaveChanges();

                vm.SaveStatus = "✅ تم الحفظ";
                vm.LastSavedAt = DateTime.Now;

                ApplyDarkMode(vm.DarkMode);

                MessageBox.Show("تم حفظ الإعدادات بنجاح ✅", "نظام زين");
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء حفظ الإعدادات: " + ex.Message, "نظام زين");
            }
        }

        private void LoadSettingsFromDatabase()
        {
            if (DataContext is not SettingsViewModel vm)
                return;

            using var db = new AppDbContext();

            var companyName = db.AppSettings.FirstOrDefault(x => x.Key == "CompanyName")?.Value;
            var darkMode = db.AppSettings.FirstOrDefault(x => x.Key == "DarkMode")?.Value;

            if (!string.IsNullOrWhiteSpace(companyName))
                vm.CompanyName = companyName;

            if (!string.IsNullOrWhiteSpace(darkMode))
                vm.DarkMode = string.Equals(darkMode, "true", StringComparison.OrdinalIgnoreCase);

            vm.SaveStatus = "☑ تم التحميل";
            vm.LastSavedAt = DateTime.Now;

            ApplyDarkMode(vm.DarkMode);
        }

        private void SaveOrUpdateSetting(AppDbContext db, string key, string value)
        {
            var row = db.AppSettings.FirstOrDefault(x => x.Key == key);
            if (row == null)
            {
                row = new Models.Settings.AppSetting
                {
                    Key = key,
                    Value = value
                };
                db.AppSettings.Add(row);
            }
            else
            {
                row.Value = value;
            }
        }

        // =========================================================
        // Backup
        // =========================================================
        private void BackupNow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string dbPath = AppDbContext.DbPath;

                if (!File.Exists(dbPath))
                {
                    MessageBox.Show("قاعدة البيانات غير موجودة لإنشاء نسخة احتياطية.", "نظام زين");
                    return;
                }

                var sfd = new SaveFileDialog
                {
                    Title = "حفظ نسخة احتياطية",
                    Filter = "SQLite Database (*.db)|*.db|Backup Files (*.bak)|*.bak|All Files (*.*)|*.*",
                    FileName = $"ZainSystem_Backup_{DateTime.Now:yyyyMMdd_HHmmss}.db"
                };

                if (sfd.ShowDialog() != true)
                    return;

                File.Copy(dbPath, sfd.FileName, true);

                if (DataContext is SettingsViewModel vm)
                {
                    vm.SaveStatus = "📦 تم إنشاء نسخة احتياطية";
                    vm.LastSavedAt = DateTime.Now;
                }

                MessageBox.Show("تم إنشاء النسخة الاحتياطية بنجاح ✅", "نظام زين");
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل إنشاء النسخة الاحتياطية: " + ex.Message, "نظام زين");
            }
        }

        // =========================================================
        // Restore Backup
        // =========================================================
        private void RestoreBackup_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string dbPath = AppDbContext.DbPath;

                var ofd = new OpenFileDialog
                {
                    Title = "اختر النسخة الاحتياطية",
                    Filter = "SQLite Database (*.db)|*.db|Backup Files (*.bak)|*.bak|All Files (*.*)|*.*"
                };

                if (ofd.ShowDialog() != true)
                    return;

                var confirm = MessageBox.Show(
                    "سيتم استبدال قاعدة البيانات الحالية بالنسخة المختارة.\n\nهل أنت متأكد؟",
                    "تأكيد الاستعادة",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);

                if (confirm != MessageBoxResult.Yes)
                    return;

                // نسخة أمان إضافية قبل الاستعادة
                if (File.Exists(dbPath))
                {
                    string safeBackup = Path.Combine(
                        AppDbContext.DbFolder,
                        $"PreRestore_{DateTime.Now:yyyyMMdd_HHmmss}.db");

                    File.Copy(dbPath, safeBackup, true);
                }

                File.Copy(ofd.FileName, dbPath, true);

                if (DataContext is SettingsViewModel vm)
                {
                    vm.SaveStatus = "♻ تم استعادة النسخة";
                    vm.LastSavedAt = DateTime.Now;
                }

                MessageBox.Show(
                    "تمت استعادة النسخة الاحتياطية بنجاح ✅\n\nيفضل إغلاق البرنامج وإعادة تشغيله الآن.",
                    "نظام زين");
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل استعادة النسخة الاحتياطية: " + ex.Message, "نظام زين");
            }
        }

        // =========================================================
        // Apply Theme
        // =========================================================
        private void ApplyDarkMode(bool isDark)
        {
            try
            {
                // محاولة آمنة لتغيير بعض الألوان مباشرة
                var app = Application.Current;
                if (app == null) return;

                if (isDark)
                {
                    SetResourceIfExists(app, "AppBackground", "#0F172A");
                    SetResourceIfExists(app, "Surface1", "#111827");
                    SetResourceIfExists(app, "Surface2", "#1F2937");
                    SetResourceIfExists(app, "TextPrimary", "#F9FAFB");
                    SetResourceIfExists(app, "TextSecondary", "#D1D5DB");
                    SetResourceIfExists(app, "BorderBrushSoft", "#374151");
                    SetResourceIfExists(app, "DividerBrush", "#374151");
                }
                else
                {
                    SetResourceIfExists(app, "AppBackground", "#F8FAFC");
                    SetResourceIfExists(app, "Surface1", "#FFFFFF");
                    SetResourceIfExists(app, "Surface2", "#F8FAFC");
                    SetResourceIfExists(app, "TextPrimary", "#0F172A");
                    SetResourceIfExists(app, "TextSecondary", "#64748B");
                    SetResourceIfExists(app, "BorderBrushSoft", "#E2E8F0");
                    SetResourceIfExists(app, "DividerBrush", "#E5E7EB");
                }
            }
            catch
            {
                // ignore
            }
        }

        private void SetResourceIfExists(Application app, string key, string colorHex)
        {
            try
            {
                var converter = new System.Windows.Media.BrushConverter();
                var brush = converter.ConvertFromString(colorHex);

                if (brush != null)
                    app.Resources[key] = brush;
            }
            catch
            {
                // ignore
            }
        }
    }
}