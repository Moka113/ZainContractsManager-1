﻿using System.Windows.Controls;
using ZainContractsManager.ViewModels;

namespace ZainContractsManager.Views
{
    public partial class ReportsView : UserControl
    {
        public ReportsView()
        {
            InitializeComponent();
            DataContext = new ReportsViewModel();
        }
    }
}