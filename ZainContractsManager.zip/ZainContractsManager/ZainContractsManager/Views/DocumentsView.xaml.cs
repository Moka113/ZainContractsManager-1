﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Diagnostics;
using System.IO;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using Microsoft.Win32;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Drawing;
using System.Drawing;
using EpplusLicenseContext = OfficeOpenXml.LicenseContext;

namespace ZainContractsManager.Views
{
    public partial class DocumentsView : UserControl
    {
        private AppDbContext _db = new AppDbContext();

        public DocumentsView()
        {
            InitializeComponent();

            ExcelPackage.LicenseContext = EpplusLicenseContext.NonCommercial;
            LoadData();
        }

        public void LoadData(object? sender = null, RoutedEventArgs? e = null)
        {
            try
            {
                _db = new AppDbContext();

                var activeDocs = _db.Documents
                    .Where(d => d.IsArchivedVersion == false)
                    .ToList();

                var sortedDocs = activeDocs
                    .OrderBy(d => GetStatusSortOrder(GetStatus(d)))
                    .ThenBy(d => d.ExpiryDate)
                    .ToList();

                if (TxtTotalDocs != null)
                    TxtTotalDocs.Text = sortedDocs.Count.ToString();

                if (TxtActiveDocs != null)
                    TxtActiveDocs.Text = sortedDocs.Count(d => GetStatus(d) == "ساري").ToString();

                if (TxtExpiredDocs != null)
                    TxtExpiredDocs.Text = sortedDocs.Count(d => GetStatus(d) == "منتهي").ToString();

                if (TxtWarningDocs != null)
                    TxtWarningDocs.Text = sortedDocs.Count(d => GetStatus(d) == "قرب الانتهاء").ToString();

                DocsDataGrid.ItemsSource = sortedDocs;

                if (TxtSearch != null)
                    TxtSearch.Text = "";
            }
            catch (Exception ex)
            {
                string msg = ex.Message.Contains("no such column")
                    ? "قاعدة البيانات قديمة. يرجى حذف ملف ZainSystem.db وإعادة تشغيل البرنامج."
                    : ex.Message;

                MessageBox.Show($"خطأ في تحميل بيانات الأرشفة: {msg}", "نظام زين");
            }
        }

        private static string GetStatus(Document doc)
        {
            if (!doc.ExpiryDate.HasValue)
                return string.IsNullOrWhiteSpace(doc.Status) ? "غير محدد" : doc.Status;

            DateTime today = DateTime.Today;

            if (doc.ExpiryDate.Value.Date < today)
                return "منتهي";

            if (doc.ExpiryDate.Value.Date <= today.AddDays(30))
                return "قرب الانتهاء";

            return "ساري";
        }

        private static int GetStatusSortOrder(string status)
        {
            return status switch
            {
                "منتهي" => 0,
                "قرب الانتهاء" => 1,
                "ساري" => 2,
                _ => 3
            };
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtSearch == null) return;

            string key = (TxtSearch.Text ?? "").ToLower().Trim();

            var list = _db.Documents
                .Where(d => d.IsArchivedVersion == false && (
                    (d.ContractNumber != null && d.ContractNumber.ToLower().Contains(key)) ||
                    (d.TenantName != null && d.TenantName.ToLower().Contains(key)) ||
                    (d.LessorName != null && d.LessorName.ToLower().Contains(key)) ||
                    (d.BranchName != null && d.BranchName.ToLower().Contains(key)) ||
                    (d.DocumentType != null && d.DocumentType.ToLower().Contains(key))
                ))
                .ToList()
                .OrderBy(d => GetStatusSortOrder(GetStatus(d)))
                .ThenBy(d => d.ExpiryDate)
                .ToList();

            DocsDataGrid.ItemsSource = list;
        }

        private void ViewHistory_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (((Button)sender).DataContext is Document currentDoc)
                {
                    int rootId = currentDoc.ParentContractId ?? currentDoc.Id;

                    var history = _db.Documents
                        .Where(d => d.Id == rootId || d.ParentContractId == rootId)
                        .OrderByDescending(d => d.CreatedAt)
                        .ToList();

                    if (history.Count > 0)
                    {
                        DocsDataGrid.ItemsSource = history;
                        MessageBox.Show(
                            $"تم عرض سجل العمليات للعقد: {currentDoc.ContractNumber}\nعدد النسخ المكتشفة: {history.Count}",
                            "سجل أرشفة زين");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"تعذر جلب السجل: {ex.Message}");
            }
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!(DocsDataGrid.ItemsSource is List<Document> data) || data.Count == 0)
                {
                    MessageBox.Show("لا توجد بيانات لتصديرها.", "نظام زين");
                    return;
                }

                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Excel Workbook (*.xlsx)|*.xlsx",
                    FileName = $"تقرير_أرشفة_زين_{DateTime.Now:yyyyMMdd_HHmm}"
                };

                if (sfd.ShowDialog() != true) return;

                using (var package = new ExcelPackage())
                {
                    var ws = package.Workbook.Worksheets.Add("تقرير الأرشفة");
                    ws.View.RightToLeft = true;

                    // ===== العنوان =====
                    ws.Cells["A1:G1"].Merge = true;
                    ws.Cells["A1"].Value = "ZAIN SYSTEM ™️ | تقرير الأرشفة";
                    ws.Cells["A1"].Style.Font.Size = 16;
                    ws.Cells["A1"].Style.Font.Bold = true;
                    ws.Cells["A1"].Style.Font.Color.SetColor(Color.White);
                    ws.Cells["A1"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ws.Cells["A1"].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59));
                    ws.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    ws.Cells["A1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    ws.Row(1).Height = 28;

                    // ===== تاريخ الاستخراج =====
                    ws.Cells["A2:G2"].Merge = true;
                    ws.Cells["A2"].Value = "تاريخ الاستخراج: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                    ws.Cells["A2"].Style.Font.Bold = true;
                    ws.Cells["A2"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    ws.Cells["A2"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;

                    // ===== مؤشرات سريعة =====
                    int activeCount = data.Count(d => GetStatus(d) == "ساري");
                    int expiredCount = data.Count(d => GetStatus(d) == "منتهي");
                    int warningCount = data.Count(d => GetStatus(d) == "قرب الانتهاء");

                    ws.Cells["A3"].Value = "إجمالي المستندات";
                    ws.Cells["B3"].Value = data.Count;
                    ws.Cells["C3"].Value = "السارية";
                    ws.Cells["D3"].Value = activeCount;
                    ws.Cells["E3"].Value = "قرب الانتهاء";
                    ws.Cells["F3"].Value = warningCount;
                    ws.Cells["G3"].Value = $"المنتهية: {expiredCount}";

                    ws.Cells["A3:G3"].Style.Font.Bold = true;
                    ws.Cells["A3:G3"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    ws.Cells["A3:G3"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    ws.Cells["A3:G3"].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ws.Cells["A3:G3"].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));

                    // ===== الشعار =====
                    TryAddLogo(ws);

                    // ===== رؤوس الجدول =====
                    string[] columns =
                    {
                        "الفرع",
                        "رقم العقد",
                        "نوع المستند",
                        "المؤجر",
                        "المستأجر",
                        "تاريخ الانتهاء",
                        "الحالة"
                    };

                    int headerRow = 5;
                    for (int i = 0; i < columns.Length; i++)
                    {
                        var cell = ws.Cells[headerRow, i + 1];
                        cell.Value = columns[i];
                        cell.Style.Font.Bold = true;
                        cell.Style.Font.Color.SetColor(Color.White);
                        cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        cell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(31, 78, 121));
                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                    }

                    ws.Row(headerRow).Height = 22;

                    // ===== البيانات =====
                    int row = 6;
                    foreach (var item in data.OrderBy(d => GetStatusSortOrder(GetStatus(d))).ThenBy(d => d.ExpiryDate))
                    {
                        string status = GetStatus(item);

                        ws.Cells[row, 1].Value = item.BranchName ?? "";
                        ws.Cells[row, 2].Value = item.ContractNumber ?? "";
                        ws.Cells[row, 3].Value = item.DocumentType ?? "";
                        ws.Cells[row, 4].Value = item.LessorName ?? "";
                        ws.Cells[row, 5].Value = item.TenantName ?? "";
                        ws.Cells[row, 6].Value = item.ExpiryDate;
                        ws.Cells[row, 7].Value = status;

                        for (int col = 1; col <= 7; col++)
                        {
                            var c = ws.Cells[row, col];
                            c.Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                            c.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                            c.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                            c.Style.WrapText = true;
                        }

                        ws.Cells[row, 6].Style.Numberformat.Format = "yyyy/mm/dd";

                        if (row % 2 == 0)
                        {
                            ws.Cells[row, 1, row, 7].Style.Fill.PatternType = ExcelFillStyle.Solid;
                            ws.Cells[row, 1, row, 7].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(248, 251, 255));
                        }

                        var statusCell = ws.Cells[row, 7];
                        statusCell.Style.Font.Bold = true;
                        statusCell.Style.Fill.PatternType = ExcelFillStyle.Solid;

                        if (status == "ساري")
                        {
                            statusCell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(213, 245, 227));
                            statusCell.Style.Font.Color.SetColor(Color.FromArgb(30, 132, 73));
                        }
                        else if (status == "قرب الانتهاء")
                        {
                            statusCell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(252, 243, 207));
                            statusCell.Style.Font.Color.SetColor(Color.FromArgb(185, 119, 14));
                        }
                        else if (status == "منتهي")
                        {
                            statusCell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(250, 219, 216));
                            statusCell.Style.Font.Color.SetColor(Color.FromArgb(192, 57, 43));
                        }

                        row++;
                    }

                    // ===== تجميد + فلترة =====
                    ws.View.FreezePanes(6, 1);
                    ws.Cells[headerRow, 1, row - 1, 7].AutoFilter = true;

                    // ===== الختم =====
                    TryAddStamp(ws, row + 1);

                    // ===== الفوتر =====
                    int footerRow = row + 7;
                    ws.Cells[footerRow, 1, footerRow, 7].Merge = true;
                    ws.Cells[footerRow, 1].Value =
                        "ZAIN SYSTEM 2026 ©️ | All Rights Reserved to Mustafa Zain | هذا النظام بجميع حقوقه محفوظة لمصطفى زين";
                    ws.Cells[footerRow, 1].Style.Font.Size = 10;
                    ws.Cells[footerRow, 1].Style.Font.Bold = true;
                    ws.Cells[footerRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    ws.Cells[footerRow, 1].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    ws.Cells[footerRow, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                    ws.Cells[footerRow, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(242, 244, 244));

                    // ===== ضبط الأعمدة =====
                    ws.Cells[ws.Dimension.Address].AutoFitColumns(12, 30);

                    package.SaveAs(new FileInfo(sfd.FileName));
                }

                MessageBox.Show("تم تصدير التقرير بتنسيق احترافي بنجاح ✅", "نظام زين");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"خطأ في التصدير: {ex.Message}");
            }
        }

        private void AddDocument_Click(object sender, RoutedEventArgs e)
        {
            var win = new AddDocumentWindow();
            if (win.ShowDialog() == true)
                LoadData();
        }

        private void EditDocument_Click(object sender, RoutedEventArgs e)
        {
            if (((Button)sender).DataContext is Document doc)
            {
                var editWin = new AddDocumentWindow(doc);
                if (editWin.ShowDialog() == true)
                    LoadData();
            }
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (((Button)sender).DataContext is Document doc)
                {
                    if (!string.IsNullOrEmpty(doc.FilePath) && File.Exists(doc.FilePath))
                    {
                        Process.Start(new ProcessStartInfo(doc.FilePath) { UseShellExecute = true });
                    }
                    else
                    {
                        MessageBox.Show(
                            "الملف غير موجود في المسار المحدد.",
                            "تنبيه زين",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"تعذر فتح الملف: {ex.Message}");
            }
        }

        private void TryAddLogo(ExcelWorksheet ws)
        {
            try
            {
                string logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "logo.png");
                if (!File.Exists(logoPath)) return;

                var pic = ws.Drawings.AddPicture($"Logo_{Guid.NewGuid():N}", new FileInfo(logoPath));
                pic.SetPosition(0, 0, 6, 0);
                pic.SetSize(80, 80);
            }
            catch
            {
                // ignore
            }
        }

        private void TryAddStamp(ExcelWorksheet ws, int row)
        {
            try
            {
                string stampPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "stamp.png");
                if (!File.Exists(stampPath)) return;

                var pic = ws.Drawings.AddPicture($"Stamp_{Guid.NewGuid():N}", new FileInfo(stampPath));
                pic.SetPosition(row, 0, 0, 0);
                pic.SetSize(140, 140);
            }
            catch
            {
                // ignore
            }
        }
    }
}