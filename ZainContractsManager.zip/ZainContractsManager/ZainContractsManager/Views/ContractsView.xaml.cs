﻿#nullable enable
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using Contract = ZainContractsManager.Models.LeaseContract;

namespace ZainContractsManager.Views
{
    public partial class ContractsView : UserControl
    {
        private readonly AppDbContext _db;
        private bool _isInitialized;

        private const int DueSoonDays = 30;

        public ContractsView()
        {
            _db = new AppDbContext();

            InitializeComponent();

            // ✅ EPPlus License (already set in App/MainWindow, but safe here)
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            _isInitialized = true;
            LoadData();
        }

        // ==============================
        // Row DTO
        // ==============================
        private sealed class ContractRow
        {
            public int Id { get; set; }
            public string? BranchName { get; set; }
            public string? ContractType { get; set; }
            public string LessorName { get; set; } = "";
            public string TenantName { get; set; } = "";
            public string ContractNumber { get; set; } = "";

            public string? ElectricityAccountNumber { get; set; }
            public string? WaterAccountNumber { get; set; }

            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }

            public decimal AmountBeforeTax { get; set; }
            public decimal VatAmount { get; set; }
            public decimal AdditionalFixedAmounts { get; set; }

            public decimal TotalAmount => AmountBeforeTax + VatAmount + AdditionalFixedAmounts;

            public int InstallmentsCount { get; set; }

            public string Status { get; set; } = "Active";

            public int PaymentsCount { get; set; }

            public string OurRoleDisplay { get; set; } = "غير محدد";

            public bool IsActive { get; set; }
            public string StatusDisplay { get; set; } = "—";

            public string PaymentStatus { get; set; } = "سليم";
            public DateTime? NextDueDate { get; set; }
        }

        // ==============================
        // Load / Filter
        // ==============================
        public void LoadData()
        {
            try
            {
                ApplyAllFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ في تحميل العقود: " + ex.Message);
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!_isInitialized) return;
            ApplyAllFilters();
        }

        private void Filters_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (!_isInitialized) return;
            ApplyAllFilters();
        }

        private void ApplyAllFilters()
        {
            if (!_isInitialized || ContractsGrid == null) return;

            var search = (TxtSearch?.Text ?? "").Trim();

            var statusTxt = ((CbStatusFilter?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "الكل").Trim();
            var roleTxt = ((CbRoleFilter?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "الكل").Trim();
            var dueTxt = GetComboSelectedTextSafe("CbDueFilter", "الكل");

            var query = _db.Contracts.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.Trim();
                query = query.Where(c =>
                    (c.ContractNumber ?? "").Contains(s) ||
                    (c.LessorName ?? "").Contains(s) ||
                    (c.TenantName ?? "").Contains(s) ||
                    (c.BranchName ?? "").Contains(s)
                );
            }

            var contracts = query.ToList();

            var today = DateTime.Today;

            if (statusTxt == "ساري")
                contracts = contracts.Where(c => c.EndDate.Date >= today).ToList();
            else if (statusTxt == "منتهي")
                contracts = contracts.Where(c => c.EndDate.Date < today).ToList();

            var ids = contracts.Select(c => c.Id).ToList();

            var payCounts = new Dictionary<int, int>();
            var nextUnpaidDue = new Dictionary<int, DateTime?>();

            if (ids.Count > 0)
            {
                payCounts = _db.Payments.AsNoTracking()
                    .Where(p => ids.Contains(p.ContractId))
                    .GroupBy(p => p.ContractId)
                    .Select(g => new { ContractId = g.Key, Cnt = g.Count() })
                    .ToList()
                    .ToDictionary(x => x.ContractId, x => x.Cnt);

                nextUnpaidDue = _db.Payments.AsNoTracking()
                    .Where(p => ids.Contains(p.ContractId) && !p.IsPaid)
                    .GroupBy(p => p.ContractId)
                    .Select(g => new
                    {
                        ContractId = g.Key,
                        NextDue = g.Min(x => (DateTime?)x.DueDate)
                    })
                    .ToList()
                    .ToDictionary(x => x.ContractId, x => x.NextDue);
            }

            var rows = new List<ContractRow>(contracts.Count);
            foreach (var c in contracts)
            {
                var isActive = c.EndDate.Date >= today;
                var role = DetermineOurRoleDisplay(c);

                nextUnpaidDue.TryGetValue(c.Id, out var nextDue);
                var payStatus = DeterminePaymentStatus(nextDue, today);

                rows.Add(new ContractRow
                {
                    Id = c.Id,
                    BranchName = c.BranchName,
                    ContractType = c.ContractType,
                    LessorName = c.LessorName ?? "",
                    TenantName = c.TenantName ?? "",
                    ContractNumber = c.ContractNumber ?? "",
                    ElectricityAccountNumber = c.ElectricityAccountNumber,
                    WaterAccountNumber = c.WaterAccountNumber,
                    StartDate = c.StartDate,
                    EndDate = c.EndDate,
                    AmountBeforeTax = c.AmountBeforeTax,
                    VatAmount = c.VatAmount,
                    AdditionalFixedAmounts = c.AdditionalFixedAmounts,
                    InstallmentsCount = c.InstallmentsCount,
                    Status = c.Status ?? "Active",
                    PaymentsCount = payCounts.TryGetValue(c.Id, out var cnt) ? cnt : 0,
                    OurRoleDisplay = role,
                    IsActive = isActive,
                    StatusDisplay = isActive ? "ساري" : "منتهي",
                    NextDueDate = nextDue,
                    PaymentStatus = payStatus
                });
            }

            if (roleTxt == "نحن المؤجر")
                rows = rows.Where(r => r.OurRoleDisplay == "نحن المؤجر").ToList();
            else if (roleTxt == "نحن المستأجر")
                rows = rows.Where(r => r.OurRoleDisplay == "نحن المستأجر").ToList();

            if (dueTxt == "متأخر")
                rows = rows.Where(r => r.PaymentStatus == "متأخر").ToList();
            else if (dueTxt == "خلال 30 يوم")
                rows = rows.Where(r => r.PaymentStatus == "خلال 30 يوم").ToList();
            else if (dueTxt == "سليم")
                rows = rows.Where(r => r.PaymentStatus == "سليم").ToList();

            ContractsGrid.ItemsSource = rows;
        }

        private string GetComboSelectedTextSafe(string comboName, string defaultValue)
        {
            try
            {
                var cb = this.FindName(comboName) as ComboBox;
                if (cb?.SelectedItem is ComboBoxItem item)
                    return (item.Content?.ToString() ?? defaultValue).Trim();

                return defaultValue;
            }
            catch
            {
                return defaultValue;
            }
        }

        private static string DetermineOurRoleDisplay(Contract c)
        {
            return c.Direction == ContractDirection.CompanyReceives
                ? "نحن المؤجر"
                : "نحن المستأجر";
        }

        private static string DeterminePaymentStatus(DateTime? nextDue, DateTime today)
        {
            if (!nextDue.HasValue) return "سليم";

            var d = nextDue.Value.Date;
            if (d < today.Date) return "متأخر";

            var days = (d - today.Date).TotalDays;
            if (days <= DueSoonDays) return "خلال 30 يوم";

            return "سليم";
        }

        // ==============================
        // CRUD
        // ==============================
        private void AddContract_Click(object sender, RoutedEventArgs e)
        {
            AddContractWindow addWin = new AddContractWindow { Owner = Window.GetWindow(this) };
            if (addWin.ShowDialog() == true)
            {
                LoadData();
                MessageBox.Show("تمت إضافة العقد الجديد بنجاح ✅", "Zain System");
            }
        }

        private void EditContract_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is ContractRow row)
            {
                var selected = _db.Contracts.AsNoTracking().FirstOrDefault(c => c.Id == row.Id);
                if (selected == null) return;

                AddContractWindow editWin = new AddContractWindow(selected) { Owner = Window.GetWindow(this) };
                if (editWin.ShowDialog() == true)
                {
                    LoadData();
                    MessageBox.Show("تم تحديث بيانات العقد بنجاح ✅", "Zain System");
                }
            }
        }

        private void DeleteContract_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is ContractRow row)
            {
                var result = MessageBox.Show($"هل أنت متأكد من حذف العقد رقم: {row.ContractNumber}؟",
                                           "تأكيد حذف", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        var contractToDelete = _db.Contracts.Find(row.Id);
                        if (contractToDelete != null)
                        {
                            _db.Contracts.Remove(contractToDelete);
                            _db.SaveChanges();
                            LoadData();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("خطأ أثناء الحذف: " + ex.Message);
                    }
                }
            }
        }

        // ==============================
        // ✅ زر "الدفعات" (Gold Navigation Fix)
        // ==============================
        private void OpenPayments_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button)?.DataContext is not ContractRow row) return;

            try
            {
                // خزّن العقد المحدد علشان PaymentsView يستخدمه
                try
                {
                    Application.Current.Properties["SelectedContractId"] = row.Id;
                    Application.Current.Properties["SelectedContractNumber"] = row.ContractNumber ?? "";
                }
                catch { }

                // ✅ Navigation داخل MainWindow بدل ShowDialog
                if (Application.Current.MainWindow is MainWindow main)
                {
                    main.MainContentHost.Content = new PaymentsView();
                }
                else
                {
                    MessageBox.Show("تعذر الوصول للنافذة الرئيسية.", "Payments", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح شاشة الدفعات: " + ex.Message, "Payments", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ==============================
        // Export Excel (EPPlus) - Enterprise
        // ==============================
        private List<ContractRow> GetCurrentRows()
        {
            try
            {
                return ContractsGrid.ItemsSource?.Cast<ContractRow>().ToList() ?? new List<ContractRow>();
            }
            catch
            {
                return new List<ContractRow>();
            }
        }

        public void ExportAllExcel_Click(object sender, RoutedEventArgs e)
        {
            var list = GetCurrentRows();
            if (list.Count == 0) return;

            try
            {
                var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                var path = Path.Combine(desktop, "كشف_العقود_Zain.xlsx");

                using var package = new ExcelPackage();
                var ws = package.Workbook.Worksheets.Add("كشف العقود");
                ws.View.RightToLeft = true;

                // ===== Header (Brand) =====
                ws.Cells["A1:R1"].Merge = true;
                ws.Cells["A1"].Value = "ZAIN SYSTEM™ | كشف العقود التجارية";
                ws.Cells["A1"].Style.Font.Size = 16;
                ws.Cells["A1"].Style.Font.Bold = true;
                ws.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws.Cells["A1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Row(1).Height = 28;

                ws.Cells["A2:R2"].Merge = true;
                ws.Cells["A2"].Value = $"تاريخ التصدير: {DateTime.Now:yyyy/MM/dd HH:mm}";
                ws.Cells["A2"].Style.Font.Size = 10;
                ws.Cells["A2"].Style.Font.Color.SetColor(Color.DimGray);
                ws.Cells["A2"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                // Optional: add logo if exists
                // ضع logo.png داخل: Assets/logo.png وغيّر المسار لو مختلف
                try
                {
                    var logoPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "logo.png");
                    if (File.Exists(logoPath))
                    {
                        var pic = ws.Drawings.AddPicture("logo", new FileInfo(logoPath));
                        pic.SetPosition(0, 2, 0, 2);
                        pic.SetSize(60, 60);
                    }
                }
                catch { }

                // ===== Table headers =====
                string[] headers =
                {
                    "الفرع","نوع العقد","دورنا","المؤجر","المستأجر","رقم العقد",
                    "الكهرباء","المياه","البداية","النهاية",
                    "قبل الضريبة","الضريبة","ثابتة","الإجمالي",
                    "عدد الدفعات","دفعات مسجلة","الحالة","الحالة المالية"
                };

                int headerRow = 4;
                for (int i = 0; i < headers.Length; i++)
                {
                    var cell = ws.Cells[headerRow, i + 1];
                    cell.Value = headers[i];
                    cell.Style.Font.Bold = true;
                    cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    cell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(17, 24, 39)); // dark
                    cell.Style.Font.Color.SetColor(Color.White);
                    cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    cell.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                }
                ws.Row(headerRow).Height = 22;

                // ===== Rows =====
                int row = headerRow + 1;
                foreach (var item in list)
                {
                    ws.Cells[row, 1].Value = item.BranchName ?? "";
                    ws.Cells[row, 2].Value = item.ContractType ?? "";
                    ws.Cells[row, 3].Value = item.OurRoleDisplay;
                    ws.Cells[row, 4].Value = item.LessorName;
                    ws.Cells[row, 5].Value = item.TenantName;
                    ws.Cells[row, 6].Value = item.ContractNumber;

                    ws.Cells[row, 7].Value = item.ElectricityAccountNumber ?? "";
                    ws.Cells[row, 8].Value = item.WaterAccountNumber ?? "";

                    ws.Cells[row, 9].Value = item.StartDate;
                    ws.Cells[row, 10].Value = item.EndDate;

                    ws.Cells[row, 11].Value = (double)item.AmountBeforeTax;
                    ws.Cells[row, 12].Value = (double)item.VatAmount;
                    ws.Cells[row, 13].Value = (double)item.AdditionalFixedAmounts;
                    ws.Cells[row, 14].Value = (double)item.TotalAmount;

                    ws.Cells[row, 15].Value = item.InstallmentsCount;
                    ws.Cells[row, 16].Value = item.PaymentsCount;
                    ws.Cells[row, 17].Value = item.StatusDisplay;
                    ws.Cells[row, 18].Value = item.PaymentStatus;

                    // Formatting
                    ws.Cells[row, 9].Style.Numberformat.Format = "yyyy/mm/dd";
                    ws.Cells[row, 10].Style.Numberformat.Format = "yyyy/mm/dd";
                    ws.Cells[row, 11, row, 14].Style.Numberformat.Format = "#,##0";

                    // Borders + alignment
                    for (int c = 1; c <= 18; c++)
                    {
                        var cell = ws.Cells[row, c];
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }

                    row++;
                }

                // ===== Footer حقوق =====
                int footerRow = row + 1;
                ws.Cells[footerRow, 1, footerRow, 18].Merge = true;
                ws.Cells[footerRow, 1].Value = "© ZAIN SYSTEM 2026 | All Rights Reserved to Mustafa Zain | جميع الحقوق محفوظة";
                ws.Cells[footerRow, 1].Style.Font.Size = 9;
                ws.Cells[footerRow, 1].Style.Font.Color.SetColor(Color.DimGray);
                ws.Cells[footerRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                ws.Cells[ws.Dimension.Address].AutoFitColumns();

                package.SaveAs(new FileInfo(path));
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء تصدير اكسل: " + ex.Message);
            }
        }

        // ✅ PDF export: نسيبه لاحقاً لو حابب (دلوقتي توحيد EPPlus أولاً)
        public void ExportAllPdf_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("تصدير PDF سيتم توحيده لاحقاً بعد إنهاء Excel لكل الصفحات.", "Zain System");
        }
    }
}