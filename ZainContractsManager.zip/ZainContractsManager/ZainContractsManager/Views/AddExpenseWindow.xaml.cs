﻿#nullable disable
using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

// ✅ ربط المحرك المالي
using ZainContractsManager.Services.FinanceEngine;

namespace ZainContractsManager.Views
{
    public partial class AddExpenseWindow : Window
    {
        private FinancialExpense _editableExpense;
        private string _selectedFilePath;

        public AddExpenseWindow()
        {
            InitializeComponent();

            if (DateInvoice != null) DateInvoice.SelectedDate = DateTime.Now;

            // ✅ افتراضيًا: لو المستخدم علم "تم السداد" وما اختارش تاريخ سداد
            // نخلي PaidAt = اليوم
            if (DatePaidAt != null) DatePaidAt.SelectedDate = DateTime.Now;
        }

        public AddExpenseWindow(FinancialExpense expense) : this()
        {
            _editableExpense = expense;
            LoadData();
        }

        private void LoadData()
        {
            if (_editableExpense == null) return;

            TxtBranchManual.Text = _editableExpense.BranchName;
            TxtContractNumber.Text = _editableExpense.ContractNumber;

            TxtInvoiceNumber.Text = _editableExpense.InvoiceNumber;
            DateInvoice.SelectedDate = _editableExpense.InvoiceDate;

            TxtAmountBase.Text = _editableExpense.Amount.ToString("N2");
            TxtTaxAmount.Text = _editableExpense.TaxAmount.ToString("N2");
            TxtDescription.Text = _editableExpense.Description;

            // ✅ الحقول الجديدة (السداد)
            if (ChkIsPaid != null) ChkIsPaid.IsChecked = _editableExpense.IsPaid;
            if (DatePaidAt != null) DatePaidAt.SelectedDate = _editableExpense.PaidAt ?? DateTime.Now;

            // PaymentMethod
            if (ComboPaymentMethod != null)
            {
                if (!string.IsNullOrWhiteSpace(_editableExpense.PaymentMethod))
                    ComboPaymentMethod.Text = _editableExpense.PaymentMethod;
            }

            // ReferenceNo
            if (TxtReferenceNo != null && !string.IsNullOrWhiteSpace(_editableExpense.ReferenceNo))
                TxtReferenceNo.Text = _editableExpense.ReferenceNo;

            // لو كان عنده ملف مرفق قبل كده
            if (!string.IsNullOrWhiteSpace(_editableExpense.AttachmentPath))
                TxtFileName.Text = System.IO.Path.GetFileName(_editableExpense.AttachmentPath);

            UpdateTotals();
        }

        private void CalculateAmounts(object sender, EventArgs e) => UpdateTotals();

        private void UpdateTotals()
        {
            if (TxtAmountBase == null || LblTotalAmount == null) return;

            if (decimal.TryParse(TxtAmountBase.Text, out decimal baseAmt))
            {
                decimal tax = (CheckIsTaxable.IsChecked == true) ? baseAmt * 0.15m : 0m;
                if (TxtTaxAmount != null) TxtTaxAmount.Text = tax.ToString("N2");

                // للعرض فقط
                LblTotalAmount.Text = (baseAmt + tax).ToString("N2") + " ريال";
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtBranchManual.Text) || string.IsNullOrWhiteSpace(TxtAmountBase.Text))
            {
                MessageBox.Show("يرجى إكمال البيانات الأساسية.");
                return;
            }

            try
            {
                using (var db = new AppDbContext())
                {
                    // ✅ لازم تكون الشركة الحالية محددة (Multi-Tenant)
                    var companyId = db.CurrentCompanyId;
                    if (companyId <= 0)
                    {
                        MessageBox.Show("اختيار (شركة) مطلوب قبل حفظ المصروفات.");
                        return;
                    }

                    // =========================
                    // 1) Load or create entity
                    // =========================
                    var expense = _editableExpense != null
                        ? db.FinancialExpenses.Find(_editableExpense.Id)
                        : new FinancialExpense();

                    if (expense == null)
                    {
                        MessageBox.Show("تعذر تحميل السند للتعديل.");
                        return;
                    }

                    // ✅ حماية: لو تعديل سند قديم لشركة مختلفة لا تسمح
                    if (_editableExpense != null && expense.CompanyId != 0 && expense.CompanyId != companyId)
                    {
                        MessageBox.Show("لا يمكن تعديل سند لا يخص الشركة الحالية.");
                        return;
                    }

                    // Snapshot قبل التعديل (لمنع Posting مرتين)
                    bool wasPaidBefore = expense.IsPaid;

                    // =========================
                    // 2) ✅ أهم سطر: Tenant Scope
                    // =========================
                    expense.CompanyId = companyId;

                    // =========================
                    // 3) Assign base fields
                    // =========================
                    expense.BranchName = (TxtBranchManual.Text ?? "").Trim();

                    // ✅ ContractNumber في الموديل عندك string (غير nullable) => نخليه "" بدل null
                    expense.ContractNumber = string.IsNullOrWhiteSpace(TxtContractNumber.Text)
                        ? ""
                        : TxtContractNumber.Text.Trim();

                    expense.InvoiceNumber = (TxtInvoiceNumber.Text ?? "").Trim();
                    expense.InvoiceDate = DateInvoice.SelectedDate ?? DateTime.Now;

                    expense.Category = (ComboCategory?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "عام";

                    if (decimal.TryParse(TxtAmountBase.Text, out decimal amt)) expense.Amount = amt;
                    if (decimal.TryParse(TxtTaxAmount.Text, out decimal tx)) expense.TaxAmount = tx;

                    expense.Description = (TxtDescription.Text ?? "").Trim();

                    // =========================
                    // 4) Attachment path (اختياري)
                    // =========================
                    if (!string.IsNullOrWhiteSpace(_selectedFilePath))
                        expense.AttachmentPath = _selectedFilePath;

                    // =========================
                    // 5) Paid Fields from UI
                    // =========================
                    bool isPaidNow = (ChkIsPaid != null && ChkIsPaid.IsChecked == true);

                    expense.IsPaid = isPaidNow;

                    if (isPaidNow)
                    {
                        // PaidAt
                        expense.PaidAt = (DatePaidAt != null && DatePaidAt.SelectedDate.HasValue)
                            ? DatePaidAt.SelectedDate.Value
                            : DateTime.Now;

                        // PaymentMethod
                        expense.PaymentMethod = (ComboPaymentMethod?.Text ?? "").Trim();
                        if (string.IsNullOrWhiteSpace(expense.PaymentMethod))
                            expense.PaymentMethod = "Bank"; // افتراضي محترم

                        // ReferenceNo
                        var refNo = (TxtReferenceNo?.Text ?? "").Trim();
                        expense.ReferenceNo = string.IsNullOrWhiteSpace(refNo) ? null : refNo;
                    }
                    else
                    {
                        // لو مش مدفوع: نخلي معلومات السداد فاضية
                        expense.PaidAt = null;
                        expense.PaymentMethod = null;
                        expense.ReferenceNo = null;
                    }

                    // =========================
                    // 6) Insert / Update
                    // =========================
                    if (_editableExpense == null)
                    {
                        expense.ExpenseNumber = "EXP-" + DateTime.Now.ToString("yyyyMMddHHmmss");
                        expense.ExpenseDate = DateTime.Now;
                        db.FinancialExpenses.Add(expense);
                    }

                    db.SaveChanges();

                    // =========================
                    // 7) Financial Engine Posting
                    // =========================
                    // ✅ يعمل Posting فقط لو:
                    // - السند مدفوع الآن
                    // - وكان غير مدفوع قبل كده (عشان ما نكرر)
                    // - أو سند جديد مدفوع
                    bool becamePaidNow = expense.IsPaid && !wasPaidBefore;

                    if (expense.IsPaid && (_editableExpense == null || becamePaidNow))
                    {
                        var engine = new FinancialEngineService(db);
                        engine.PostExpenseIfPaid(expense);

                        // ✅ optional: لو المحرك بيسجّل JournalEntryId داخل expense
                        db.SaveChanges();
                    }
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء الحفظ: " + ex.Message);
            }
        }

        private void BtnUpload_Click(object sender, RoutedEventArgs e)
        {
            var op = new OpenFileDialog
            {
                Filter = "All Supported|*.pdf;*.jpg;*.jpeg;*.png|PDF|*.pdf|Images|*.jpg;*.jpeg;*.png|All Files|*.*"
            };

            if (op.ShowDialog() == true)
            {
                _selectedFilePath = op.FileName;
                TxtFileName.Text = System.IO.Path.GetFileName(op.FileName);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => Close();
    }
}