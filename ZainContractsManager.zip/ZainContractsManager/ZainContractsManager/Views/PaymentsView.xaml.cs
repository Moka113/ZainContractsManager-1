﻿#nullable disable
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using ZainContractsManager.Data;
using ZainContractsManager.Models;

// ✅ حل تعارض PaymentDirection (استخدم Enum الموديل فقط)
using PaymentDirection = ZainContractsManager.Models.PaymentDirection;

// ✅ Fix: تعارض LicenseContext بين System.ComponentModel و EPPlus
using EpplusLicenseContext = OfficeOpenXml.LicenseContext;

// ✅ Finance Posting
using ZainContractsManager.Services.FinanceEngine;

namespace ZainContractsManager.Views
{
    public partial class PaymentsView : UserControl
    {
        private readonly ObservableCollection<Payment> _items = new ObservableCollection<Payment>();
        private ICollectionView _view;

        // ✅ لو فاتح الدفعات من عقد محدد
        private int _selectedContractId = 0;

        public PaymentsView()
        {
            InitializeComponent();

            // ✅ EPPlus License (بدون Ambiguous)
            ExcelPackage.LicenseContext = EpplusLicenseContext.NonCommercial;

            GridPayments.ItemsSource = _items;
            _view = CollectionViewSource.GetDefaultView(_items);
            _view.Filter = FilterPayment;

            Loaded += PaymentsView_Loaded;
        }

        private void PaymentsView_Loaded(object sender, RoutedEventArgs e)
        {
            // ✅ اقرأ ContractId المختار (لو موجود)
            try
            {
                if (Application.Current?.Properties != null &&
                    Application.Current.Properties.Contains("SelectedContractId"))
                {
                    int.TryParse(Application.Current.Properties["SelectedContractId"]?.ToString(), out _selectedContractId);
                }
            }
            catch { }

            RefreshPayments();
        }

        // =========================================================
        // Load + KPIs
        // =========================================================
        private void RefreshPayments()
        {
            try
            {
                using var db = new AppDbContext();

                // ✅ Global Query Filter (CompanyId) شغال من DbContext
                var query = db.Payments
                    .AsNoTracking()
                    .Include(p => p.Contract)
                    .AsQueryable();

                // ✅ فلترة دفعات العقد المحدد فقط
                if (_selectedContractId > 0)
                    query = query.Where(p => p.ContractId == _selectedContractId);

                var list = query
                    .OrderByDescending(p => p.DueDate)
                    .ThenByDescending(p => p.Id)
                    .ToList();

                _items.Clear();
                foreach (var p in list)
                    _items.Add(p);

                _view.Refresh();
                UpdateKpis();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر تحميل الدفعات: " + ex.Message);
            }
        }

        private void UpdateKpis()
        {
            try
            {
                var today = DateTime.Today;

                var overdue = _items
                    .Where(p => !p.IsPaid && p.DueDate.Date < today)
                    .Sum(p => p.Amount);

                var monthDue = _items
                    .Where(p => !p.IsPaid && p.DueDate.Year == today.Year && p.DueDate.Month == today.Month)
                    .Sum(p => p.Amount);

                var paid = _items
                    .Where(p => p.IsPaid)
                    .Sum(p => p.Amount);

                var lessorOutgoing = _items
                    .Where(p => p.Direction == PaymentDirection.Outgoing)
                    .Sum(p => p.Amount);

                var tenantIncoming = _items
                    .Where(p => p.Direction == PaymentDirection.Incoming)
                    .Sum(p => p.Amount);

                TxtOverdue.Text = overdue.ToString("N2");
                TxtMonthDue.Text = monthDue.ToString("N2");
                TxtPaid.Text = paid.ToString("N2");
                TxtLessorTotal.Text = lessorOutgoing.ToString("N2");
                TxtTenantTotal.Text = tenantIncoming.ToString("N2");
            }
            catch
            {
                // ignore KPI errors
            }
        }

        // =========================================================
        // Search
        // =========================================================
        private void TxtSmartSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            _view.Refresh();
        }

        private bool FilterPayment(object obj)
        {
            var p = obj as Payment;
            if (p == null) return false;

            var q = (TxtSmartSearch?.Text ?? "").Trim();
            if (string.IsNullOrWhiteSpace(q)) return true;

            q = q.ToLowerInvariant();

            string contractNo = (p.Contract?.ContractNumber ?? "").ToLowerInvariant();
            string lessor = (p.Contract?.LessorName ?? "").ToLowerInvariant();
            string tenant = (p.Contract?.TenantName ?? "").ToLowerInvariant();

            string cat = (p.Category ?? "").ToLowerInvariant();
            string method = (p.PaymentMethod ?? "").ToLowerInvariant();
            string refNo = (p.ReferenceNo ?? "").ToLowerInvariant();

            string dir = (p.Direction == PaymentDirection.Incoming ? "تحصيل" : "سداد");

            return contractNo.Contains(q)
                || lessor.Contains(q)
                || tenant.Contains(q)
                || cat.Contains(q)
                || method.Contains(q)
                || refNo.Contains(q)
                || dir.Contains(q);
        }

        // =========================================================
        // ✅ Posting (ترحيل محاسبي)
        // =========================================================

        private void PostToJournal_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment == null) return;

            try
            {
                using var db = new AppDbContext();

                var row = db.Payments.FirstOrDefault(x => x.Id == payment.Id);
                if (row == null)
                {
                    MessageBox.Show("لم يتم العثور على الدفعة في قاعدة البيانات.");
                    return;
                }

                if (!row.IsPaid)
                {
                    MessageBox.Show("لا يمكن ترحيل دفعة غير مسددة. فعّل IsPaid أولاً.");
                    return;
                }

                if (row.JournalEntryId.HasValue || row.IsPostedToJournal)
                {
                    MessageBox.Show("هذه الدفعة مُرحّلة بالفعل ✅");
                    return;
                }

                PostingService.PostPayment(db, row.Id);

                MessageBox.Show("تم ترحيل الدفعة إلى القيود اليومية بنجاح ✅");
                RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل ترحيل الدفعة: " + ex.Message);
            }
        }

        private void PostAllPaid_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using var db = new AppDbContext();

                var list = db.Payments
                    .Where(p => p.IsPaid
                                && !p.IsPostedToJournal
                                && !p.JournalEntryId.HasValue)
                    .OrderBy(p => p.Id)
                    .Select(p => p.Id)
                    .ToList();

                if (list.Count == 0)
                {
                    MessageBox.Show("لا توجد دفعات مدفوعة غير مُرحلة.");
                    return;
                }

                int ok = 0, failed = 0;

                foreach (var id in list)
                {
                    try
                    {
                        PostingService.PostPayment(db, id);
                        ok++;
                    }
                    catch
                    {
                        failed++;
                    }
                }

                MessageBox.Show($"تم الترحيل ✅\nنجاح: {ok}\nفشل: {failed}");
                RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل ترحيل الكل: " + ex.Message);
            }
        }

        // =========================================================
        // Add / Edit / Delete
        // =========================================================
        private void AddPayment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var win = new AddPaymentWindow
                {
                    Owner = Window.GetWindow(this)
                };

                var ok = win.ShowDialog();
                if (ok == true)
                    RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح نافذة إضافة الدفعات: " + ex.Message);
            }
        }

        private void EditPayment_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var payment = (sender as Button)?.DataContext as Payment;
                if (payment == null) return;

                var win = new AddPaymentWindow(payment)
                {
                    Owner = Window.GetWindow(this)
                };

                var ok = win.ShowDialog();
                if (ok == true)
                    RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر تعديل الدفعة: " + ex.Message);
            }
        }

        private void DeletePayment_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment == null) return;

            var res = MessageBox.Show(
                $"هل أنت متأكد من حذف الدفعة؟\n\nرقم العقد: {payment.Contract?.ContractNumber}\nالمبلغ: {payment.Amount:N2}",
                "تأكيد الحذف",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (res != MessageBoxResult.Yes) return;

            try
            {
                using var db = new AppDbContext();

                var row = db.Payments.FirstOrDefault(x => x.Id == payment.Id);
                if (row == null)
                {
                    MessageBox.Show("لم يتم العثور على الدفعة في قاعدة البيانات.");
                    return;
                }

                if (row.JournalEntryId.HasValue || row.IsPostedToJournal)
                {
                    MessageBox.Show("لا يمكن حذف دفعة مُرحّلة محاسبياً.\n(المستوى الاحترافي: نعمل Reverse بدلاً من الحذف).");
                    return;
                }

                db.Payments.Remove(row);
                db.SaveChanges();

                RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل حذف الدفعة: " + ex.Message);
            }
        }

        // =========================================================
        // Attachments
        // =========================================================
        private void AttachDocument_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment == null) return;

            try
            {
                var dlg = new OpenFileDialog
                {
                    Title = "اختر سند الأرشفة",
                    Filter = "All Files|*.*|PDF|*.pdf|Images|*.png;*.jpg;*.jpeg",
                    Multiselect = false
                };

                if (dlg.ShowDialog() != true) return;

                var attachFolder = Path.Combine(AppDbContext.DbFolder, "Attachments", "Payments");
                Directory.CreateDirectory(attachFolder);

                var ext = Path.GetExtension(dlg.FileName);
                var safeName = $"PAY_{payment.Id}_{DateTime.Now:yyyyMMdd_HHmmss}{ext}";
                var dest = Path.Combine(attachFolder, safeName);

                File.Copy(dlg.FileName, dest, true);

                using var db = new AppDbContext();
                var row = db.Payments.FirstOrDefault(x => x.Id == payment.Id);
                if (row == null) return;

                row.AttachmentPath = dest;
                db.SaveChanges();

                MessageBox.Show("تم إرفاق السند بنجاح ✅");
                RefreshPayments();
            }
            catch (Exception ex)
            {
                MessageBox.Show("فشل إرفاق السند: " + ex.Message);
            }
        }

        private void ViewAttachment_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment == null) return;

            var path = payment.AttachmentPath;
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                MessageBox.Show("لا يوجد ملف مرفق لهذه الدفعة.");
                return;
            }

            try
            {
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح المرفق: " + ex.Message);
            }
        }

        // =========================================================
        // WhatsApp
        // =========================================================
        private void WhatsApp_Click(object sender, RoutedEventArgs e)
        {
            var payment = (sender as Button)?.DataContext as Payment;
            if (payment == null) return;

            var phone = TryGetContractPhone(payment);

            if (string.IsNullOrWhiteSpace(phone))
            {
                MessageBox.Show("لم يتم العثور على رقم واتساب داخل بيانات العقد (Tenant/Lessor).");
                return;
            }

            var msg =
                $"تنبيه دفعة\n" +
                $"العقد: {payment.Contract?.ContractNumber}\n" +
                $"المبلغ: {payment.Amount:N2}\n" +
                $"الاستحقاق: {payment.DueDate:yyyy/MM/dd}\n" +
                $"الحالة: {(payment.IsPaid ? "تم السداد" : "مستحق")}";

            OpenWhatsApp(phone, msg);
        }

        private static string TryGetContractPhone(Payment p)
        {
            var c = p.Contract;
            if (c == null) return null;

            string[] candidates =
            {
                "TenantPhone", "TenantMobile", "TenantMobileNo", "TenantPhoneNumber",
                "LessorPhone", "LessorMobile", "LessorMobileNo", "LessorPhoneNumber",
                "Phone", "Mobile"
            };

            foreach (var name in candidates)
            {
                var prop = c.GetType().GetProperty(name);
                if (prop == null) continue;
                var val = prop.GetValue(c)?.ToString();
                if (!string.IsNullOrWhiteSpace(val))
                    return val.Trim();
            }

            return null;
        }

        private static void OpenWhatsApp(string phoneRaw, string message)
        {
            try
            {
                var phone = NormalizePhone(phoneRaw);
                var url = $"https://wa.me/{phone}?text={Uri.EscapeDataString(message)}";
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("تعذر فتح واتساب: " + ex.Message);
            }
        }

        private static string NormalizePhone(string phone)
        {
            var p = new string(phone.Where(char.IsDigit).ToArray());

            if (p.StartsWith("0"))
                p = "966" + p.Substring(1);

            return p;
        }

        // =========================================================
        // Reports Menu (Excel Exports)
        // =========================================================
        private void BtnReports_Click(object sender, RoutedEventArgs e)
        {
            if (BtnReports?.ContextMenu != null)
            {
                BtnReports.ContextMenu.PlacementTarget = BtnReports;
                BtnReports.ContextMenu.IsOpen = true;
            }
        }

        private void ReportCurrentMonth_Click(object sender, RoutedEventArgs e)
        {
            var d = DateTime.Today;
            var data = GetReportData(p => !p.IsPaid && p.DueDate.Year == d.Year && p.DueDate.Month == d.Month);
            ExportPaymentsExcel(data, $"تقرير استحقاق الشهر الحالي ({d:yyyy/MM})", $"تقرير_استحقاق_الشهر_الحالي_{d:yyyy_MM}.xlsx");
        }

        private void ReportNextMonth_Click(object sender, RoutedEventArgs e)
        {
            var d = DateTime.Today.AddMonths(1);
            var data = GetReportData(p => !p.IsPaid && p.DueDate.Year == d.Year && p.DueDate.Month == d.Month);
            ExportPaymentsExcel(data, $"تقرير استحقاق الشهر القادم ({d:yyyy/MM})", $"تقرير_استحقاق_الشهر_القادم_{d:yyyy_MM}.xlsx");
        }

        private void ReportYearly_Click(object sender, RoutedEventArgs e)
        {
            var y = DateTime.Today.Year;
            var data = GetReportData(p => !p.IsPaid && p.DueDate.Year == y);
            ExportPaymentsExcel(data, $"تقرير استحقاق العام ({y})", $"تقرير_استحقاق_العام_{y}.xlsx");
        }

        private void ReportPaid_Click(object sender, RoutedEventArgs e)
        {
            var data = GetReportData(p => p.IsPaid);
            ExportPaymentsExcel(data, $"تقرير الدفعات التي تم سدادها", $"تقرير_الدفعات_المسددة_{DateTime.Today:yyyy_MM_dd}.xlsx");
        }

        private void ReportOverdue_Click(object sender, RoutedEventArgs e)
        {
            var today = DateTime.Today;
            var data = GetReportData(p => !p.IsPaid && p.DueDate.Date < today);
            ExportPaymentsExcel(data, $"تقرير الدفعات المتأخرة حتى {today:yyyy/MM/dd}", $"تقرير_الدفعات_المتأخرة_{DateTime.Today:yyyy_MM_dd}.xlsx");
        }

        private void ReportTenant_Click(object sender, RoutedEventArgs e)
        {
            var all = GetReportData(_ => true);

            ExportAccountExcel(
                all,
                groupBy: p => (p.Contract?.TenantName ?? "غير محدد").Trim(),
                title: "كشف حساب مستأجر",
                fileName: $"كشف_حساب_مستأجر_{DateTime.Today:yyyy_MM_dd}.xlsx"
            );
        }

        private void ReportLessor_Click(object sender, RoutedEventArgs e)
        {
            var all = GetReportData(_ => true);

            ExportAccountExcel(
                all,
                groupBy: p => (p.Contract?.LessorName ?? "غير محدد").Trim(),
                title: "كشف حساب مؤجر",
                fileName: $"كشف_حساب_مؤجر_{DateTime.Today:yyyy_MM_dd}.xlsx"
            );
        }

        // =========================================================
        // ✅ Excel Engine (EPPlus) - Same Table as Grid
        // =========================================================
        private List<Payment> GetReportData(Func<Payment, bool> predicate)
        {
            try
            {
                return _items
                    .Where(p => p != null && predicate(p))
                    .OrderByDescending(p => p.DueDate)
                    .ThenByDescending(p => p.Id)
                    .ToList();
            }
            catch
            {
                return new List<Payment>();
            }
        }

        private void ExportPaymentsExcel(List<Payment> list, string reportTitle, string fileName)
        {
            try
            {
                if (list == null || list.Count == 0)
                {
                    MessageBox.Show("لا توجد بيانات لإخراج التقرير.");
                    return;
                }

                var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                var path = Path.Combine(desktop, fileName);

                using var pck = new ExcelPackage();
                var ws = pck.Workbook.Worksheets.Add("Payments");
                ws.View.RightToLeft = true;

                string[] headers =
                {
                    "الاتجاه",
                    "رقم العقد",
                    "المؤجر",
                    "المستأجر",
                    "المبلغ",
                    "تاريخ الاستحقاق",
                    "التصنيف",
                    "طريقة السداد",
                    "المرجع",
                    "تاريخ السداد",
                    "الحالة",
                    "الترحيل"
                };

                ws.Cells["A1:L1"].Merge = true;
                ws.Cells["A1"].Value = $"ZAIN SYSTEM ™️ | {reportTitle}";
                ws.Cells["A1"].Style.Font.Size = 16;
                ws.Cells["A1"].Style.Font.Bold = true;
                ws.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws.Cells["A1"].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                ws.Row(1).Height = 28;

                TryAddLogo(ws);
                TryAddStamp(ws);

                for (int i = 0; i < headers.Length; i++)
                {
                    var c = ws.Cells[3, i + 1];
                    c.Value = headers[i];
                    c.Style.Font.Bold = true;
                    c.Style.Font.Color.SetColor(Color.White);
                    c.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    c.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59)); // #1E293B
                    c.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    c.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    c.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                }
                ws.Row(3).Height = 22;

                int r = 4;
                foreach (var p in list)
                {
                    var dirTxt = p.Direction == PaymentDirection.Incoming ? "تحصيل" : "سداد";

                    ws.Cells[r, 1].Value = dirTxt;
                    ws.Cells[r, 2].Value = p.Contract?.ContractNumber ?? "";
                    ws.Cells[r, 3].Value = p.Contract?.LessorName ?? "";
                    ws.Cells[r, 4].Value = p.Contract?.TenantName ?? "";
                    ws.Cells[r, 5].Value = p.Amount;
                    ws.Cells[r, 6].Value = p.DueDate;
                    ws.Cells[r, 7].Value = p.Category ?? "";
                    ws.Cells[r, 8].Value = p.PaymentMethod ?? "";
                    ws.Cells[r, 9].Value = p.ReferenceNo ?? "";
                    ws.Cells[r, 10].Value = p.PaidAt.HasValue ? (object)p.PaidAt.Value : "";
                    ws.Cells[r, 11].Value = p.IsPaid ? "تم السداد" : "مستحق";
                    ws.Cells[r, 12].Value = p.IsPostedToJournal ? "مُرحّل" : "غير مُرحّل";

                    for (int col = 1; col <= 12; col++)
                    {
                        var cell = ws.Cells[r, col];
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        cell.Style.WrapText = true;
                    }

                    ws.Cells[r, 5].Style.Numberformat.Format = "#,##0.00";
                    ws.Cells[r, 6].Style.Numberformat.Format = "yyyy/mm/dd";
                    ws.Cells[r, 10].Style.Numberformat.Format = "yyyy/mm/dd hh:mm";

                    var dirCell = ws.Cells[r, 1];
                    dirCell.Style.Font.Bold = true;
                    dirCell.Style.Font.Color.SetColor(Color.White);
                    dirCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    dirCell.Style.Fill.BackgroundColor.SetColor(
                        p.Direction == PaymentDirection.Incoming
                        ? Color.FromArgb(22, 163, 74)   // #16A34A
                        : Color.FromArgb(220, 38, 38)   // #DC2626
                    );
                    dirCell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    var st = ws.Cells[r, 11];
                    st.Style.Font.Bold = true;
                    st.Style.Font.Color.SetColor(Color.White);
                    st.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    st.Style.Fill.BackgroundColor.SetColor(p.IsPaid ? Color.FromArgb(16, 185, 129) : Color.FromArgb(239, 68, 68));
                    st.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    var posted = ws.Cells[r, 12];
                    posted.Style.Font.Bold = true;
                    posted.Style.Font.Color.SetColor(Color.White);
                    posted.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    posted.Style.Fill.BackgroundColor.SetColor(p.IsPostedToJournal ? Color.FromArgb(14, 165, 233) : Color.FromArgb(148, 163, 184));
                    posted.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    r++;
                }

                ws.View.FreezePanes(4, 1);
                ws.Cells[3, 1, r - 1, 12].AutoFilter = true;
                ws.Cells[3, 1, r - 1, 12].AutoFitColumns(12, 55);

                int footerRow = r + 1;
                ws.Cells[footerRow, 1, footerRow, 12].Merge = true;
                ws.Cells[footerRow, 1].Value =
                    "ZAIN SYSTEM 2026 ©️ | All Rights Reserved to Mustafa Zain | هذا النظام بجميع ملكياته الفكرية وحقوقه القانونية تعود لـ مصطفى زين";
                ws.Cells[footerRow, 1].Style.Font.Size = 10;
                ws.Cells[footerRow, 1].Style.Font.Bold = true;
                ws.Cells[footerRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws.Cells[footerRow, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                ws.Cells[footerRow, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));
                ws.Row(footerRow).Height = 22;

                pck.SaveAs(new FileInfo(path));
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء إنشاء تقرير Excel: " + ex.Message);
            }
        }

        private void ExportAccountExcel(List<Payment> all, Func<Payment, string> groupBy, string title, string fileName)
        {
            try
            {
                if (all == null || all.Count == 0)
                {
                    MessageBox.Show("لا توجد بيانات لإخراج التقرير.");
                    return;
                }

                var desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                var path = Path.Combine(desktop, fileName);

                using var pck = new ExcelPackage();

                // ================= SUMMARY =================
                var ws1 = pck.Workbook.Worksheets.Add("Summary");
                ws1.View.RightToLeft = true;

                ws1.Cells["A1:F1"].Merge = true;
                ws1.Cells["A1"].Value = $"ZAIN SYSTEM ™️ | {title} (ملخص)";
                ws1.Cells["A1"].Style.Font.Size = 16;
                ws1.Cells["A1"].Style.Font.Bold = true;
                ws1.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws1.Row(1).Height = 28;

                TryAddLogo(ws1);
                TryAddStamp(ws1);

                string[] h =
                {
                    "الطرف",
                    "إجمالي التحصيل",
                    "إجمالي السداد",
                    "المسدّد",
                    "المستحق",
                    "المتأخر"
                };

                for (int i = 0; i < h.Length; i++)
                {
                    var c = ws1.Cells[3, i + 1];
                    c.Value = h[i];
                    c.Style.Font.Bold = true;
                    c.Style.Font.Color.SetColor(Color.White);
                    c.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    c.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59));
                    c.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    c.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                }
                ws1.Row(3).Height = 22;

                var today = DateTime.Today;

                var groups = all
                    .GroupBy(groupBy)
                    .OrderBy(g => g.Key)
                    .Select(g => new
                    {
                        Key = g.Key,
                        Incoming = g.Where(x => x.Direction == PaymentDirection.Incoming).Sum(x => x.Amount),
                        Outgoing = g.Where(x => x.Direction == PaymentDirection.Outgoing).Sum(x => x.Amount),
                        Paid = g.Where(x => x.IsPaid).Sum(x => x.Amount),
                        Unpaid = g.Where(x => !x.IsPaid).Sum(x => x.Amount),
                        Overdue = g.Where(x => !x.IsPaid && x.DueDate.Date < today).Sum(x => x.Amount),
                    })
                    .ToList();

                int r = 4;
                foreach (var g in groups)
                {
                    ws1.Cells[r, 1].Value = g.Key;
                    ws1.Cells[r, 2].Value = g.Incoming;
                    ws1.Cells[r, 3].Value = g.Outgoing;
                    ws1.Cells[r, 4].Value = g.Paid;
                    ws1.Cells[r, 5].Value = g.Unpaid;
                    ws1.Cells[r, 6].Value = g.Overdue;

                    for (int col = 1; col <= 6; col++)
                    {
                        ws1.Cells[r, col].Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                        ws1.Cells[r, col].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    }

                    for (int col = 2; col <= 6; col++)
                        ws1.Cells[r, col].Style.Numberformat.Format = "#,##0.00";

                    r++;
                }

                ws1.View.FreezePanes(4, 1);
                ws1.Cells[3, 1, r - 1, 6].AutoFilter = true;
                ws1.Cells[3, 1, r - 1, 6].AutoFitColumns(12, 55);

                int footerRow = r + 1;
                ws1.Cells[footerRow, 1, footerRow, 6].Merge = true;
                ws1.Cells[footerRow, 1].Value = "ZAIN SYSTEM 2026 ©️ | All Rights Reserved to Mustafa Zain";
                ws1.Cells[footerRow, 1].Style.Font.Bold = true;
                ws1.Cells[footerRow, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws1.Cells[footerRow, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                ws1.Cells[footerRow, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));
                ws1.Row(footerRow).Height = 22;

                // ================= DETAILS =================
                var ws2 = pck.Workbook.Worksheets.Add("Details");
                ws2.View.RightToLeft = true;

                ws2.Cells["A1:L1"].Merge = true;
                ws2.Cells["A1"].Value = $"ZAIN SYSTEM ™️ | {title} (تفاصيل)";
                ws2.Cells["A1"].Style.Font.Size = 16;
                ws2.Cells["A1"].Style.Font.Bold = true;
                ws2.Cells["A1"].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws2.Row(1).Height = 28;

                TryAddLogo(ws2);
                TryAddStamp(ws2);

                string[] headers =
                {
                    "الاتجاه",
                    "رقم العقد",
                    "المؤجر",
                    "المستأجر",
                    "المبلغ",
                    "تاريخ الاستحقاق",
                    "التصنيف",
                    "طريقة السداد",
                    "المرجع",
                    "تاريخ السداد",
                    "الحالة",
                    "الترحيل"
                };

                for (int i = 0; i < headers.Length; i++)
                {
                    var c = ws2.Cells[3, i + 1];
                    c.Value = headers[i];
                    c.Style.Font.Bold = true;
                    c.Style.Font.Color.SetColor(Color.White);
                    c.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    c.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(30, 41, 59));
                    c.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    c.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    c.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.LightGray);
                }
                ws2.Row(3).Height = 22;

                int rr = 4;
                foreach (var p in all.OrderByDescending(x => x.DueDate).ThenByDescending(x => x.Id))
                {
                    var dirTxt = p.Direction == PaymentDirection.Incoming ? "تحصيل" : "سداد";

                    ws2.Cells[rr, 1].Value = dirTxt;
                    ws2.Cells[rr, 2].Value = p.Contract?.ContractNumber ?? "";
                    ws2.Cells[rr, 3].Value = p.Contract?.LessorName ?? "";
                    ws2.Cells[rr, 4].Value = p.Contract?.TenantName ?? "";
                    ws2.Cells[rr, 5].Value = p.Amount;
                    ws2.Cells[rr, 6].Value = p.DueDate;
                    ws2.Cells[rr, 7].Value = p.Category ?? "";
                    ws2.Cells[rr, 8].Value = p.PaymentMethod ?? "";
                    ws2.Cells[rr, 9].Value = p.ReferenceNo ?? "";
                    ws2.Cells[rr, 10].Value = p.PaidAt.HasValue ? (object)p.PaidAt.Value : "";
                    ws2.Cells[rr, 11].Value = p.IsPaid ? "تم السداد" : "مستحق";
                    ws2.Cells[rr, 12].Value = p.IsPostedToJournal ? "مُرحّل" : "غير مُرحّل";

                    for (int col = 1; col <= 12; col++)
                    {
                        var cell = ws2.Cells[rr, col];
                        cell.Style.Border.BorderAround(ExcelBorderStyle.Hair, Color.Gainsboro);
                        cell.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        cell.Style.WrapText = true;
                    }

                    ws2.Cells[rr, 5].Style.Numberformat.Format = "#,##0.00";
                    ws2.Cells[rr, 6].Style.Numberformat.Format = "yyyy/mm/dd";
                    ws2.Cells[rr, 10].Style.Numberformat.Format = "yyyy/mm/dd hh:mm";

                    var dirCell = ws2.Cells[rr, 1];
                    dirCell.Style.Font.Bold = true;
                    dirCell.Style.Font.Color.SetColor(Color.White);
                    dirCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    dirCell.Style.Fill.BackgroundColor.SetColor(
                        p.Direction == PaymentDirection.Incoming
                        ? Color.FromArgb(22, 163, 74)
                        : Color.FromArgb(220, 38, 38)
                    );
                    dirCell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    var st = ws2.Cells[rr, 11];
                    st.Style.Font.Bold = true;
                    st.Style.Font.Color.SetColor(Color.White);
                    st.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    st.Style.Fill.BackgroundColor.SetColor(p.IsPaid ? Color.FromArgb(16, 185, 129) : Color.FromArgb(239, 68, 68));
                    st.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    var posted = ws2.Cells[rr, 12];
                    posted.Style.Font.Bold = true;
                    posted.Style.Font.Color.SetColor(Color.White);
                    posted.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    posted.Style.Fill.BackgroundColor.SetColor(p.IsPostedToJournal ? Color.FromArgb(14, 165, 233) : Color.FromArgb(148, 163, 184));
                    posted.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                    rr++;
                }

                ws2.View.FreezePanes(4, 1);
                ws2.Cells[3, 1, rr - 1, 12].AutoFilter = true;
                ws2.Cells[3, 1, rr - 1, 12].AutoFitColumns(12, 55);

                int footer2 = rr + 1;
                ws2.Cells[footer2, 1, footer2, 12].Merge = true;
                ws2.Cells[footer2, 1].Value =
                    "ZAIN SYSTEM 2026 ©️ | All Rights Reserved to Mustafa Zain | هذا النظام بجميع ملكياته الفكرية وحقوقه القانونية تعود لـ مصطفى زين";
                ws2.Cells[footer2, 1].Style.Font.Size = 10;
                ws2.Cells[footer2, 1].Style.Font.Bold = true;
                ws2.Cells[footer2, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                ws2.Cells[footer2, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
                ws2.Cells[footer2, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(241, 245, 249));
                ws2.Row(footer2).Height = 22;

                pck.SaveAs(new FileInfo(path));
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء إنشاء كشف الحساب: " + ex.Message);
            }
        }

        // =========================================================
        // ✅ Assets Helpers (Fix img errors)
        // =========================================================
        private string FindAssetPath(params string[] fileNames)
        {
            try
            {
                // أهم مسار عندك من الصور: ProjectRoot\Assets\logo.png
                // وأيضاً: DbFolder\Assets\logo.png
                var candidates = new List<string>();

                // 1) DbFolder\Assets
                candidates.Add(Path.Combine(AppDbContext.DbFolder, "Assets"));

                // 2) مسار التشغيل + Assets
                var baseDir = AppDomain.CurrentDomain.BaseDirectory;
                candidates.Add(Path.Combine(baseDir, "Assets"));

                // 3) مسار المشروع (لو شغال Debug): ..\..\..\Assets
                candidates.Add(Path.GetFullPath(Path.Combine(baseDir, "..", "..", "..", "Assets")));

                foreach (var folder in candidates.Distinct())
                {
                    foreach (var f in fileNames)
                    {
                        var p = Path.Combine(folder, f);
                        if (File.Exists(p)) return p;
                    }
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        private void TryAddLogo(ExcelWorksheet ws)
        {
            try
            {
                // ✅ أهم تعديل: EPPlus عندك يقبل Path/FileInfo وليس System.Drawing.Image
                var logoPath = FindAssetPath("logo.png", "logo.jpg", "logo.jpeg");
                if (string.IsNullOrWhiteSpace(logoPath)) return;

                var pic = ws.Drawings.AddPicture($"Logo_{Guid.NewGuid():N}", new FileInfo(logoPath));

                // مكانه أعلى يمين (Sheet RTL)
                pic.SetPosition(0, 2, 11, 0);
                pic.SetSize(80, 80);
            }
            catch
            {
                // ignore
            }
        }

        private void TryAddStamp(ExcelWorksheet ws)
        {
            try
            {
                var stampPath = FindAssetPath("stamp.png", "stamp.jpg", "stamp.jpeg");
                if (string.IsNullOrWhiteSpace(stampPath)) return;

                var pic = ws.Drawings.AddPicture($"Stamp_{Guid.NewGuid():N}", new FileInfo(stampPath));

                // Watermark منتصف الصفحة تقريباً
                pic.SetPosition(6, 0, 4, 0);
                pic.SetSize(320, 320);
            }
            catch
            {
                // ignore
            }
        }
    }
}