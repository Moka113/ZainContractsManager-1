﻿#nullable enable
using System;
using System.Windows;
using System.Windows.Controls;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
// السطر السحري لتوحيد المسميات داخل هذه الصفحة
using Contract = ZainContractsManager.Models.LeaseContract;

namespace ZainContractsManager.Views
{
    public partial class AddContractWindow : Window
    {
        private Contract? _existingContract = null;
        private bool _isEditMode = false;

        // لمنع loop لو بنكتب في TxtVat/TxtTotal أثناء TextChanged
        private bool _isUpdatingTotals = false;

        public AddContractWindow()
        {
            InitializeComponent();

            DateStart.SelectedDate = DateTime.Now;
            DateEnd.SelectedDate = DateTime.Now.AddYears(1);

            // ✅ افتراضي: نحن مستأجر (الشركة تدفع)
            if (ComboDirection != null && ComboDirection.SelectedIndex < 0)
                ComboDirection.SelectedIndex = 0;

            // تأكيد قيمة افتراضية للضريبة
            if (ChkApplyVat != null && ChkApplyVat.IsChecked == null)
                ChkApplyVat.IsChecked = true;

            // حساب أولي
            RecalculateTotals();
        }

        // استخدام Alias هنا يمنع خطأ Argument 1: cannot convert
        public AddContractWindow(Contract contractToEdit) : this()
        {
            _existingContract = contractToEdit;
            _isEditMode = true;
            FillDataForEdit();
        }

        private void FillDataForEdit()
        {
            if (_existingContract == null) return;

            Title = "تعديل عقد: " + _existingContract.ContractNumber;

            TxtContractNo.Text = _existingContract.ContractNumber;
            TxtLessor.Text = _existingContract.LessorName;
            TxtTenant.Text = _existingContract.TenantName;
            TxtBranchName.Text = _existingContract.BranchName;

            DateStart.SelectedDate = _existingContract.StartDate;
            DateEnd.SelectedDate = _existingContract.EndDate;

            TxtAmount.Text = _existingContract.AmountBeforeTax.ToString("F2");
            TxtAdditional.Text = _existingContract.AdditionalFixedAmounts.ToString("F2");

            // ✅ اتجاه العقد
            if (ComboDirection != null)
            {
                // CompanyPays = 0 (نحن مستأجر) / CompanyReceives = 1 (نحن مؤجر)
                ComboDirection.SelectedIndex = (int)_existingContract.Direction == 1 ? 1 : 0;
            }

            // ✅ الضريبة اختيارية: لو VatAmount == 0 غالبًا الضريبة غير مطبقة
            if (ChkApplyVat != null)
                ChkApplyVat.IsChecked = _existingContract.VatAmount > 0;

            TxtNotes.Text = _existingContract.Notes;
            TxtElectricity.Text = _existingContract.ElectricityAccountNumber;
            TxtWater.Text = _existingContract.WaterAccountNumber;

            TxtInstallmentsCount.Text = _existingContract.InstallmentsCount.ToString();
            ComboContractType.Text = _existingContract.ContractType;
            ComboFrequency.Text = _existingContract.PaymentFrequency;

            RecalculateTotals();
        }

        // ✅ Event جديد من الـ XAML
        private void VatOption_Changed(object sender, RoutedEventArgs e)
        {
            RecalculateTotals();
        }

        private void CalculateTotal_TextChanged(object sender, TextChangedEventArgs e)
        {
            RecalculateTotals();
        }

        private void RecalculateTotals()
        {
            if (_isUpdatingTotals) return;

            if (TxtAmount == null || TxtVat == null || TxtTotal == null || TxtAdditional == null)
                return;

            try
            {
                _isUpdatingTotals = true;

                decimal.TryParse(TxtAmount.Text, out decimal baseAmount);
                decimal.TryParse(TxtAdditional.Text, out decimal additional);

                bool applyVat = ChkApplyVat?.IsChecked == true;

                decimal vat = applyVat ? baseAmount * 0.15m : 0m;
                decimal total = baseAmount + vat + additional;

                TxtVat.Text = vat.ToString("F2");
                TxtTotal.Text = total.ToString("F2");
            }
            finally
            {
                _isUpdatingTotals = false;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // ✅ Validations بسيطة
                if (string.IsNullOrWhiteSpace(TxtContractNo.Text))
                {
                    MessageBox.Show("يرجى إدخال رقم العقد.");
                    return;
                }

                if (ComboDirection == null || ComboDirection.SelectedIndex < 0)
                {
                    MessageBox.Show("يرجى تحديد دور شركتك في العقد (نحن مستأجر / نحن مؤجر).");
                    return;
                }

                using var db = new AppDbContext();

                // ✅ أهم سطر: لازم يكون عندنا شركة مختارة
                var companyId = db.CurrentCompanyId;
                if (companyId <= 0)
                {
                    MessageBox.Show("لا يمكن حفظ العقد قبل اختيار الشركة (CurrentCompanyId غير محدد).");
                    return;
                }

                if (_isEditMode && _existingContract != null)
                {
                    var contract = db.Contracts.FirstOrDefault(x => x.Id == _existingContract.Id);
                    if (contract == null)
                    {
                        MessageBox.Show("لم يتم العثور على العقد للتعديل.");
                        return;
                    }

                    // ✅ حماية: ممنوع تعديل عقد لشركة أخرى
                    if (contract.CompanyId != companyId)
                    {
                        MessageBox.Show("لا يمكن تعديل عقد لا ينتمي للشركة الحالية.");
                        return;
                    }

                    UpdateContractData(contract, companyId);
                    db.Entry(contract).State = EntityState.Modified;
                }
                else
                {
                    var newContract = new Contract();
                    UpdateContractData(newContract, companyId);

                    // ✅ أهم سطر: تعيين CompanyId قبل الإضافة
                    newContract.CompanyId = companyId;

                    db.Contracts.Add(newContract);
                }

                db.SaveChanges();

                DialogResult = true;
                Close();
            }
            catch (DbUpdateException dbEx)
            {
                // غالباً Unique per Company على ContractNumber
                MessageBox.Show("تعذر الحفظ (قد يكون رقم العقد مكرر داخل نفس الشركة).\n\n" + dbEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("خطأ أثناء الحفظ: " + ex.Message);
            }
        }

        private void UpdateContractData(Contract contract, int companyId)
        {
            // ✅ تأكيد الـ CompanyId حتى في التعديل (مفيد لو كان قديم = 0)
            contract.CompanyId = companyId;

            contract.ContractNumber = TxtContractNo.Text.Trim();
            contract.TenantName = (TxtTenant.Text ?? "").Trim();
            contract.LessorName = (TxtLessor.Text ?? "").Trim();
            contract.BranchName = (TxtBranchName.Text ?? "").Trim();

            contract.ContractType = ComboContractType?.Text;

            contract.StartDate = DateStart.SelectedDate ?? DateTime.Now;
            contract.EndDate = DateEnd.SelectedDate ?? DateTime.Now.AddYears(1);

            // ✅ اتجاه العقد من ComboDirection
            // index 0 = نحن مستأجر (CompanyPays), index 1 = نحن مؤجر (CompanyReceives)
            contract.Direction = (ComboDirection?.SelectedIndex == 1)
                ? ContractDirection.CompanyReceives
                : ContractDirection.CompanyPays;

            decimal.TryParse(TxtAmount.Text, out decimal amt);
            contract.AmountBeforeTax = amt;

            decimal.TryParse(TxtAdditional.Text, out decimal addAmt);
            contract.AdditionalFixedAmounts = addAmt;

            // ✅ الضريبة اختيارية
            bool applyVat = ChkApplyVat?.IsChecked == true;
            contract.VatAmount = applyVat ? (amt * 0.15m) : 0m;

            contract.Notes = TxtNotes.Text;
            contract.ElectricityAccountNumber = TxtElectricity.Text;
            contract.WaterAccountNumber = TxtWater.Text;

            int.TryParse(TxtInstallmentsCount.Text, out int instCount);
            contract.InstallmentsCount = instCount;

            contract.PaymentFrequency = ComboFrequency?.Text;
            contract.LastModifiedDate = DateTime.Now;
            contract.Status = "Active";
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}