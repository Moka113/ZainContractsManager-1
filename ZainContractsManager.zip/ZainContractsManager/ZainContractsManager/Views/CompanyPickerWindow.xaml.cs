﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Views
{
    public partial class CompanyPickerWindow : Window
    {
        private readonly int _userId;

        public int SelectedCompanyId { get; private set; } = 0;

        public CompanyPickerWindow(int userId)
        {
            InitializeComponent();
            _userId = userId;

            Loaded += CompanyPickerWindow_Loaded;
        }

        private async void CompanyPickerWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Loaded -= CompanyPickerWindow_Loaded;
            await LoadCompaniesAsync();
            UpdateOkButton();
        }

        // ===================== Events =====================
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                e.Handled = true;
                Cancel_Click(this, new RoutedEventArgs());
                return;
            }

            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                if (OkBtn != null && OkBtn.IsEnabled)
                    Ok_Click(this, new RoutedEventArgs());
                return;
            }
        }

        private void CompaniesList_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            HideError();
            UpdateOkButton();
        }

        private void CompaniesList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (OkBtn != null && OkBtn.IsEnabled)
                Ok_Click(this, new RoutedEventArgs());
        }

        private void UpdateOkButton()
        {
            try
            {
                if (OkBtn == null) return;
                OkBtn.IsEnabled = CompaniesList.SelectedItem is Company;
            }
            catch { }
        }

        // ===================== Load Companies =====================
        private async Task LoadCompaniesAsync()
        {
            try
            {
                HideError();

                using var db = new AppDbContext();
                db.InitializeDatabase();

                // ✅ مهم جداً: IgnoreQueryFilters حتى لو كان في فلتر بالخطأ
                var companies = await db.CompanyUsers
                    .AsNoTracking()
                    .IgnoreQueryFilters()
                    .Where(cu => cu.UserId == _userId && cu.IsActive)
                    .Join(db.Companies.AsNoTracking().IgnoreQueryFilters(),
                          cu => cu.CompanyId,
                          c => c.Id,
                          (cu, c) => c)
                    .OrderBy(c => c.Name)
                    .ToListAsync();

                CompaniesList.ItemsSource = companies;

                if (CompaniesList.Items.Count > 0)
                    CompaniesList.SelectedIndex = 0;
                else
                    ShowError("لا توجد شركات مرتبطة بهذا المستخدم.");
            }
            catch (Exception ex)
            {
                ShowError("تعذر تحميل الشركات: " + Flatten(ex));
            }
        }

        // ===================== Create Company =====================
        private async void CreateCompany_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HideError();

                var name = (NewCompanyNameTxt.Text ?? "").Trim();
                if (string.IsNullOrWhiteSpace(name))
                {
                    ShowError("اكتب اسم الشركة أولاً.");
                    NewCompanyNameTxt.Focus();
                    return;
                }

                using var db = new AppDbContext();
                db.InitializeDatabase();

                // ✅ منع تكرار اسم الشركة
                var existsByName = await db.Companies.AsNoTracking().IgnoreQueryFilters()
                    .AnyAsync(c => (c.Name ?? "").Trim().ToLower() == name.ToLower());

                if (existsByName)
                {
                    ShowError("اسم الشركة موجود بالفعل. اختر اسمًا مختلفًا.");
                    NewCompanyNameTxt.Focus();
                    return;
                }

                // ✅ Generate unique code
                string code;
                do
                {
                    code = ("COMP-" + Guid.NewGuid().ToString("N")[..8]).ToUpperInvariant();
                }
                while (await db.Companies.AsNoTracking().IgnoreQueryFilters().AnyAsync(c => c.Code == code));

                using var tx = await db.Database.BeginTransactionAsync();

                var newCompany = new Company
                {
                    Name = name,
                    Code = code,
                    Country = "SA",
                    City = "—",
                    CreatedAt = DateTime.UtcNow
                };

                db.Companies.Add(newCompany);
                await db.SaveChangesAsync();

                db.CompanyUsers.Add(new CompanyUser
                {
                    CompanyId = newCompany.Id,
                    UserId = _userId,
                    Role = "Owner",
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                });

                await db.SaveChangesAsync();
                await tx.CommitAsync();

                await LoadCompaniesAsync();
                SelectCompanyInList(newCompany.Id);

                NewCompanyNameTxt.Text = "";
                UpdateOkButton();
            }
            catch (Exception ex)
            {
                ShowError("تعذر إنشاء الشركة: " + Flatten(ex));
            }
        }

        private void SelectCompanyInList(int companyId)
        {
            try
            {
                if (CompaniesList.ItemsSource is not IEnumerable<Company> items) return;

                var list = items.ToList();
                var idx = list.FindIndex(c => c.Id == companyId);
                if (idx >= 0)
                    CompaniesList.SelectedIndex = idx;
            }
            catch { }
        }

        // ===================== OK / Cancel =====================
        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            HideError();

            if (CompaniesList.SelectedItem is not Company selected)
            {
                ShowError("من فضلك اختر شركة.");
                UpdateOkButton();
                return;
            }

            SelectedCompanyId = selected.Id;

            try
            {
                Application.Current.Properties["CurrentCompanyId"] = SelectedCompanyId;
            }
            catch { }

            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            SelectedCompanyId = 0;

            try
            {
                Application.Current.Properties["CurrentCompanyId"] = 0;
            }
            catch { }

            DialogResult = false;
            Close();
        }

        // ===================== Helpers =====================
        private void ShowError(string msg)
        {
            ErrorTxt.Text = msg;
            ErrorTxt.Visibility = Visibility.Visible;
        }

        private void HideError()
        {
            ErrorTxt.Text = "";
            ErrorTxt.Visibility = Visibility.Collapsed;
        }

        private static string Flatten(Exception ex)
        {
            var parts = new List<string>();
            var cur = ex;
            while (cur != null)
            {
                if (!string.IsNullOrWhiteSpace(cur.Message))
                    parts.Add(cur.Message);
                cur = cur.InnerException;
            }
            return string.Join(" | ", parts);
        }
    }
}