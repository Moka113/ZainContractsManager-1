﻿using ClosedXML.Excel;
using Microsoft.Win32;
using System;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace ZainContractsManager.Services
{
    public class FileService
    {
        public string ExportToExcel(DataTable dataTable, string reportTitle)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "Excel Files|*.xlsx",
                FileName = $"{reportTitle}_{DateTime.Now:yyyyMMdd_HHmm}"
            };

            if (dlg.ShowDialog() != true) return "";

            using (var workbook = new XLWorkbook())
            {
                var ws = workbook.Worksheets.Add("التقرير");
                var table = ws.Cell(1, 1).InsertTable(dataTable);

                table.Theme = XLTableTheme.TableStyleMedium9;
                ws.Columns().AdjustToContents();
                ws.RightToLeft = true;

                // Header style
                ws.Row(1).Style.Font.Bold = true;

                // Freeze top row
                ws.SheetView.FreezeRows(1);

                workbook.SaveAs(dlg.FileName);
            }

            return dlg.FileName;
        }

        public string ExportToCsv(DataTable dataTable, string reportTitle)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "CSV Files|*.csv",
                FileName = $"{reportTitle}_{DateTime.Now:yyyyMMdd_HHmm}"
            };

            if (dlg.ShowDialog() != true) return "";

            var sb = new StringBuilder();

            // Header
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                if (i > 0) sb.Append(",");
                sb.Append(EscapeCsv(dataTable.Columns[i].ColumnName));
            }
            sb.AppendLine();

            // Rows
            foreach (DataRow row in dataTable.Rows)
            {
                for (int i = 0; i < dataTable.Columns.Count; i++)
                {
                    if (i > 0) sb.Append(",");
                    sb.Append(EscapeCsv(Convert.ToString(row[i]) ?? ""));
                }
                sb.AppendLine();
            }

            File.WriteAllText(dlg.FileName, sb.ToString(), Encoding.UTF8);
            return dlg.FileName;
        }

        public void OpenFileIfExists(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            if (!File.Exists(path)) return;

            try
            {
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch { }
        }

        private static string EscapeCsv(string input)
        {
            if (input.Contains("\"")) input = input.Replace("\"", "\"\"");
            if (input.Contains(",") || input.Contains("\n") || input.Contains("\r"))
                input = $"\"{input}\"";
            return input;
        }
    }
}