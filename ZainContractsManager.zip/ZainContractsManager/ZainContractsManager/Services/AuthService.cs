﻿#nullable enable
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Windows; // Application.Current.Properties
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using ZainContractsManager.Models.SaaS;

namespace ZainContractsManager.Services
{
    public class AuthService
    {
        // آخر سبب فشل (علشان تعرضه في الواجهة)
        public string LastError { get; private set; } = "";

        private static string Normalize(string? s) => (s ?? "").Trim();

        /// <summary>
        /// يسجل الدخول + يضبط CurrentCompanyId داخل Application.Current.Properties
        /// </summary>
        public bool ValidateLogin(string username, string password)
        {
            LastError = "";

            username = Normalize(username);
            password = password ?? "";

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                LastError = "اسم المستخدم أو كلمة المرور فارغة.";
                return false;
            }

            try
            {
                using var db = new AppDbContext();

                var user = db.Users
                    .AsNoTracking()
                    .FirstOrDefault(x => x.Username == username);

                if (user == null)
                {
                    LastError = "المستخدم غير موجود.";
                    return false;
                }

                // مؤقتًا Plain Text (بعدها نعمل Hash)
                if (!string.Equals(user.Password ?? "", password, StringComparison.Ordinal))
                {
                    LastError = "كلمة المرور غير صحيحة.";
                    return false;
                }

                // ✅ SaaS: اختار أول شركة Active للمستخدم
                var cu = db.CompanyUsers
                    .AsNoTracking()
                    .Where(x => x.UserId == user.Id && x.IsActive)
                    .OrderByDescending(x => x.Role == "Owner" || x.Role == "Admin")
                    .FirstOrDefault();

                if (cu == null)
                {
                    LastError = "هذا المستخدم غير مرتبط بأي شركة. أنشئ/اربط شركة أولاً.";
                    return false;
                }

                // ✅ أهم خطوة: ضبط CurrentCompanyId في App.Properties
                TrySetCurrentCompanyId(cu.CompanyId);

                return true;
            }
            catch (Exception ex)
            {
                LastError = "خطأ أثناء تسجيل الدخول: " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// إنشاء مستخدم + (إن لم توجد شركة) إنشاء شركة افتراضية + ربط المستخدم بها Owner
        /// </summary>
        public bool CreateUser(string username, string password)
        {
            LastError = "";

            username = Normalize(username);
            password = password ?? "";

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                LastError = "اسم المستخدم أو كلمة المرور فارغة.";
                return false;
            }

            try
            {
                using var db = new AppDbContext();

                var exists = db.Users.Any(x => x.Username == username);
                if (exists)
                {
                    LastError = "اسم المستخدم موجود مسبقًا.";
                    return false;
                }

                var user = new User
                {
                    Username = username,
                    Password = password,

                    // مهم عشان NOT NULL
                    Role = "User",
                    CanEditContracts = true,
                    CanViewFinancials = true,
                    CanExportExcel = true
                };

                db.Users.Add(user);
                db.SaveChanges();

                // ✅ لو مفيش شركات لسه: اعمل شركة افتراضية
                var company = db.Companies.OrderBy(c => c.Id).FirstOrDefault();
                if (company == null)
                {
                    company = new Company
                    {
                        Name = "Default Company"
                    };
                    db.Companies.Add(company);
                    db.SaveChanges();
                }

                // ✅ ربط المستخدم بالشركة (Owner)
                var linkExists = db.CompanyUsers.Any(x => x.CompanyId == company.Id && x.UserId == user.Id);
                if (!linkExists)
                {
                    db.CompanyUsers.Add(new CompanyUser
                    {
                        CompanyId = company.Id,
                        UserId = user.Id,
                        Role = "Owner",
                        IsActive = true
                    });
                    db.SaveChanges();
                }

                // ✅ اختياري: خلي الشركة الحالية = الشركة دي
                TrySetCurrentCompanyId(company.Id);

                return true;
            }
            catch (DbUpdateException dbEx)
            {
                LastError = "فشل حفظ المستخدم في قاعدة البيانات: " + (dbEx.InnerException?.Message ?? dbEx.Message);
                return false;
            }
            catch (Exception ex)
            {
                LastError = "خطأ أثناء إنشاء المستخدم: " + ex.Message;
                return false;
            }
        }

        private static void TrySetCurrentCompanyId(int companyId)
        {
            try
            {
                if (Application.Current != null)
                    Application.Current.Properties["CurrentCompanyId"] = companyId;
            }
            catch
            {
                // ignore
            }
        }
    }
}