﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models.Finance;

namespace ZainContractsManager.Services.FinanceEngine
{
    public static class FinanceSeeder
    {
        /// <summary>
        /// ✅ Seed chart of accounts per company (Multi-tenant)
        /// - Safe: does nothing if already seeded.
        /// - Atomic: wrapped in a transaction.
        /// </summary>
        public static void Seed(AppDbContext db, int companyId)
        {
            if (db == null) throw new ArgumentNullException(nameof(db));
            if (companyId <= 0)
                throw new InvalidOperationException("FinanceSeeder: companyId غير صحيح.");

            // ✅ Strong guard: if root exists, assume this company already seeded
            // (prevents partial-seed issues from blocking full re-run)
            if (db.Accounts.AsNoTracking().Any(a => a.CompanyId == companyId && a.Code == "1000"))
                return;

            using var tx = db.Database.BeginTransaction();

            try
            {
                // ===============================
                // ROOT ACCOUNTS (Level 1)
                // ===============================
                var assets = New(companyId, "1000", "الأصول", AccountType.Asset);
                var liabilities = New(companyId, "2000", "الالتزامات", AccountType.Liability);
                var equity = New(companyId, "3000", "حقوق الملكية", AccountType.Equity);
                var revenue = New(companyId, "4000", "الإيرادات", AccountType.Revenue);
                var expense = New(companyId, "5000", "المصروفات", AccountType.Expense);

                db.Accounts.AddRange(assets, liabilities, equity, revenue, expense);
                db.SaveChanges(); // generate Ids

                // ===============================
                // Level 2 - Assets
                // ===============================
                var cash = New(companyId, "1100", "الصندوق", AccountType.Asset, assets.Id);
                var bank = New(companyId, "1200", "البنوك", AccountType.Asset, assets.Id);
                var ar = New(companyId, "1300", "الذمم المدينة (مستحقات العملاء)", AccountType.Asset, assets.Id);

                // Level 3 - Bank details
                var bankCurrent = New(companyId, "1210", "بنك - حساب جاري", AccountType.Asset, bank.Id);
                var bankTransfer = New(companyId, "1220", "بنك - تحويلات", AccountType.Asset, bank.Id);

                // ===============================
                // Level 2 - Liabilities
                // ===============================
                var ap = New(companyId, "2100", "الذمم الدائنة (مستحقات الموردين/المؤجرين)", AccountType.Liability, liabilities.Id);
                var vatPayable = New(companyId, "2200", "ضريبة القيمة المضافة (مستحقة)", AccountType.Liability, liabilities.Id);

                // ===============================
                // Level 2 - Equity
                // ===============================
                var capital = New(companyId, "3100", "رأس المال", AccountType.Equity, equity.Id);
                var retained = New(companyId, "3200", "الأرباح المحتجزة", AccountType.Equity, equity.Id);

                // ===============================
                // Level 2 - Revenue
                // ===============================
                var rentRevenue = New(companyId, "4100", "إيرادات الإيجار", AccountType.Revenue, revenue.Id);

                // ===============================
                // Level 2 - Expense
                // ===============================
                var operating = New(companyId, "5100", "مصروفات تشغيل", AccountType.Expense, expense.Id);

                // Details under operating
                var opDetails = new List<Account>
                {
                    New(companyId, "5110", "كهرباء", AccountType.Expense, operating.Id),
                    New(companyId, "5120", "مياه", AccountType.Expense, operating.Id),
                    New(companyId, "5130", "صيانة", AccountType.Expense, operating.Id),
                    New(companyId, "5140", "نظافة", AccountType.Expense, operating.Id),
                    New(companyId, "5150", "مكافحة حشرات", AccountType.Expense, operating.Id),
                    New(companyId, "5160", "سعي/عمولة", AccountType.Expense, operating.Id),
                };

                // ✅ IMPORTANT: 5300 (محرك)
                var engineExpense = New(companyId, "5300", "مصروفات عامة (محرك)", AccountType.Expense, expense.Id);

                // ===============================
                // Add everything
                // ===============================
                db.Accounts.AddRange(
                    cash, bank, ar,
                    bankCurrent, bankTransfer,
                    ap, vatPayable,
                    capital, retained,
                    rentRevenue,
                    operating,
                    engineExpense
                );

                db.Accounts.AddRange(opDetails);

                db.SaveChanges();
                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        private static Account New(int companyId, string code, string name, AccountType type, int? parentId = null)
        {
            return new Account
            {
                CompanyId = companyId,
                Code = code,
                Name = name,
                Type = type,
                ParentId = parentId,
                IsActive = true,
                CreatedAt = DateTime.UtcNow
            };
        }
    }
}