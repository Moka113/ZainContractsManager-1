﻿#nullable enable
using System;
using System.Linq;
using ZainContractsManager.Data;
using ZainContractsManager.Models.Finance;

namespace ZainContractsManager.Services.FinanceEngine
{
    public static class FinanceSeedService
    {
        /// <summary>
        /// ينشئ شجرة حسابات أساسية ERP جاهزة.
        /// لو الحساب موجود (بنفس Code) لن يتم تكراره.
        /// </summary>
        public static void SeedDefaultChartOfAccounts(AppDbContext db)
        {
            if (db == null) throw new ArgumentNullException(nameof(db));

            // Helper
            Account Ensure(string code, string name, AccountType type, string? parentCode = null)
            {
                var existing = db.Accounts.FirstOrDefault(a => a.Code == code);
                if (existing != null) return existing;

                Account? parent = null;
                if (!string.IsNullOrWhiteSpace(parentCode))
                    parent = db.Accounts.FirstOrDefault(a => a.Code == parentCode);

                var acc = new Account
                {
                    Code = code,
                    Name = name,
                    Type = type,
                    ParentId = parent?.Id,
                    Parent = parent,
                    IsActive = true,
                    CreatedAt = DateTime.Now
                };

                db.Accounts.Add(acc);
                db.SaveChanges();
                return acc;
            }

            // =========================
            // Assets (1000)
            // =========================
            Ensure("1000", "الأصول", AccountType.Asset);

            Ensure("1100", "الصندوق", AccountType.Asset, "1000");
            Ensure("1200", "البنك", AccountType.Asset, "1000");

            Ensure("1300", "العملاء / ذمم مدينة", AccountType.Asset, "1000");
            Ensure("1400", "الموردون (ذمم مدينة/سلف) - اختياري", AccountType.Asset, "1000");

            Ensure("1500", "مصروفات مقدمة", AccountType.Asset, "1000");
            Ensure("1600", "أصول ثابتة", AccountType.Asset, "1000");

            // =========================
            // Liabilities (2000)
            // =========================
            Ensure("2000", "الالتزامات", AccountType.Liability);

            Ensure("2100", "الموردون / ذمم دائنة", AccountType.Liability, "2000");
            Ensure("2200", "ضريبة القيمة المضافة مستحقة (VAT Payable)", AccountType.Liability, "2000");
            Ensure("2300", "إيرادات مؤجلة", AccountType.Liability, "2000");

            // =========================
            // Equity (3000)
            // =========================
            Ensure("3000", "حقوق الملكية", AccountType.Equity);

            Ensure("3100", "رأس المال", AccountType.Equity, "3000");
            Ensure("3200", "الأرباح المحتجزة", AccountType.Equity, "3000");

            // =========================
            // Revenue (4000)
            // =========================
            Ensure("4000", "الإيرادات", AccountType.Revenue);

            // عندك في المحرك المالي: 4100 إيجارات
            Ensure("4100", "إيرادات الإيجار", AccountType.Revenue, "4000");
            Ensure("4200", "إيرادات أخرى", AccountType.Revenue, "4000");

            // =========================
            // Expenses (5000)
            // =========================
            Ensure("5000", "المصروفات", AccountType.Expense);

            // عندك: 5100 تشغيل
            Ensure("5100", "مصروفات تشغيل عامة", AccountType.Expense, "5000");

            // Mapping الموجود في FinancialEngineService
            Ensure("5110", "مصروف إيجار", AccountType.Expense, "5000");

            Ensure("5200", "مصروفات كهرباء", AccountType.Expense, "5000");
            Ensure("5300", "مصروفات مياه", AccountType.Expense, "5000");
            Ensure("5400", "مصروفات صيانة", AccountType.Expense, "5000");

            db.SaveChanges();
        }
    }
}