﻿#nullable enable
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using ZainContractsManager.Models.Finance;

// ✅ FIX: استخدم enum بتاع الـ Models فقط لتجنب أي تعارض
using ModelPaymentDirection = ZainContractsManager.Models.PaymentDirection;

namespace ZainContractsManager.Services.FinanceEngine
{
    public static class PostingService
    {
        // أكواد حسابات أساسية (ابسط أساس قوي)
        private const string CASH_CODE = "1100";         // Cash/Bank
        private const string RENT_REV_CODE = "4100";     // Rent Revenue
        private const string RENT_EXP_CODE = "5100";     // Rent Expense

        public static int PostPayment(AppDbContext db, int paymentId)
        {
            if (db == null) throw new ArgumentNullException(nameof(db));

            var companyId = db.CurrentCompanyId;
            if (companyId <= 0)
                throw new InvalidOperationException("CurrentCompanyId غير محدد قبل الترحيل.");

            // ✅ Transaction: أي فشل = Rollback
            using var tx = db.Database.BeginTransaction();

            // ✅ نجيب Payment Tracking عشان نقدر نعدل عليه
            var p = db.Payments
                .Include(x => x.Contract)
                .FirstOrDefault(x => x.Id == paymentId);

            if (p == null) throw new Exception("Payment غير موجود.");

            // ✅ حتى لو عندك GlobalQueryFilter، نخليها حماية إضافية
            if (p.CompanyId != companyId)
                throw new Exception("Payment لا ينتمي للشركة الحالية.");

            // ✅ لازم تكون مدفوعة قبل الترحيل
            if (!p.IsPaid)
                throw new Exception("لا يمكن ترحيل دفعة غير مسددة. فعّل IsPaid أولاً.");

            // ✅ مبلغ صحيح
            if (p.Amount <= 0)
                throw new Exception("لا يمكن ترحيل دفعة بمبلغ 0 أو أقل.");

            // ✅ تثبيت PaidAt لو مفقود
            if (p.PaidAt == null)
                p.PaidAt = DateTime.Now;

            // ✅ منع تكرار الترحيل (1) لو Payment مربوط بالفعل
            if (p.JournalEntryId.HasValue && p.JournalEntryId.Value > 0)
            {
                tx.Commit();
                return p.JournalEntryId.Value;
            }

            // ✅ منع تكرار الترحيل (2) حتى لو JournalEntryId مش متسجل لسبب ما
            var existing = db.JournalEntries
                .AsNoTracking()
                .Where(e => e.CompanyId == companyId && e.SourceType == "Payment" && e.SourceId == p.Id)
                .OrderByDescending(e => e.Id)
                .Select(e => e.Id)
                .FirstOrDefault();

            if (existing > 0)
            {
                // اربطها رجوعًا للدفع لتثبيت الحالة
                p.JournalEntryId = existing;
                p.PostedAt = p.PostedAt ?? DateTime.Now;
                p.IsPostedToJournal = true;

                db.SaveChanges();
                tx.Commit();
                return existing;
            }

            // 1) Ensure accounts exist
            var cash = EnsureAccount(db, companyId, CASH_CODE, "Cash / Bank", AccountType.Asset);
            var rentRev = EnsureAccount(db, companyId, RENT_REV_CODE, "Rent Revenue", AccountType.Revenue);
            var rentExp = EnsureAccount(db, companyId, RENT_EXP_CODE, "Rent Expense", AccountType.Expense);

            // 2) Build entry
            var entryNo = JournalEntryNumberService.Next(db, companyId);

            var dir = FixPaymentDir(p);

            var je = new JournalEntry
            {
                CompanyId = companyId,
                EntryNo = entryNo,
                EntryDate = p.PaidAt.Value,
                Description =
                    dir == ModelPaymentDirection.Incoming
                        ? $"Incoming Payment #{p.Id} (ContractId={p.ContractId})"
                        : $"Outgoing Payment #{p.Id} (ContractId={p.ContractId})",
                Status = JournalStatus.Posted,
                SourceType = "Payment",
                SourceId = p.Id,
                CreatedAt = DateTime.Now
            };

            // Incoming: Dr Cash, Cr Rent Revenue
            // Outgoing: Dr Rent Expense, Cr Cash
            if (dir == ModelPaymentDirection.Incoming)
            {
                je.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = cash.Id,
                    Debit = p.Amount,
                    Credit = 0m,
                    Notes = "Incoming payment"
                });

                je.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = rentRev.Id,
                    Debit = 0m,
                    Credit = p.Amount,
                    Notes = "Rent revenue"
                });
            }
            else
            {
                je.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = rentExp.Id,
                    Debit = p.Amount,
                    Credit = 0m,
                    Notes = "Outgoing payment"
                });

                je.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = cash.Id,
                    Debit = 0m,
                    Credit = p.Amount,
                    Notes = "Cash/Bank"
                });
            }

            ValidateBalanced(je);

            db.JournalEntries.Add(je);
            db.SaveChanges(); // يولّد je.Id

            // 3) Link back to payment
            p.JournalEntryId = je.Id;
            p.PostedAt = DateTime.Now;
            p.IsPostedToJournal = true;

            db.SaveChanges();

            tx.Commit();
            return je.Id;
        }

        private static ModelPaymentDirection FixPaymentDir(Payment p)
        {
            // ✅ حماية للبيانات القديمة (Direction=0)
            if ((int)p.Direction == 0) return ModelPaymentDirection.Incoming;
            return p.Direction;
        }

        private static void ValidateBalanced(JournalEntry je)
        {
            var debit = je.Lines.Sum(x => x.Debit);
            var credit = je.Lines.Sum(x => x.Credit);

            // ✅ tolerance (عشان الكسور)
            if (Math.Abs(debit - credit) > 0.0001m)
                throw new Exception($"القيد غير متوازن. Debit={debit} Credit={credit}");
        }

        private static Account EnsureAccount(AppDbContext db, int companyId, string code, string name, AccountType type)
        {
            var acc = db.Accounts.FirstOrDefault(a => a.CompanyId == companyId && a.Code == code);
            if (acc != null) return acc;

            acc = new Account
            {
                CompanyId = companyId,
                Code = code,
                Name = name,
                Type = type,
                IsActive = true,
                CreatedAt = DateTime.Now
            };

            db.Accounts.Add(acc);
            db.SaveChanges();
            return acc;
        }
    }
}