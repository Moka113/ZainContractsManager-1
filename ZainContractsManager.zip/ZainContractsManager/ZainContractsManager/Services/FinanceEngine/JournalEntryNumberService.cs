﻿#nullable enable
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;

namespace ZainContractsManager.Services.FinanceEngine
{
    public static class JournalEntryNumberService
    {
        // الصيغة: JV-2026-000001
        public static string Next(AppDbContext db, int companyId)
        {
            if (companyId <= 0)
                throw new InvalidOperationException("CompanyId غير صحيح أثناء توليد رقم القيد.");

            var year = DateTime.Now.Year;
            var prefix = $"JV-{year}-";

            // مهم: AsNoTracking لتقليل الحمل
            var lastEntryNo = db.JournalEntries
                .AsNoTracking()
                .Where(x =>
                    x.CompanyId == companyId &&
                    x.EntryNo != null &&
                    EF.Functions.Like(x.EntryNo, prefix + "%"))
                .OrderByDescending(x => x.Id)
                .Select(x => x.EntryNo)
                .FirstOrDefault();

            int nextNo = 1;

            if (!string.IsNullOrWhiteSpace(lastEntryNo))
            {
                var tail = lastEntryNo.Substring(prefix.Length);

                if (int.TryParse(tail, out var n))
                    nextNo = n + 1;
            }

            return prefix + nextNo.ToString("000000");
        }
    }
}