﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using ZainContractsManager.Models.Finance;

// ✅ Use ONLY the Model enum to avoid ambiguity
using ModelPaymentDirection = ZainContractsManager.Models.PaymentDirection;

namespace ZainContractsManager.Services.FinanceEngine
{
    public class FinancialEngineService
    {
        private readonly AppDbContext _db;

        public FinancialEngineService(AppDbContext db)
        {
            _db = db;
        }

        // ========================= Company / Tenant =========================

        private int RequireCompanyId()
        {
            var cid = _db.CurrentCompanyId;
            if (cid <= 0)
                throw new InvalidOperationException("FinancialEngineService: CurrentCompanyId غير محدد. لازم تختار شركة قبل الترحيل.");
            return cid;
        }

        // ========================= Accounts (Auto Ensure + Tenant Safe) =========================

        /// <summary>
        /// ✅ يضمن وجود الحساب للشركة الحالية + يفعّله لو كان غير نشط.
        /// لو غير موجود: ينشئه بشكل آمن.
        /// </summary>
        private Account EnsureAccountActiveByCode(
            int companyId,
            string code,
            string defaultName,
            AccountType defaultType)
        {
            code = (code ?? "").Trim();
            if (string.IsNullOrWhiteSpace(code))
                throw new InvalidOperationException("Account code فارغ.");

            // ✅ Include inactive + ignore query filters
            var acc = _db.Accounts
                .IgnoreQueryFilters()
                .FirstOrDefault(a => a.CompanyId == companyId && a.Code == code);

            if (acc == null)
            {
                acc = new Account
                {
                    CompanyId = companyId,
                    Code = code,
                    Name = string.IsNullOrWhiteSpace(defaultName) ? code : defaultName.Trim(),
                    Type = defaultType,
                    IsActive = true,
                    ParentId = null,
                    CreatedAt = DateTime.Now
                };

                _db.Accounts.Add(acc);

                try
                {
                    _db.SaveChanges();
                }
                catch
                {
                    // ✅ لو حصل تعارض Unique/Concurrency: أعد القراءة
                    acc = _db.Accounts
                        .IgnoreQueryFilters()
                        .FirstOrDefault(a => a.CompanyId == companyId && a.Code == code);

                    if (acc == null)
                        throw; // شيء غير متوقع فعلاً
                }
            }
            else
            {
                // ✅ activate if inactive
                bool changed = false;

                if (!acc.IsActive)
                {
                    acc.IsActive = true;
                    changed = true;
                }

                // ✅ لو الاسم فاضي/افتراضي جدًا، نحسنّه
                if (string.IsNullOrWhiteSpace(acc.Name) && !string.IsNullOrWhiteSpace(defaultName))
                {
                    acc.Name = defaultName.Trim();
                    changed = true;
                }

                // ✅ لو النوع غير مضبوط (اختياري) – نخليه الافتراضي لو كان 0 أو غير منطقي
                // (مش هنغير النوع لو موجود لتجنب كسر شجرة حسابات عندك)
                if (changed)
                    _db.SaveChanges();
            }

            return acc;
        }

        private Account EnsureCashAccount(int companyId)
            => EnsureAccountActiveByCode(companyId, "1100", "الصندوق (Cash)", AccountType.Asset);

        private Account EnsureBankAccount(int companyId)
            => EnsureAccountActiveByCode(companyId, "1200", "البنك (Bank)", AccountType.Asset);

        private Account EnsureRentRevenue(int companyId)
            => EnsureAccountActiveByCode(companyId, "4100", "إيرادات الإيجار", AccountType.Revenue);

        private Account EnsureOperatingExpenseUmbrella(int companyId)
            => EnsureAccountActiveByCode(companyId, "5100", "مصروفات تشغيل", AccountType.Expense);

        private Account EnsureGeneralExpenseUmbrella(int companyId)
            => EnsureAccountActiveByCode(companyId, "5300", "مصروفات عامة", AccountType.Expense);

        private Account EnsureExpenseByCodeOrFallback(
            int companyId,
            string primaryCode,
            string primaryName,
            string fallbackCode,
            string fallbackName)
        {
            // جرّب الأساسي (يتم إنشاؤه/تفعيله تلقائيًا)
            var primary = EnsureAccountActiveByCode(companyId, primaryCode, primaryName, AccountType.Expense);
            if (primary != null) return primary;

            // احتياط (نظريًا لن نصل هنا)
            return EnsureAccountActiveByCode(companyId, fallbackCode, fallbackName, AccountType.Expense);
        }

        private int ResolveCashOrBankAccountId(int companyId, string? paymentMethod)
        {
            var pm = (paymentMethod ?? "").Trim().ToLowerInvariant();

            // صندوق
            if (pm.Contains("cash") || pm.Contains("صندوق") || pm.Contains("كاش"))
                return EnsureCashAccount(companyId).Id;

            // بنك (افتراضي)
            return EnsureBankAccount(companyId).Id;
        }

        // ========================= Branch Helpers (Snapshot on JournalEntry) =========================

        private (int? branchId, string branchName) ResolveBranchFromPayment(int companyId, Payment payment)
        {
            if (payment.Contract != null)
            {
                var name = (payment.Contract.BranchName ?? "").Trim();
                return (payment.Contract.BranchId, name);
            }

            var contract = _db.Contracts.AsNoTracking()
                .FirstOrDefault(c => c.CompanyId == companyId && c.Id == payment.ContractId);

            if (contract == null)
                return (null, string.Empty);

            var branchName = (contract.BranchName ?? "").Trim();
            return (contract.BranchId, branchName);
        }

        private (int? branchId, string branchName) ResolveBranchFromExpense(FinancialExpense exp)
        {
            var name = (exp.BranchName ?? "").Trim();
            return (exp.BranchId, name);
        }

        // ========================= Journal Helpers =========================

        private string NextEntryNo(int companyId, DateTime date)
        {
            var day = date.Date;

            var todayCount = _db.JournalEntries.Count(e =>
                e.CompanyId == companyId &&
                e.EntryDate.Date == day);

            return $"JE-{day:yyyyMMdd}-{(todayCount + 1):0000}";
        }

        private bool ExistsJournal(int companyId, string sourceType, int sourceId)
        {
            return _db.JournalEntries.Any(e =>
                e.CompanyId == companyId &&
                e.SourceType == sourceType &&
                e.SourceId == sourceId);
        }

        private static void EnsureBalanced(JournalEntry entry)
        {
            var debit = entry.Lines.Sum(l => l.Debit);
            var credit = entry.Lines.Sum(l => l.Credit);

            if (Math.Abs(debit - credit) > 0.0001m)
                throw new InvalidOperationException($"القيد غير متوازن! مدين={debit} دائن={credit}");
        }

        private int Post(int companyId, JournalEntry entry)
        {
            entry.Lines ??= new List<JournalLine>();

            EnsureBalanced(entry);

            entry.CompanyId = companyId;
            entry.Status = JournalStatus.Posted;

            if (string.IsNullOrWhiteSpace(entry.EntryNo))
                entry.EntryNo = NextEntryNo(companyId, entry.EntryDate);

            foreach (var line in entry.Lines)
                line.CompanyId = companyId;

            _db.JournalEntries.Add(entry);
            _db.SaveChanges();

            return entry.Id;
        }

        // ========================= Payments =========================

        private static ModelPaymentDirection FixPaymentDir(Payment payment)
        {
            if ((int)payment.Direction == 0) return ModelPaymentDirection.Incoming;
            return payment.Direction;
        }

        public void PostPaymentIfPaid(Payment payment)
        {
            var companyId = RequireCompanyId();

            if (!payment.IsPaid) return;

            if (payment.CompanyId != companyId)
                throw new InvalidOperationException("لا يمكن ترحيل دفعة لا تتبع الشركة الحالية.");

            if (payment.IsPostedToJournal && payment.JournalEntryId.HasValue) return;
            if (ExistsJournal(companyId, "Payment", payment.Id)) return;

            if (payment.Amount <= 0) return;

            var paidAt = payment.PaidAt ?? DateTime.Now;
            var cashOrBankId = ResolveCashOrBankAccountId(companyId, payment.PaymentMethod);

            var (branchId, branchName) = ResolveBranchFromPayment(companyId, payment);

            // ✅ Ensure required accounts (auto-create/activate)
            var rentRevenue = EnsureRentRevenue(companyId);

            // ✅ Outgoing payments rent expense: 5300 then 5100 fallback
            // (هنا الاتنين بيتعملهم Ensure anyway)
            var rentExpensePrimary = EnsureGeneralExpenseUmbrella(companyId);
            var rentExpenseFallback = EnsureOperatingExpenseUmbrella(companyId);
            var rentExpense = rentExpensePrimary ?? rentExpenseFallback;

            var dir = FixPaymentDir(payment);

            var entry = new JournalEntry
            {
                CompanyId = companyId,
                BranchId = branchId,
                BranchName = branchName,
                EntryDate = paidAt,
                EntryNo = null,
                Description =
                    dir == ModelPaymentDirection.Incoming
                        ? $"تحصيل - عقد #{payment.ContractId} - Ref:{payment.ReferenceNo ?? "-"}"
                        : $"سداد إيجار - عقد #{payment.ContractId} - Ref:{payment.ReferenceNo ?? "-"}",
                SourceType = "Payment",
                SourceId = payment.Id,
                AuditLog = payment.AuditLog,
                CreatedAt = DateTime.Now,
                Lines = new List<JournalLine>()
            };

            if (dir == ModelPaymentDirection.Incoming)
            {
                entry.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = cashOrBankId,
                    Debit = payment.Amount,
                    Credit = 0m,
                    Notes = payment.Notes
                });

                entry.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = rentRevenue.Id,
                    Debit = 0m,
                    Credit = payment.Amount,
                    Notes = payment.Notes
                });
            }
            else
            {
                entry.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = rentExpense.Id,
                    Debit = payment.Amount,
                    Credit = 0m,
                    Notes = payment.Notes
                });

                entry.Lines.Add(new JournalLine
                {
                    CompanyId = companyId,
                    AccountId = cashOrBankId,
                    Debit = 0m,
                    Credit = payment.Amount,
                    Notes = payment.Notes
                });
            }

            var jeId = Post(companyId, entry);

            if (_db.Entry(payment).State == EntityState.Detached)
                _db.Payments.Attach(payment);

            payment.IsPostedToJournal = true;
            payment.JournalEntryId = jeId;
            payment.PostedAt = DateTime.Now;

            _db.SaveChanges();
        }

        // ========================= Expenses =========================

        private Account ResolveExpenseAccountByCategory(int companyId, FinancialExpense exp)
        {
            // ✅ Ensure umbrella accounts exist
            var umbrella5300 = EnsureGeneralExpenseUmbrella(companyId);
            var umbrella5100 = EnsureOperatingExpenseUmbrella(companyId);

            var cat = (exp.Category ?? "").Trim().ToLowerInvariant();

            if (cat.Contains("كهرباء") || cat.Contains("كهرب"))
                return EnsureAccountActiveByCode(companyId, "5110", "مصروفات كهرباء", AccountType.Expense);

            if (cat.Contains("مياه"))
                return EnsureAccountActiveByCode(companyId, "5120", "مصروفات مياه", AccountType.Expense);

            if (cat.Contains("صيانة"))
                return EnsureAccountActiveByCode(companyId, "5130", "مصروفات صيانة", AccountType.Expense);

            if (cat.Contains("نظافة"))
                return EnsureAccountActiveByCode(companyId, "5140", "مصروفات نظافة", AccountType.Expense);

            if (cat.Contains("حشرات") || cat.Contains("مكافحة"))
                return EnsureAccountActiveByCode(companyId, "5150", "مصروفات مكافحة حشرات", AccountType.Expense);

            if (cat.Contains("سعي") || cat.Contains("عمولة"))
                return EnsureAccountActiveByCode(companyId, "5160", "سعي/عمولة", AccountType.Expense);

            // Default umbrella
            return umbrella5300 ?? umbrella5100;
        }

        public void PostExpenseIfPaid(FinancialExpense exp)
        {
            var companyId = RequireCompanyId();

            if (!exp.IsPaid) return;

            if (exp.CompanyId != companyId)
                throw new InvalidOperationException("لا يمكن ترحيل مصروف لا يتبع الشركة الحالية.");

            if (exp.IsPostedToJournal && exp.JournalEntryId.HasValue) return;
            if (ExistsJournal(companyId, "Expense", exp.Id)) return;

            var total = exp.Amount + exp.TaxAmount;
            if (total <= 0) return;

            var paidAt = exp.PaidAt ?? DateTime.Now;
            var cashOrBankId = ResolveCashOrBankAccountId(companyId, exp.PaymentMethod);

            var (branchId, branchName) = ResolveBranchFromExpense(exp);

            var expenseAccount = ResolveExpenseAccountByCategory(companyId, exp);

            var entry = new JournalEntry
            {
                CompanyId = companyId,
                BranchId = branchId,
                BranchName = branchName,
                EntryDate = paidAt,
                EntryNo = null,
                Description = $"سداد مصروف ({exp.Category}) - رقم:{exp.ExpenseNumber ?? "-"} - Ref:{exp.ReferenceNo ?? "-"}",
                SourceType = "Expense",
                SourceId = exp.Id,
                CreatedAt = DateTime.Now,
                Lines = new List<JournalLine>()
            };

            entry.Lines.Add(new JournalLine
            {
                CompanyId = companyId,
                AccountId = expenseAccount.Id,
                Debit = total,
                Credit = 0m,
                Notes = exp.Description
            });

            entry.Lines.Add(new JournalLine
            {
                CompanyId = companyId,
                AccountId = cashOrBankId,
                Debit = 0m,
                Credit = total,
                Notes = exp.Description
            });

            var jeId = Post(companyId, entry);

            if (_db.Entry(exp).State == EntityState.Detached)
                _db.FinancialExpenses.Attach(exp);

            exp.IsPostedToJournal = true;
            exp.JournalEntryId = jeId;
            exp.PostedAt = DateTime.Now;

            _db.SaveChanges();
        }
    }
}