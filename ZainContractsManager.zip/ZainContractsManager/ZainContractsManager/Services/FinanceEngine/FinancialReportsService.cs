﻿#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;

namespace ZainContractsManager.Services.FinanceEngine
{
    public class FinancialReportsService
    {
        private readonly AppDbContext _db;

        public FinancialReportsService(AppDbContext db)
        {
            _db = db;
        }

        // =========================
        // DTOs
        // =========================
        public class TrialBalanceRow
        {
            public int AccountId { get; set; }
            public string Code { get; set; } = "";
            public string Name { get; set; } = "";

            public decimal Debit { get; set; }
            public decimal Credit { get; set; }

            public decimal Net => Debit - Credit;
        }

        public class LedgerLineRow
        {
            public DateTime EntryDate { get; set; }
            public string EntryNo { get; set; } = "";
            public string? Description { get; set; }
            public string? SourceType { get; set; }
            public int? SourceId { get; set; }

            public decimal Debit { get; set; }
            public decimal Credit { get; set; }
            public string? Notes { get; set; }
        }

        // =========================
        // Trial Balance (ميزان مراجعة)
        // =========================
        public List<TrialBalanceRow> GetTrialBalance(DateTime? from = null, DateTime? to = null)
        {
            var q = _db.JournalLines
                .AsNoTracking()
                .Include(l => l.Account)
                .Include(l => l.JournalEntry)
                .Where(l => l.JournalEntry != null && l.JournalEntry.Status == Models.Finance.JournalStatus.Posted);

            if (from.HasValue)
                q = q.Where(l => l.JournalEntry!.EntryDate.Date >= from.Value.Date);

            if (to.HasValue)
                q = q.Where(l => l.JournalEntry!.EntryDate.Date <= to.Value.Date);

            var rows = q
                .GroupBy(l => new { l.AccountId, Code = l.Account!.Code, Name = l.Account!.Name })
                .Select(g => new TrialBalanceRow
                {
                    AccountId = g.Key.AccountId,
                    Code = g.Key.Code,
                    Name = g.Key.Name,
                    Debit = g.Sum(x => x.Debit),
                    Credit = g.Sum(x => x.Credit)
                })
                .OrderBy(r => r.Code)
                .ToList();

            return rows;
        }

        // =========================
        // General Ledger (أستاذ عام لحساب واحد)
        // =========================
        public List<LedgerLineRow> GetGeneralLedger(int accountId, DateTime? from = null, DateTime? to = null)
        {
            var q = _db.JournalLines
                .AsNoTracking()
                .Include(l => l.JournalEntry)
                .Where(l => l.AccountId == accountId
                         && l.JournalEntry != null
                         && l.JournalEntry.Status == Models.Finance.JournalStatus.Posted);

            if (from.HasValue)
                q = q.Where(l => l.JournalEntry!.EntryDate.Date >= from.Value.Date);

            if (to.HasValue)
                q = q.Where(l => l.JournalEntry!.EntryDate.Date <= to.Value.Date);

            var lines = q
                .OrderBy(l => l.JournalEntry!.EntryDate)
                .ThenBy(l => l.Id)
                .Select(l => new LedgerLineRow
                {
                    EntryDate = l.JournalEntry!.EntryDate,
                    EntryNo = l.JournalEntry!.EntryNo,
                    Description = l.JournalEntry!.Description,
                    SourceType = l.JournalEntry!.SourceType,
                    SourceId = l.JournalEntry!.SourceId,
                    Debit = l.Debit,
                    Credit = l.Credit,
                    Notes = l.Notes
                })
                .ToList();

            return lines;
        }
    }
}