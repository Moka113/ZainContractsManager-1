﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ZainContractsManager.Services.Security
{
    public enum OtpVerifyResult { Ok, NotFound, Expired, WrongCode }

    public sealed class EmailOtpService
    {
        private readonly string _smtpUser;
        private readonly string _smtpPass;
        private readonly string _fromEmail;
        private readonly string _fromName;
        private readonly int _expiresMinutes;
        private readonly bool _enableSsl;

        // ✅ ممكن تخليهم ثوابت أو باراميتر
        private readonly string _smtpHost;
        private readonly int _smtpPort;

        private sealed class OtpEntry
        {
            public string Code { get; set; } = "";
            public DateTime ExpiresAt { get; set; }
        }

        private readonly ConcurrentDictionary<string, OtpEntry> _store = new();

        public EmailOtpService(
            string smtpUser,
            string smtpPass,
            string fromEmail,
            string fromName = "ZAIN SYSTEM",
            int expiresMinutes = 5,
            bool enableSsl = true,
            string smtpHost = "smtp.gmail.com",
            int smtpPort = 587)
        {
            _smtpUser = smtpUser ?? throw new ArgumentNullException(nameof(smtpUser));
            _smtpPass = smtpPass ?? throw new ArgumentNullException(nameof(smtpPass));
            _fromEmail = fromEmail ?? throw new ArgumentNullException(nameof(fromEmail));
            _fromName = string.IsNullOrWhiteSpace(fromName) ? "ZAIN SYSTEM" : fromName;
            _expiresMinutes = expiresMinutes <= 0 ? 5 : expiresMinutes;
            _enableSsl = enableSsl;

            _smtpHost = smtpHost;
            _smtpPort = smtpPort;
        }

        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            return Regex.IsMatch(email.Trim(), @"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.IgnoreCase);
        }

        public async Task SendOtpAsync(string email)
        {
            if (!IsValidEmail(email))
                throw new ArgumentException("Invalid email", nameof(email));

            var key = email.Trim().ToLowerInvariant();
            var code = Generate6Digits();

            _store[key] = new OtpEntry
            {
                Code = code,
                ExpiresAt = DateTime.Now.AddMinutes(_expiresMinutes)
            };

            try
            {
                // ✅ TLS (مهم على بعض الأجهزة/الشبكات)
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls13;

                using var client = new SmtpClient(_smtpHost, _smtpPort)
                {
                    EnableSsl = _enableSsl,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(_smtpUser, _smtpPass),
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    Timeout = 20000
                };

                using var msg = new MailMessage
                {
                    From = new MailAddress(_fromEmail, _fromName),
                    Subject = "ZAIN SYSTEM - OTP Code",
                    Body = BuildBody(code),
                    IsBodyHtml = true
                };

                msg.To.Add(email.Trim());

                // ✅ الأفضل بدل Task.Run
                await client.SendMailAsync(msg);

                // ✅ Log نجاح
                Log($"OTP sent to {email} (expires {_expiresMinutes}m).");
            }
            catch (SmtpException smtpEx)
            {
                Log("SMTP ERROR: " + smtpEx);
                throw new InvalidOperationException(
                    "فشل إرسال الإيميل عبر SMTP.\n" +
                    "تحقق من:\n" +
                    "1) تفعيل 2FA\n" +
                    "2) استخدام App Password صحيح\n" +
                    "3) الشبكة/الجدار الناري\n\n" +
                    smtpEx.Message, smtpEx);
            }
            catch (Exception ex)
            {
                Log("GENERAL ERROR: " + ex);
                throw new InvalidOperationException("حدث خطأ أثناء إرسال OTP.\n" + ex.Message, ex);
            }
        }

        public OtpVerifyResult VerifyOtp(string email, string code)
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(code))
                return OtpVerifyResult.NotFound;

            var key = email.Trim().ToLowerInvariant();
            if (!_store.TryGetValue(key, out var entry) || entry == null)
                return OtpVerifyResult.NotFound;

            if (DateTime.Now > entry.ExpiresAt)
                return OtpVerifyResult.Expired;

            if (!string.Equals(entry.Code, code.Trim(), StringComparison.Ordinal))
                return OtpVerifyResult.WrongCode;

            return OtpVerifyResult.Ok;
        }

        public void Invalidate(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return;
            var key = email.Trim().ToLowerInvariant();
            _store.TryRemove(key, out _);
        }

        private static string Generate6Digits()
        {
            // ✅ أفضل من Random العادي في تكرار الأكواد
            var rnd = Random.Shared;
            return rnd.Next(100000, 999999).ToString();
        }

        private static string BuildBody(string code)
        {
            return $@"
<div style='font-family:Segoe UI,Arial;line-height:1.8'>
  <h2>ZAIN SYSTEM</h2>
  <p>رمز التفعيل الخاص بك هو:</p>
  <div style='font-size:28px;font-weight:700;letter-spacing:6px'>{code}</div>
  <p style='color:#666'>إذا لم تطلب هذا الكود تجاهل الرسالة.</p>
</div>";
        }

        private static void Log(string line)
        {
            try
            {
                var dir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "ZainContractsManager");

                Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, "otp_log.txt"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {line}{Environment.NewLine}");
            }
            catch { }
        }
    }
}