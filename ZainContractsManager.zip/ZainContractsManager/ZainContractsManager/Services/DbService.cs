﻿using System;
using ZainContractsManager.Data;

namespace ZainContractsManager.Services
{
    public sealed class DbService : IDisposable
    {
        private static readonly Lazy<DbService> _lazy = new(() => new DbService());
        public static DbService Instance => _lazy.Value;

        private DbService()
        {
            // ممنوع EnsureCreated هنا.
            // تهيئة الداتابيز الصح بتكون في App.xaml.cs عبر Migrate().
        }

        public AppDbContext CreateDbContext()
        {
            // كل مرة Context جديد فقط
            return new AppDbContext();
        }

        public void Dispose()
        {
            // لا شيء
        }
    }
}