﻿#nullable enable
using System;
using System.Windows;

namespace ZainContractsManager.Services.Settings
{
    public static class ThemeService
    {
        private const string LightDict = "Resources/Colors.Light.xaml";
        private const string DarkDict = "Resources/Colors.Dark.xaml";

        public static void Apply(bool darkMode)
        {
            var app = Application.Current;
            if (app == null) return;

            var target = new Uri(darkMode ? DarkDict : LightDict, UriKind.Relative);

            // Remove old theme dictionaries
            for (int i = app.Resources.MergedDictionaries.Count - 1; i >= 0; i--)
            {
                var md = app.Resources.MergedDictionaries[i];
                var src = md.Source?.OriginalString ?? "";

                if (src.EndsWith("Colors.Light.xaml", StringComparison.OrdinalIgnoreCase) ||
                    src.EndsWith("Colors.Dark.xaml", StringComparison.OrdinalIgnoreCase))
                {
                    app.Resources.MergedDictionaries.RemoveAt(i);
                }
            }

            // Add selected theme
            app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source = target });
        }
    }
}