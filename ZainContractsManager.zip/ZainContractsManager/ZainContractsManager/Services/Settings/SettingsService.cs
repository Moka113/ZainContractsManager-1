﻿#nullable enable
using System;
using System.Linq;
using ZainContractsManager.Data;
using ZainContractsManager.Models.Settings;

namespace ZainContractsManager.Services.Settings
{
    public class SettingsService
    {
        public string? GetString(string key, string? defaultValue = null)
        {
            using var db = new AppDbContext();
            var row = db.AppSettings.FirstOrDefault(x => x.Key == key);
            return row?.Value ?? defaultValue;
        }

        public bool GetBool(string key, bool defaultValue = false)
        {
            var s = GetString(key, defaultValue ? "true" : "false");
            return bool.TryParse(s, out var b) ? b : defaultValue;
        }

        public int GetInt(string key, int defaultValue = 0)
        {
            var s = GetString(key, defaultValue.ToString());
            return int.TryParse(s, out var i) ? i : defaultValue;
        }

        public void SetString(string key, string value, string? description = null)
        {
            using var db = new AppDbContext();

            var row = db.AppSettings.FirstOrDefault(x => x.Key == key);
            if (row == null)
            {
                row = new AppSetting
                {
                    Key = key,
                    Value = value,
                    Description = description,
                    UpdatedAt = DateTime.UtcNow
                };
                db.AppSettings.Add(row);
            }
            else
            {
                row.Value = value;
                if (!string.IsNullOrWhiteSpace(description))
                    row.Description = description;

                row.UpdatedAt = DateTime.UtcNow;
            }

            db.SaveChanges();
        }

        public void SetBool(string key, bool value, string? description = null)
            => SetString(key, value ? "true" : "false", description);

        public void SetInt(string key, int value, string? description = null)
            => SetString(key, value.ToString(), description);
    }
}