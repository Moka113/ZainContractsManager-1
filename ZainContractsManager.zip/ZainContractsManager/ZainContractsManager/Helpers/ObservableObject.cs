﻿#nullable enable
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ZainContractsManager.Helpers
{
    public class ObservableObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        // إشعار تغيير الخاصية
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        // الدالة الأصلية الموجودة عندك
        protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
        {
            if (Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(name);
            return true;
        }

        // ✅ Alias احترافي علشان ViewModels الجديدة تستخدم SetProperty
        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? name = null)
            => Set(ref field, value, name);
    }
}