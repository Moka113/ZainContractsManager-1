﻿using System.Windows;
using System.Windows.Controls;

namespace ZainContractsManager.Helpers.UI
{
    // الهدف:
    // 1) نخلي PasswordBox يقبل Binding (عن طريق Attached Property اسمها Password)
    // 2) Attach = true تفعّل المزامنة بين الـ PasswordBox والـ VM
    public static class PasswordToggleHelper
    {
        public static readonly DependencyProperty AttachProperty =
            DependencyProperty.RegisterAttached(
                "Attach",
                typeof(bool),
                typeof(PasswordToggleHelper),
                new PropertyMetadata(false, OnAttachChanged));

        public static bool GetAttach(DependencyObject dp) => (bool)dp.GetValue(AttachProperty);
        public static void SetAttach(DependencyObject dp, bool value) => dp.SetValue(AttachProperty, value);

        public static readonly DependencyProperty PasswordProperty =
            DependencyProperty.RegisterAttached(
                "Password",
                typeof(string),
                typeof(PasswordToggleHelper),
                new FrameworkPropertyMetadata(string.Empty, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnPasswordPropertyChanged));

        public static string GetPassword(DependencyObject dp) => (string)dp.GetValue(PasswordProperty);
        public static void SetPassword(DependencyObject dp, string value) => dp.SetValue(PasswordProperty, value);

        private static readonly DependencyProperty IsUpdatingProperty =
            DependencyProperty.RegisterAttached(
                "IsUpdating",
                typeof(bool),
                typeof(PasswordToggleHelper),
                new PropertyMetadata(false));

        private static bool GetIsUpdating(DependencyObject dp) => (bool)dp.GetValue(IsUpdatingProperty);
        private static void SetIsUpdating(DependencyObject dp, bool value) => dp.SetValue(IsUpdatingProperty, value);

        private static void OnAttachChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is not PasswordBox pb) return;

            if ((bool)e.NewValue)
                pb.PasswordChanged += PasswordChanged;
            else
                pb.PasswordChanged -= PasswordChanged;
        }

        private static void OnPasswordPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is not PasswordBox pb) return;

            pb.PasswordChanged -= PasswordChanged;

            if (!GetIsUpdating(pb))
            {
                pb.Password = e.NewValue?.ToString() ?? "";
            }

            pb.PasswordChanged += PasswordChanged;
        }

        private static void PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (sender is not PasswordBox pb) return;

            SetIsUpdating(pb, true);
            SetPassword(pb, pb.Password);
            SetIsUpdating(pb, false);
        }
    }
}