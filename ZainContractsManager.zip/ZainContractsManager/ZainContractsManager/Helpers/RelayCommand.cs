﻿using System;
using System.Windows.Input;

namespace ZainContractsManager.Helpers
{
    public class RelayCommand : ICommand
    {
        private readonly Action? _execute;
        private readonly Func<bool>? _canExecute;

        private readonly Action<object?>? _executeParam;
        private readonly Func<object?, bool>? _canExecuteParam;

        public RelayCommand(Action execute, Func<bool>? canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null)
        {
            _executeParam = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecuteParam = canExecute;
        }

        public event EventHandler? CanExecuteChanged;

        public bool CanExecute(object? parameter)
        {
            if (_canExecute != null) return _canExecute();
            if (_canExecuteParam != null) return _canExecuteParam(parameter);
            return true;
        }

        public void Execute(object? parameter)
        {
            if (_execute != null)
            {
                _execute();
                return;
            }

            _executeParam?.Invoke(parameter);
        }

        // ✅ دي اللي كانت ناقصة
        public void RaiseCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
            CommandManager.InvalidateRequerySuggested();
        }
    }
}