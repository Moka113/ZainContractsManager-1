﻿namespace ZainContractsManager.AI_Module
{
    public static class ZainAnalyst
    {
        public static string PrepareContext(decimal totalRent, decimal utilities, int alerts, string branchName)
        {
            return $"تحليل استراتيجي لفرع {branchName}: " +
                   $"- الإيجارات: {totalRent:N2} ريال. " +
                   $"- المصاريف: {utilities:N2} ريال. " +
                   $"- التنبيهات: {alerts} عقود منتهية أو قريبة. " +
                   $"كمحلل بيانات مالي، ما هي نصيحتك لهذا الفرع؟";
        }
    }
}