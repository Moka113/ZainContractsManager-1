﻿#nullable enable
namespace ZainContractsManager.AI_Module
{
    public enum ChatMessageRole
    {
        System = 0,
        User = 1,
        Assistant = 2
    }
}