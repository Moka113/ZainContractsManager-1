﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZainContractsManager.AI_Module
{
    internal class ChatSessionService
    {
    }
}
