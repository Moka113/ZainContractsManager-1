﻿#nullable enable
using System;

namespace ZainContractsManager.AI_Module
{
    public class ChatMessage
    {
        public string Sender { get; set; } = "";
        public string Text { get; set; } = "";
        public DateTime Time { get; set; } = DateTime.Now;

        public bool IsUser { get; set; }
        public bool IsTyping { get; set; }   // للـ AI

        // عرضيات جاهزة للـ Binding
        public string TimeText => Time.ToString("HH:mm");

        public string StatusText => IsUser ? "✔✔" : "";
        public string ShowStatus => IsUser ? "Visible" : "Collapsed";

        public string IsUserBubble => IsUser ? "Visible" : "Collapsed";
        public string IsAiBubble => !IsUser ? "Visible" : "Collapsed";

        public string ShowTyping => (!IsUser && IsTyping) ? "Visible" : "Collapsed";
    }
}