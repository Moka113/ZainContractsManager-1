﻿#nullable enable
using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace ZainContractsManager.AI_Module
{
    /// <summary>
    /// عميل بسيط لـ Ollama (Streaming) متوافق مع WPF و CancellationToken
    /// </summary>
    public sealed class OllamaClient : IDisposable
    {
        private readonly HttpClient _http;
        private readonly string _baseUrl;
        private readonly string _model;

        // يمكنك تغيير الموديل هنا لو تبغى
        // مثال: "zain-ai" أو "qwen2.5" أو "mistral" حسب الموجود عندك في Ollama
        public OllamaClient(string baseUrl = "http://localhost:11434", string model = "zain-ai")
        {
            _baseUrl = baseUrl.TrimEnd('/');
            _model = model;

            _http = new HttpClient
            {
                Timeout = Timeout.InfiniteTimeSpan // مهم للـ streaming
            };
        }

        /// <summary>
        /// يرسل Prompt إلى Ollama ويستقبل الرد بشكل Streaming token-by-token
        /// </summary>
        public async Task AskZainAIStream(
            string prompt,
            Action<string> onToken,
            CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return;

            if (onToken is null)
                throw new ArgumentNullException(nameof(onToken));

            var url = $"{_baseUrl}/api/generate";

            // Ollama JSON body
            var payload = new
            {
                model = _model,
                prompt = prompt,
                stream = true
            };

            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");

            // نستخدم HttpRequestMessage عشان نضمن Streaming
            using var req = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };

            // ResponseHeadersRead => لا ينتظر تحميل كامل الرد قبل القراءة
            using var resp = await _http.SendAsync(
                req,
                HttpCompletionOption.ResponseHeadersRead,
                cancellationToken);

            resp.EnsureSuccessStatusCode();

            await using var stream = await resp.Content.ReadAsStreamAsync(cancellationToken);
            using var reader = new StreamReader(stream);

            // Ollama بيرجع JSON lines (كل سطر JSON مستقل)
            while (!reader.EndOfStream && !cancellationToken.IsCancellationRequested)
            {
                var line = await reader.ReadLineAsync();
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                // Parse JSON line: { "response": "...", "done": false, ... }
                try
                {
                    using var doc = JsonDocument.Parse(line);
                    var root = doc.RootElement;

                    if (root.TryGetProperty("response", out var r))
                    {
                        var token = r.GetString();
                        if (!string.IsNullOrEmpty(token))
                            onToken(token);
                    }

                    if (root.TryGetProperty("done", out var doneEl) && doneEl.GetBoolean())
                        break;
                }
                catch (JsonException)
                {
                    // لو وصل سطر غير متوقع، نتجاهله بدون ما نوقف البرنامج
                }
            }
        }

        public void Dispose()
        {
            _http.Dispose();
        }
    }
}