﻿#nullable enable
namespace ZainContractsManager.AI_Module
{
    /// <summary>
    /// أي صفحة (View) تحب تدي للـ AI Snapshot سريع عنها (بدون DB).
    /// </summary>
    public interface IAiPageContextProvider
    {
        string GetAiContextSnapshot();
    }
}