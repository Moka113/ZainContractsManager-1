﻿#nullable enable
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ZainContractsManager.Data;
using ZainContractsManager.Models;
using System.Collections.Generic;

namespace ZainContractsManager.AI_Module
{
    public static class ZainContextBuilder
    {
        public sealed class ContextOptions
        {
            public int MaxChars { get; set; } = 6500;
            public int TopRows { get; set; } = 8;
            public string? Question { get; set; }
            public string? BranchName { get; set; }
        }

        private static string Norm(string? s) => (s ?? "").Trim().ToLowerInvariant();

        private static bool ContainsAny(string? haystack, params string[] keys)
        {
            var h = Norm(haystack);
            foreach (var k in keys)
                if (h.Contains(Norm(k))) return true;
            return false;
        }

        private static string TrimTo(string text, int maxChars)
        {
            if (string.IsNullOrEmpty(text)) return "";
            if (text.Length <= maxChars) return text;
            return text.Substring(0, Math.Max(0, maxChars - 3)) + "...";
        }

        public static async Task<string> BuildGlobalContextAsync(ContextOptions opt)
        {
            try
            {
                using var db = new AppDbContext();
                // إلغاء تهيئة القاعدة في كل مرة لتحسين السرعة، نفترض أنها موجودة

                var today = DateTime.Today;
                var question = opt.Question ?? "";
                var branch = opt.BranchName;

                // التوجيه الذكي للبيانات (Logic Routing)
                bool qContracts = ContainsAny(question, "عقد", "العقود", "ايجار", "إيجار", "مؤجر", "مستأجر", "تجديد", "منتهي");
                bool qPayments = ContainsAny(question, "دفعة", "الدفعات", "سداد", "تحصيل", "متأخر", "due");
                bool qDocs = ContainsAny(question, "مستند", "ارشفة", "pdf", "صك", "رخص");
                bool qExpenses = ContainsAny(question, "مصاريف", "فواتير", "فاتورة", "كهرباء", "صيانة", "ضريبة");
                bool qGeneral = !(qContracts || qPayments || qDocs || qExpenses);

                // الاستعلامات الأساسية
                var contractsQ = db.Contracts.AsNoTracking();
                var docsQ = db.Documents.AsNoTracking();
                var expQ = db.FinancialExpenses.AsNoTracking();
                var payQ = db.Payments.AsNoTracking();

                if (!string.IsNullOrWhiteSpace(branch))
                {
                    var bn = Norm(branch);
                    contractsQ = contractsQ.Where(c => c.BranchName.ToLower().Contains(bn));
                    docsQ = docsQ.Where(d => d.BranchName.ToLower().Contains(bn));
                    expQ = expQ.Where(e => e.BranchName.ToLower().Contains(bn));
                }

                // تنفيذ الـ Counts بشكل آمن
                var cCount = await contractsQ.CountAsync();
                var pCount = await payQ.CountAsync();
                var dCount = await docsQ.CountAsync();
                var eCount = await expQ.CountAsync();

                // حل مشكلة الـ Decimal في SQLite: نقوم بجلب القيم للذاكرة ثم حسابها لتجنب خطأ الـ SQL الحسابي
                var activeContractsData = await contractsQ
                    .Where(c => c.EndDate >= today)
                    .Select(c => new { c.AmountBeforeTax, c.VatAmount, c.AdditionalFixedAmounts })
                    .ToListAsync();

                decimal activeRentValue = activeContractsData.Sum(c => c.AmountBeforeTax + c.VatAmount + c.AdditionalFixedAmounts);

                var archivedDocsCount = await docsQ.CountAsync(d => d.IsArchived || (d.FilePath != null && d.FilePath != ""));

                // حساب المصاريف بشكل آمن (In-Memory Sum)
                var expData = await expQ
                    .Where(e => e.ExpenseDate >= today.AddDays(-90))
                    .Select(e => new { e.ExpenseDate, e.Amount, e.TaxAmount })
                    .ToListAsync();

                decimal exp30 = expData.Where(e => e.ExpenseDate >= today.AddDays(-30)).Sum(e => e.Amount + e.TaxAmount);
                decimal exp90 = expData.Sum(e => e.Amount + e.TaxAmount);

                var overduePayments = await payQ.CountAsync(p => p.DueDate < today && !p.IsPaid);
                var dueNext30 = await payQ.CountAsync(p => p.DueDate >= today && p.DueDate <= today.AddDays(30) && !p.IsPaid);

                var sb = new StringBuilder(15000);
                sb.AppendLine("### [نظام زين - سياق البيانات الحالي]");
                sb.AppendLine($"- التاريخ: {DateTime.Now:yyyy-MM-dd HH:mm}");
                sb.AppendLine($"- الإحصائيات: عقود({cCount})، دفعات({pCount})، مستندات({dCount})، فواتير({eCount})");
                if (!string.IsNullOrEmpty(branch)) sb.AppendLine($"- تصفية حسب الفرع: {branch}");

                sb.AppendLine("\n## المؤشرات المالية (KPIs)");
                sb.AppendLine($"- قيمة الإيجارات النشطة: {activeRentValue:N0} ريال");
                sb.AppendLine($"- فواتير آخر 30 يوم: {exp30:N0} ريال");
                sb.AppendLine($"- دفعات متأخرة: {overduePayments} دفعة");
                sb.AppendLine($"- دفعات مستحقة قريباً: {dueNext30}");

                // جلب عينات البيانات (Samples) مع حماية الـ Null
                int top = opt.TopRows;

                if (qGeneral || qContracts)
                {
                    var sampleContracts = await contractsQ.OrderBy(c => c.EndDate).Take(top).ToListAsync();
                    sb.AppendLine("\n## عينة العقود (الأقرب للانتهاء):");
                    foreach (var c in sampleContracts)
                        sb.AppendLine($"- عقد {c.ContractNumber} | {c.TenantName} | ينتهي: {c.EndDate:yyyy-MM-dd} | القيمة: {(c.AmountBeforeTax + c.VatAmount):N0}");
                }

                if (qGeneral || qPayments)
                {
                    // نظام الـ Join اليدوي لتجنب مشاكل SQLite في الـ Include المعقد
                    var samplePayments = await (from p in db.Payments.AsNoTracking()
                                                join c in db.Contracts on p.ContractId equals c.Id
                                                orderby p.DueDate
                                                select new { p.DueDate, p.Amount, p.IsPaid, c.ContractNumber, c.BranchName })
                                         .Take(top).ToListAsync();

                    sb.AppendLine("\n## جدول الدفعات:");
                    foreach (var p in samplePayments)
                        sb.AppendLine($"- استحقاق: {p.DueDate:yyyy-MM-dd} | مبلغ: {p.Amount:N0} | عقد: {p.ContractNumber} | حالة: {(p.IsPaid ? "مدفوعة" : "معلقة")}");
                }

                // أمر توجيهي صارم للموديل لمنع الصينية والهلوسة
                sb.AppendLine("\n[System Instruction]: أجب على سؤال المستخدم باللغة العربية فقط بناءً على البيانات أعلاه. إذا لم تتوفر إجابة دقيقة، اطلب من المستخدم توضيح السؤال.");

                return TrimTo(sb.ToString(), opt.MaxChars);
            }
            catch (Exception ex)
            {
                return $"[Error building context]: {ex.Message}";
            }
        }
    }
}